// shared.js — field mapping and formatting used by both the runner and the exports.

export const API = 'https://partnersapi.myntrainfo.com/api/spf/getTickets';
export const BLOB_PREFIX = 'https://myntrascmuistaticassets.blob.core.windows.net/spf-claims/';

export const STATUSES = [
  { value: 'REJECT',   label: 'Rejected' },
  { value: 'OPEN',     label: 'In review' },
  { value: 'APPROVED', label: 'Approved' },
  { value: 'PAID',     label: 'Paid' },
  { value: 'ALL',      label: 'All claims' }
];

// Columns written to CSV / clipboard, in order.
export const COLUMNS = [
  'Ticket No', 'Order ID', 'Order Line ID', 'Return ID', 'Brand', 'Product Name',
  'Style ID', 'Seller SKU', 'Article Type', 'MRP (Rs)', 'Claim Value (Rs)', 'COGS (Rs)',
  'Compensation (Rs)', 'Fwd Tracking ID', 'Return Tracking ID', 'Issue Category',
  'Return Reason', 'Return Mode', 'Status', 'Rejection Reason', 'Claim Created (IST)',
  'Claim Updated (IST)', 'Order Created', 'Shipped On', 'Order Delivered',
  'Return Created', 'Pickup Date', 'Return POD Date', 'Warehouse ID', 'Refunded',
  'Tag Loop Eligible', 'Total Proofs', 'Claim Description'
];

const https = u => (u || '').replace(/^http:\/\//, 'https://');

export function title(s) {
  if (!s) return '';
  return String(s).replace(/_/g, ' ').toLowerCase()
    .replace(/\b\w/g, c => c.toUpperCase());
}

// Portal timestamps come back as UTC ISO; the portal itself shows IST.
export function toIST(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  if (isNaN(d)) return iso;
  const ist = new Date(d.getTime() + (5.5 * 3600 * 1000));
  const p = n => String(n).padStart(2, '0');
  return `${p(ist.getUTCDate())}-${p(ist.getUTCMonth() + 1)}-${ist.getUTCFullYear()} ${p(ist.getUTCHours())}:${p(ist.getUTCMinutes())}`;
}

// Turn one raw API ticket into the flat record everything else uses.
export function normalise(d) {
  let meta = {};
  try { meta = typeof d.meta === 'string' ? JSON.parse(d.meta) : (d.meta || {}); } catch (e) { meta = {}; }
  const si = d.styleInfo || {};
  const sb = si.styleBasic || {};
  const proofs = String(d.productProofUrls || '')
    .split(',').map(s => https(s.trim())).filter(Boolean);
  const label = https(d.shippingLabelProofUrl);
  const video = https(d.videoProofUrl);

  return {
    ticketId: d.ticketId,
    orderId: d.orderId,
    orderLineId: d.orderLineId,
    returnId: d.returnId || '',
    brand: meta.brandName || sb.brandName || '',
    productName: sb.name || sb.productDisplayName || '',
    styleId: d.styleId,
    skuId: d.skuId,
    articleType: sb.articleTypeName || meta.articleType || '',
    mrp: sb.price ?? '',
    claimAmount: meta.finalAmount ? Number(meta.finalAmount) : '',
    cogs: d.cogs != null ? Math.round(d.cogs * 100) / 100 : '',
    compensation: d.compensationAmount ?? '',
    fwdTracking: d.trackingId || '',
    returnTracking: meta.returnTrackingId || '',
    issueCategory: title(d.issueCategory),
    returnReason: d.returnReason || '',
    returnMode: title(d.returnMode),
    status: title(d.status),
    rejectionReason: title(d.validationReason),
    diagnostics: (((meta.validationResults || [])[0] || {}).diagnosticReasons || []).join(' | '),
    claimCreated: toIST(d.createdOn),
    claimUpdated: toIST(d.lastModifiedOn),
    orderCreated: d.orderCreatedDate || '',
    shippedOn: d.shippedOn || '',
    orderDelivered: d.orderDeliveredDate || '',
    returnCreated: d.returnCreatedDate || '',
    pickupDate: d.pickupDate || '',
    podDate: d.podDate || '',
    warehouseId: d.warehouseId ?? '',
    refunded: d.isRefunded ? 'Yes' : 'No',
    tagLoop: String(meta.isEligibleForTagLoop).toLowerCase() === 'true' ? 'Yes' : 'No',
    description: String(d.description || '').replace(/\s+/g, ' ').trim(),
    productImage: https(si.imageLink360px || si.imageLink),
    landingPage: sb.landingPageUrl ? 'https://www.myntra.com/' + sb.landingPageUrl : '',
    labelProof: label,
    proofs,
    videoProof: video
  };
}

export function rowValues(r) {
  return [
    r.ticketId, r.orderId, r.orderLineId, r.returnId, r.brand, r.productName,
    r.styleId, r.skuId, r.articleType, r.mrp, r.claimAmount, r.cogs,
    r.compensation, r.fwdTracking, r.returnTracking, r.issueCategory,
    r.returnReason, r.returnMode, r.status, r.rejectionReason, r.claimCreated,
    r.claimUpdated, r.orderCreated, r.shippedOn, r.orderDelivered,
    r.returnCreated, r.pickupDate, r.podDate, r.warehouseId, r.refunded,
    r.tagLoop, r.proofs.length + (r.labelProof ? 1 : 0), r.description
  ];
}

export function toCSV(rows) {
  const esc = v => {
    const s = v == null ? '' : String(v);
    return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  };
  const urlCols = ['Product Image URL', 'Shipping Label URL',
    'Proof 1 URL', 'Proof 2 URL', 'Proof 3 URL', 'Proof 4 URL', 'Proof 5 URL',
    'Extra Proof URLs', 'Video Proof URL', 'Myntra Product Page'];
  const head = [...COLUMNS, ...urlCols].map(esc).join(',');
  const body = rows.map(r => {
    const p = r.proofs;
    return [
      ...rowValues(r), r.productImage, r.labelProof,
      p[0] || '', p[1] || '', p[2] || '', p[3] || '', p[4] || '',
      p.slice(5).join(' | '), r.videoProof, r.landingPage
    ].map(esc).join(',');
  });
  return [head, ...body].join('\r\n');
}

// TSV for the clipboard. Pasted into Google Sheets, =IMAGE() cells become
// live formulas — which a CSV *import* never does.
export function toSheetTSV(rows) {
  const clean = v => (v == null ? '' : String(v).replace(/[\t\r\n]+/g, ' '));
  const img = u => (u ? `=IMAGE("${u}",1)` : '');
  const head = ['Product Image', ...COLUMNS, 'Shipping Label',
    'Proof 1', 'Proof 2', 'Proof 3', 'Proof 4', 'Proof 5', 'Myntra Product Page'];
  const body = rows.map(r => {
    const p = r.proofs;
    return [
      img(r.productImage), ...rowValues(r).map(clean), img(r.labelProof),
      img(p[0]), img(p[1]), img(p[2]), img(p[3]), img(p[4]),
      r.landingPage ? `=HYPERLINK("${r.landingPage}","Open listing")` : ''
    ].join('\t');
  });
  return [head.join('\t'), ...body].join('\n');
}

export function totals(rows) {
  const num = v => (typeof v === 'number' ? v : parseFloat(v) || 0);
  return {
    count: rows.length,
    claim: rows.reduce((a, r) => a + num(r.claimAmount), 0),
    cogs: rows.reduce((a, r) => a + num(r.cogs), 0),
    comp: rows.reduce((a, r) => a + num(r.compensation), 0),
    photos: rows.reduce((a, r) => a + r.proofs.length + (r.labelProof ? 1 : 0) + (r.videoProof ? 1 : 0), 0)
  };
}

export function groupBy(rows, key) {
  const m = new Map();
  for (const r of rows) {
    const k = r[key] || '—';
    const g = m.get(k) || { n: 0, value: 0 };
    g.n++; g.value += parseFloat(r.claimAmount) || 0;
    m.set(k, g);
  }
  return [...m.entries()].sort((a, b) => b[1].value - a[1].value);
}

export const rupees = n =>
  '₹' + Math.round(n).toLocaleString('en-IN');

// Every image belonging to one claim, with the filename it gets inside the ZIP.
export function assetsOf(r) {
  const out = [];
  const ext = u => (/\.(jpe?g|png|webp|gif)(\?|$)/i.exec(u || '') || [, 'jpg'])[1];
  if (r.productImage) out.push({ url: r.productImage, name: `00_catalogue.${ext(r.productImage)}` });
  if (r.labelProof) out.push({ url: r.labelProof, name: '01_shipping_label.jpg' });
  r.proofs.forEach((u, i) => out.push({ url: u, name: `${String(i + 2).padStart(2, '0')}_proof_${i + 1}.jpg` }));
  if (r.videoProof) out.push({ url: r.videoProof, name: '90_video_proof.mp4' });
  return out;
}

export const folderOf = r => `${r.ticketId}_order_${r.orderId}`;
