import { STATUSES } from './shared.js';

const $ = id => document.getElementById(id);
const iso = d => d.toISOString().slice(0, 10);

const sel = $('status');
for (const s of STATUSES) {
  const o = document.createElement('option');
  o.value = s.value; o.textContent = s.label;
  sel.appendChild(o);
}

const today = new Date();
const twoYearsAgo = new Date(today);
twoYearsAgo.setFullYear(today.getFullYear() - 2);
$('to').value = iso(today);
$('from').value = iso(twoYearsAgo);

// Restore last-used settings.
chrome.storage.local.get('spfPrefs').then(({ spfPrefs }) => {
  if (!spfPrefs) return;
  if (spfPrefs.status) sel.value = spfPrefs.status;
  if (spfPrefs.from) $('from').value = spfPrefs.from;
  if (spfPrefs.to) $('to').value = spfPrefs.to;
  $('optPhotos').checked = spfPrefs.photos !== false;
  $('optDossier').checked = spfPrefs.dossier !== false;
});

// The portal tab has to be open — that is where the session lives.
let sourceTabId = null;
const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
const tab = tabs[0];
if (tab && /^https:\/\/partners\.myntrainfo\.com\//.test(tab.url || '')) {
  sourceTabId = tab.id;
} else {
  const others = await chrome.tabs.query({ url: 'https://partners.myntrainfo.com/*' });
  if (others.length) {
    sourceTabId = others[0].id;
    show(`Using your other partner-portal tab: “${others[0].title || 'Partner portal'}”.`);
  } else {
    show('Open <a href="https://partners.myntrainfo.com/SPF" target="_blank">partners.myntrainfo.com/SPF</a> and sign in first — the extractor borrows that tab’s session.');
    $('run').disabled = true;
  }
}

function show(html) {
  const w = $('warn');
  w.innerHTML = html;
  w.hidden = false;
}

$('run').addEventListener('click', async () => {
  const prefs = {
    status: sel.value,
    from: $('from').value,
    to: $('to').value,
    photos: $('optPhotos').checked,
    dossier: $('optDossier').checked
  };
  await chrome.storage.local.set({ spfPrefs: prefs });

  const params = new URLSearchParams({
    tabId: String(sourceTabId),
    status: prefs.status,
    from: prefs.from,
    to: prefs.to,
    photos: prefs.photos ? '1' : '0',
    dossier: prefs.dossier ? '1' : '0'
  });
  await chrome.tabs.create({ url: chrome.runtime.getURL('runner.html') + '?' + params });
  window.close();
});
