import {
  STATUSES, normalise, toCSV, toSheetTSV, totals, groupBy,
  rupees, assetsOf, folderOf, title
} from './shared.js';

const $ = id => document.getElementById(id);
const q = new URLSearchParams(location.search);
const opts = {
  tabId: Number(q.get('tabId')),
  status: q.get('status') || 'REJECT',
  from: q.get('from'),
  to: q.get('to'),
  photos: q.get('photos') === '1',
  dossier: q.get('dossier') === '1'
};
const statusLabel = (STATUSES.find(s => s.value === opts.status) || {}).label || opts.status;

let rows = [];

/* ---------------------------------------------------------------- progress */

function log(msg, cls) {
  const li = document.createElement('li');
  li.textContent = msg;
  if (cls) li.className = cls;
  $('log').appendChild(li);
  $('log').scrollTop = $('log').scrollHeight;
}
const setBar = pct => { $('progress').style.width = Math.max(0, Math.min(100, pct)) + '%'; };
const stage = t => { $('stageTitle').textContent = t; };

/* ------------------------------------------------------------------ portal */

// Runs inside the portal tab so the request carries that session exactly as
// the site's own code would. Paginates until a short page comes back.
function fetchTicketsInPage(startDate, endDate, status) {
  const base = 'https://partnersapi.myntrainfo.com/api/spf/getTickets';
  const size = 100;
  return (async () => {
    const all = [];
    for (let page = 1; page <= 60; page++) {
      const p = new URLSearchParams({
        startDate, endDate, fetchAccio: 'true',
        page: String(page), pageSize: String(size)
      });
      if (status && status !== 'ALL') p.set('status', status);
      const res = await fetch(base + '?' + p.toString(), { credentials: 'include' });
      if (!res.ok) return { error: `Portal replied ${res.status} on page ${page}.` };
      const json = await res.json();
      const batch = (json && json.data) || [];
      all.push(...batch);
      if (batch.length < size) break;
    }
    return { data: all };
  })();
}

async function loadClaims() {
  const startDate = `${opts.from} 00:00:00`;
  const endDate = `${opts.to} 23:59:59`;
  log(`Asking the portal for ${statusLabel.toLowerCase()} claims, ${opts.from} → ${opts.to}.`);

  let result;
  try {
    const [inj] = await chrome.scripting.executeScript({
      target: { tabId: opts.tabId },
      world: 'MAIN',
      func: fetchTicketsInPage,
      args: [startDate, endDate, opts.status]
    });
    result = inj && inj.result;
  } catch (e) {
    throw new Error(`Could not reach the portal tab (${e.message}). Keep the tab open and signed in, then run again.`);
  }
  if (!result) throw new Error('The portal tab returned nothing. Reload it and try again.');
  if (result.error) throw new Error(result.error);
  return result.data.map(normalise);
}

/* ----------------------------------------------------------------- exports */

function download(filename, blob) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}

const stamp = () => new Date().toISOString().slice(0, 10);
const slug = () => `myntra-spf-${opts.status.toLowerCase()}-${stamp()}`;

function downloadCSV() {
  download(`${slug()}.csv`, new Blob(['﻿' + toCSV(rows)], { type: 'text/csv;charset=utf-8' }));
  log(`Saved ${slug()}.csv`, 'done');
}

async function copySheetRows() {
  await navigator.clipboard.writeText(toSheetTSV(rows));
  $('copied').textContent = 'Copied — paste into cell A1 of a Google Sheet.';
  setTimeout(() => { $('copied').textContent = ''; }, 9000);
}

function downloadDossier() {
  download(`${slug()}-dossier.html`,
    new Blob([buildDossier()], { type: 'text/html;charset=utf-8' }));
  log(`Saved ${slug()}-dossier.html`, 'done');
}

async function downloadPhotos() {
  const jobs = [];
  for (const r of rows) for (const a of assetsOf(r)) jobs.push({ r, a });
  if (!jobs.length) { log('No proof photos on these claims.'); return; }

  stage(`Downloading ${jobs.length} photos`);
  $('btnZip').disabled = true;
  const zip = new JSZip();
  let done = 0, failed = 0;

  const worker = async queue => {
    while (queue.length) {
      const { r, a } = queue.pop();
      try {
        const res = await fetch(a.url);
        if (!res.ok) throw new Error(String(res.status));
        zip.folder(folderOf(r)).file(a.name, await res.blob());
      } catch (e) {
        failed++;
        log(`Could not fetch ${a.name} for ticket ${r.ticketId} (${e.message}).`, 'err');
      }
      done++;
      setBar(done / jobs.length * 100);
      if (done % 10 === 0 || done === jobs.length) stage(`Downloading photos — ${done} of ${jobs.length}`);
    }
  };
  const queue = jobs.slice();
  await Promise.all(Array.from({ length: 6 }, () => worker(queue)));

  zip.file('claims.csv', '﻿' + toCSV(rows));
  stage('Zipping');
  const blob = await zip.generateAsync({ type: 'blob', compression: 'STORE' });
  download(`${slug()}-photos.zip`, blob);
  log(`Saved ${slug()}-photos.zip — ${done - failed} photos in ${rows.length} folders.`, 'done');
  $('btnZip').disabled = false;
  stage('Done');
}

/* ----------------------------------------------------------------- dossier */

const esc = s => String(s == null ? '' : s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

function buildDossier() {
  const t = totals(rows);
  const cards = rows.map(r => {
    const shots = [];
    if (r.labelProof) shots.push([r.labelProof, 'Shipping label']);
    r.proofs.forEach((u, i) => shots.push([u, `Product &amp; packing ${i + 1}`]));
    const facts = [
      ['Order ID', r.orderId], ['Order line ID', r.orderLineId], ['Return ID', r.returnId || '—'],
      ['Forward tracking', r.fwdTracking || '—'], ['Return tracking', r.returnTracking || '—'],
      ['Style ID', r.styleId], ['Seller SKU', r.skuId], ['Warehouse', r.warehouseId],
      ['Order delivered', r.orderDelivered || '—'], ['Return created', r.returnCreated || '—'],
      ['Return POD', r.podDate || '—'], ['Claim raised', r.claimCreated || '—']
    ];
    return `<article class="claim">
  <header><span class="tk">Ticket ${esc(r.ticketId)}</span>
    <div class="hrow"><div><h3>${esc(r.productName)}</h3>
      <p class="sub">${esc(r.brand)} · ${esc(r.articleType)} · ${esc(r.issueCategory)}${r.returnReason ? ' · ' + esc(r.returnReason) : ''}</p></div>
      <div class="money"><span class="amt">${rupees(parseFloat(r.claimAmount) || 0)}</span>
      <span class="cogs">COGS ${rupees(parseFloat(r.cogs) || 0)} · MRP ${rupees(parseFloat(r.mrp) || 0)}</span></div>
    </div></header>
  <p class="verdict"><span class="chip">${esc(r.status)}</span> ${esc(r.rejectionReason || '—')}</p>
  <div class="body">
    <div class="orig"><span class="cap">Original product dispatched</span>
      <img src="${esc(r.productImage)}" alt="${esc(r.productName)}" loading="lazy"></div>
    <dl class="grid">${facts.map(([k, v]) => `<div class="f"><dt>${k}</dt><dd>${esc(v)}</dd></div>`).join('')}</dl>
  </div>
  <section class="proofs"><span class="cap">Seller proof submitted — ${shots.length} photo${shots.length === 1 ? '' : 's'}</span>
    <div class="strip">${shots.map(([u, c]) => `<figure><img src="${esc(u)}" alt="${c}" loading="lazy"><figcaption>${c}</figcaption></figure>`).join('')}</div>
  </section>
  ${r.description ? `<p class="desc">${esc(r.description)}</p>` : ''}
</article>`;
  }).join('\n');

  return `<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Myntra SPF — ${esc(statusLabel)} claims dossier</title>
<style>
:root{--paper:#F7F8FA;--surface:#fff;--sunk:#EFF1F5;--ink:#14161C;--ink-2:#4A515E;--line:#DFE3EA;--accent:#2B4C7E;--crit:#A4271F;--crit-soft:#FBE9E7}
@media(prefers-color-scheme:dark){:root{--paper:#0F1116;--surface:#171A21;--sunk:#1E222B;--ink:#E9ECF2;--ink-2:#9AA3B2;--line:#2A2F3A;--accent:#8FB0DE;--crit:#F0938A;--crit-soft:#2C1A18}}
*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font:400 15px/1.55 system-ui,-apple-system,"Segoe UI",sans-serif}
.wrap{max-width:1120px;margin:0 auto;padding:38px 24px 80px}
h1{margin:0;font-size:clamp(26px,4vw,38px);font-weight:700;letter-spacing:-.02em}
.cap{font:500 11px/1 ui-monospace,monospace;letter-spacing:.09em;text-transform:uppercase;color:var(--ink-2)}
header.top{border-bottom:2px solid var(--ink);padding-bottom:16px;margin-bottom:26px}
header.top .cap{display:block;margin-bottom:9px}header.top p{margin:7px 0 0;color:var(--ink-2);max-width:66ch}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(155px,1fr));gap:1px;background:var(--line);border:1px solid var(--line);margin-bottom:28px}
.stat{background:var(--surface);padding:15px 17px}.stat .n{display:block;font-size:25px;font-weight:700;letter-spacing:-.02em;font-variant-numeric:tabular-nums}
.stat .k{font:500 10.5px/1.3 ui-monospace,monospace;letter-spacing:.08em;text-transform:uppercase;color:var(--ink-2)}
.claims{display:grid;gap:19px}
.claim{background:var(--surface);border:1px solid var(--line);border-left:3px solid var(--crit);padding:19px 21px;box-shadow:0 1px 2px rgba(20,22,28,.06)}
.tk{display:block;font:500 11px/1 ui-monospace,monospace;letter-spacing:.08em;color:var(--accent);margin-bottom:6px}
.hrow{display:flex;gap:18px;justify-content:space-between;align-items:flex-start;flex-wrap:wrap}
h3{margin:0;font-size:16.5px;font-weight:600;letter-spacing:-.01em;text-wrap:balance}
.sub{margin:5px 0 0;font-size:12.5px;color:var(--ink-2)}
.money{text-align:right}.amt{display:block;font-size:23px;font-weight:700;letter-spacing:-.02em;font-variant-numeric:tabular-nums}
.cogs{display:block;font-family:ui-monospace,monospace;font-size:11px;color:var(--ink-2);margin-top:3px}
.verdict{margin:15px 0 0;font-size:13px;color:var(--crit);display:flex;gap:9px;align-items:center;flex-wrap:wrap}
.chip{background:var(--crit-soft);color:var(--crit);border:1px solid rgba(164,39,31,.3);font:500 10px/1 ui-monospace,monospace;letter-spacing:.09em;text-transform:uppercase;padding:5px 8px}
.body{display:grid;grid-template-columns:160px 1fr;gap:20px;margin-top:16px;align-items:start}
@media(max-width:760px){.body{grid-template-columns:1fr}}
.orig .cap{display:block;margin-bottom:8px}
img{display:block;width:100%;border:1px solid var(--line);background:var(--sunk)}
.orig img{aspect-ratio:3/4;object-fit:cover}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:11px 17px;margin:0}
.f dt{font:500 10px/1.3 ui-monospace,monospace;letter-spacing:.07em;text-transform:uppercase;color:var(--ink-2)}
.f dd{margin:3px 0 0;font-family:ui-monospace,monospace;font-size:12.5px;word-break:break-word}
.proofs{margin-top:18px;border-top:1px solid var(--line);padding-top:15px}
.strip{display:grid;grid-template-columns:repeat(auto-fill,minmax(110px,1fr));gap:9px;margin-top:9px}
figure{margin:0}figure img{aspect-ratio:1;object-fit:cover}
figcaption{font:400 10px/1.3 ui-monospace,monospace;color:var(--ink-2);margin-top:4px}
.desc{margin:15px 0 0;font-size:12.5px;color:var(--ink-2);border-left:2px solid var(--line);padding-left:11px}
footer{margin-top:38px;border-top:1px solid var(--line);padding-top:15px;font-size:12px;color:var(--ink-2)}
</style></head><body><div class="wrap">
<header class="top"><span class="cap">Seller Protection Fund · ${esc(opts.from)} → ${esc(opts.to)}</span>
<h1>${esc(statusLabel)} claims dossier</h1>
<p>Each claim with the catalogue image of what was dispatched, the seller proof photos filed against the order, and the tracking and value trail behind the ticket.</p></header>
<div class="stats">
<div class="stat"><span class="n">${t.count}</span><span class="k">Claims</span></div>
<div class="stat"><span class="n">${rupees(t.claim)}</span><span class="k">Claim value</span></div>
<div class="stat"><span class="n">${rupees(t.cogs)}</span><span class="k">COGS exposure</span></div>
<div class="stat"><span class="n">${rupees(t.comp)}</span><span class="k">Compensation</span></div>
<div class="stat"><span class="n">${t.photos}</span><span class="k">Proof photos</span></div>
</div>
<div class="claims">${cards}</div>
<footer>Generated ${esc(stamp())} by SPF Claim Extractor from partners.myntrainfo.com. Images load from Myntra's asset hosts, so keep this page online.</footer>
</div></body></html>`;
}

/* -------------------------------------------------------------------- view */

function renderStats() {
  const t = totals(rows);
  $('stats').innerHTML = [
    [t.count, 'Claims'],
    [rupees(t.claim), 'Claim value'],
    [rupees(t.cogs), 'COGS exposure'],
    [rupees(t.comp), 'Compensation'],
    [t.photos, 'Proof photos']
  ].map(([n, k]) => `<div class="stat"><span class="n">${esc(n)}</span><span class="k">${k}</span></div>`).join('');
  $('stats').hidden = false;
}

function renderBreakdown() {
  const key = opts.status === 'REJECT' ? 'rejectionReason' : 'issueCategory';
  $('breakdownTitle').textContent =
    key === 'rejectionReason' ? 'Why they were rejected' : 'By issue category';
  const groups = groupBy(rows, key);
  if (!groups.length) return;
  const max = groups[0][1].value || 1;
  $('bars').innerHTML = groups.map(([k, g]) =>
    `<li><span>${esc(k)}</span><span class="bt"><i style="width:${(g.value / max * 100).toFixed(1)}%"></i></span>
     <span class="bv">${g.n} · ${rupees(g.value)}</span></li>`).join('');
  $('breakdown').hidden = false;
}

function renderClaims() {
  $('claims').innerHTML = rows.map(r => {
    const shots = [];
    if (r.labelProof) shots.push([r.labelProof, 'Shipping label']);
    r.proofs.forEach((u, i) => shots.push([u, `Proof ${i + 1}`]));
    const facts = [
      ['Order ID', r.orderId], ['Order line ID', r.orderLineId], ['Return ID', r.returnId || '—'],
      ['Forward tracking', r.fwdTracking || '—'], ['Return tracking', r.returnTracking || '—'],
      ['Style ID', r.styleId], ['Seller SKU', r.skuId], ['Warehouse', r.warehouseId],
      ['Order delivered', r.orderDelivered || '—'], ['Return POD', r.podDate || '—'],
      ['Claim raised', r.claimCreated || '—'], ['Claim updated', r.claimUpdated || '—']
    ];
    const rejected = /reject/i.test(r.status);
    return `<article class="claim${rejected ? ' rejected' : ''}">
  <div class="chead"><div><span class="tk">Ticket ${esc(r.ticketId)}</span>
    <h3>${esc(r.productName)}</h3>
    <p class="sub">${esc(r.brand)} · ${esc(r.articleType)} · ${esc(r.issueCategory)}${r.returnReason ? ' · ' + esc(r.returnReason) : ''}</p></div>
    <div class="money"><span class="amt">${rupees(parseFloat(r.claimAmount) || 0)}</span>
      <span class="cogs">COGS ${rupees(parseFloat(r.cogs) || 0)} · MRP ${rupees(parseFloat(r.mrp) || 0)}</span></div>
  </div>
  <span class="chip${rejected ? '' : ' ok'}">${esc(r.status)}</span><span class="reason">${esc(r.rejectionReason || '')}</span>
  <div class="body">
    <div class="orig"><span class="cap">Dispatched product</span>
      <img class="shot" src="${esc(r.productImage)}" alt="${esc(r.productName)}" data-cap="Ticket ${esc(r.ticketId)} · catalogue image" loading="lazy"></div>
    <dl class="grid">${facts.map(([k, v]) => `<div class="f"><dt>${k}</dt><dd>${esc(v)}</dd></div>`).join('')}</dl>
  </div>
  <section class="proofs"><span class="cap">Seller proof — ${shots.length} photo${shots.length === 1 ? '' : 's'}</span>
    <div class="strip">${shots.map(([u, c]) => `<figure class="thumb"><img class="shot" src="${esc(u)}" alt="${c}" data-cap="Ticket ${esc(r.ticketId)} · ${c}" loading="lazy"><figcaption>${c}</figcaption></figure>`).join('')}</div>
  </section>
  ${r.description ? `<p class="desc">${esc(r.description)}</p>` : ''}
</article>`;
  }).join('');
}

document.addEventListener('click', e => {
  const img = e.target.closest('img.shot');
  if (!img) return;
  $('lbImg').src = img.src;
  $('lbCap').textContent = img.dataset.cap || '';
  $('lb').showModal();
});
$('lbClose').addEventListener('click', () => $('lb').close());
$('lb').addEventListener('click', e => { if (e.target === $('lb')) $('lb').close(); });

$('btnCsv').addEventListener('click', downloadCSV);
$('btnSheet').addEventListener('click', copySheetRows);
$('btnDossier').addEventListener('click', downloadDossier);
$('btnZip').addEventListener('click', downloadPhotos);

/* --------------------------------------------------------------------- run */

(async function run() {
  $('scope').textContent = `Myntra Seller Protection Fund · ${statusLabel} · ${opts.from} → ${opts.to}`;
  setBar(8);
  try {
    rows = await loadClaims();
  } catch (e) {
    stage('Stopped');
    log(e.message, 'err');
    $('headline').textContent = 'Could not read the claims';
    $('blurb').textContent = e.message;
    setBar(0);
    return;
  }

  if (!rows.length) {
    stage('Nothing to export');
    log('The portal returned no claims for that status and date range.');
    $('headline').textContent = 'No claims in that range';
    $('blurb').textContent = 'Try a wider date range or a different status.';
    setBar(100);
    return;
  }

  const t = totals(rows);
  log(`Found ${rows.length} ${statusLabel.toLowerCase()} claims worth ${rupees(t.claim)}.`, 'done');
  setBar(35);

  $('headline').textContent = `${rows.length} ${statusLabel.toLowerCase()} claims`;
  $('blurb').textContent = `${rupees(t.claim)} of claim value across ${t.photos} proof photos. Everything below came straight from the portal — nothing is typed by hand.`;
  renderStats(); renderBreakdown(); renderClaims();
  $('actions').hidden = false;

  downloadCSV();
  setBar(55);
  if (opts.dossier) { downloadDossier(); setBar(70); }
  if (opts.photos) { await downloadPhotos(); }
  setBar(100);
  stage('Done');
  log('Finished. Use “Copy rows for Google Sheets” to paste a sheet with live image cells.', 'done');
})();
