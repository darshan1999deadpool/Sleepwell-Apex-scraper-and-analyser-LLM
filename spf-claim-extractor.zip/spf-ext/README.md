# SPF Claim Extractor

A Chrome extension that does, in one click, what took a whole session by hand: reads
every Seller Protection Fund claim out of the open Myntra partner-portal tab and turns
it into a spreadsheet, a proof dossier and a folder of proof photos.

It never scrapes the screen. It calls the same `getTickets` endpoint the portal's own
JavaScript calls, from inside your logged-in tab, so it gets the complete record —
including fields the table doesn't show (COGS, claim value, return tracking ID,
rejection diagnostics, and the URL of every proof photo).

---

## Install

1. Unzip this folder somewhere permanent — Chrome loads it from disk every time, so
   don't leave it in Downloads.
2. Go to `chrome://extensions`.
3. Turn on **Developer mode** (top right).
4. Click **Load unpacked** and pick the `spf-ext` folder.
5. Pin the extension so the icon sits in your toolbar.

No sign-in, no account, no server. Everything runs locally in your browser.

## Use

1. Open <https://partners.myntrainfo.com/SPF> and sign in.
2. Click the extension icon.
3. Pick the status (**Rejected** by default), the date range (last 2 years by default),
   and whether you want the proof photos and the dossier.
4. Click **Extract claims**.

A results tab opens and does the rest: it pulls the claims, shows every one of them
with its catalogue image and proof photos, and saves the files as it goes.

## What you get

| Output | What it is |
| --- | --- |
| **`myntra-spf-…​.csv`** | One row per claim, 43 columns — every ID, tracking number, date, value, and the direct URL of each proof photo. |
| **`…​-dossier.html`** | A single self-contained page: each claim with the product that was dispatched, all the seller proof photos, and the tracking and value trail. Open it in any browser or send it to Partner Support. |
| **`…​-photos.zip`** | Every image, in one folder per claim named `<ticket>_order_<orderid>`, with the claim CSV alongside. |
| **Copy rows for Google Sheets** | Puts the whole table on your clipboard as TSV, with `=IMAGE()` cells for the catalogue shot and each proof. |

### The Google Sheets button is the important one

Pasting is not the same as importing. If you *import* a CSV containing `=IMAGE(...)`,
Google Sheets stores it as text and you get a column of formula strings. If you
**paste** the same thing, Sheets parses it and you get live pictures in the cells.

So: click **Copy rows for Google Sheets**, open a blank sheet, click cell A1, paste.
Then:

- Click **Allow access** on the yellow banner that appears — that is what lets Sheets
  fetch images from Myntra's servers. Nothing renders until you do.
- Select rows 2 onward → right-click the row numbers → **Resize rows** → 110 px, and
  widen column A to about 120 px, so the images are big enough to judge.

## Reading the output

For rejected claims the results page groups them by rejection reason and sizes each bar
by money at stake, so the expensive pattern is the one you see first. Watch for:

- **`Not eligible ticket raised beyond 7 days TAT`** — a filing-speed problem, entirely
  in your control.
- **`VMS not adopted`** — Myntra logs this reason under two or three different spellings,
  so it never groups cleanly in their own exports. This tool shows them as written; treat
  any variant containing "VMS" as the same bucket.
- **`Not eligible item not delivered to seller`** — check whether a return POD date exists
  at all before accepting it.

## Troubleshooting

**"Open partners.myntrainfo.com/SPF and sign in first"** — the extension borrows the
session from that tab. It has to be open somewhere in Chrome; it doesn't have to be the
tab in front.

**"Portal replied 401 / 403"** — your portal session expired. Reload the portal tab, sign
in again, and run it once more.

**Photos fail to download** — Myntra's asset host occasionally rate-limits. The failures
are logged by ticket number, and the ZIP still contains everything that did come through;
just run the photos step again from the button for a clean copy.

**Nothing found** — the portal only keeps two years of claims. Widen the dates, or check
you picked the right status.

## Files

```
manifest.json     permissions and entry points
popup.html/.js    the small settings panel behind the toolbar icon
runner.html/.js   the results tab: fetch, render, export
shared.js         field mapping, CSV/TSV builders, totals — the single source of truth
lib/jszip.min.js  ZIP writer (bundled, MIT)
```

If Myntra changes the API, `shared.js → normalise()` is the only place that maps their
field names to the columns; everything else works off the normalised record.
