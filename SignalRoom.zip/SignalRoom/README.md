# Signal Room — Chrome extension (v1.1)

Brand and competitor listening across YouTube, X, Instagram, Reddit and online news.
For each brand you enter a name and its handle on each platform. A platform is pulled
**only for brands that have a handle on it**.

Everything runs inside your Chrome. Keys and collected posts stay in this browser profile.

## What works without any key

| Platform | Without a key | With a key |
|---|---|---|
| News | Google News by brand name (GDELT optional) | — |
| YouTube | Each brand's own latest videos (YouTube's public channel feed): views, likes | Also other creators' videos about your brands, comments, subscriber counts |
| Instagram | Nothing: Instagram has no keyless access | Your connected account with reach/views/shares/saves; other brands' public business accounts; hashtags (after Meta approval) |
| X | Nothing: X only shares data through its paid API | Recent posts mentioning the brand, impressions, likes, replies, reposts |
| Reddit | Nothing: Reddit approves every API app | Posts mentioning the brand and the brand's own posts |

The **Readiness** panel at the top of Setup shows exactly what each platform will collect with what you've entered,
and **Run checks** tests every key and confirms each handle exists.

## What's new in 1.1

- YouTube works without a key for each brand's own channel videos.
- Status strip on the dashboard: one glance shows what each platform collected, and why not if it didn't.
- Collect now first lists what will and won't be collected when something needs access.
- Setup: Readiness table, Run checks, a status under every handle, step-by-step key guides, setup backup and restore.
- Faster: all platforms collect at the same time; the slow GDELT news source is optional (off by default).
- Fixed: reopening the extension showed the starter brands in Setup instead of your saved ones.
- Fixed: a brand renamed from a pre-filled one kept its old matching words (now flagged, with one-click clear).
- Fixed: a GDELT hiccup no longer marks News as a problem when Google News worked.

## Update from 1.0 (keeps your setup and data)

1. Unzip this file.
2. Open the folder Chrome loads Signal Room from (the one with `manifest.json`), and copy everything from the new `SignalRoom` folder into it. Choose **Replace the files in the destination**.
3. Go to `chrome://extensions` and click the reload arrow on the Signal Room card.
4. Open Signal Room → Setup and check your brands and handles, then press **Run checks**.

Don't load the new folder as a second extension: Chrome treats it as a new install with an empty setup.
(Setup → *Your data and setup backup* can move settings between installs from now on.)

## Fresh install

1. Unzip somewhere permanent, e.g. `Documents\SignalRoom`.
2. `chrome://extensions` → turn on **Developer mode** → **Load unpacked** → pick the folder with `manifest.json`.
3. Pin Signal Room from the puzzle-piece menu.

## Set up

1. **Brands and handles** — paste each brand's handle or profile link per platform. The line under each field says what will be used and whether it's ready.
   A pre-filled brand you rename keeps its *Advanced matching* words; the card warns you and offers **Clear advanced matching**.
2. **API access** — only for the platforms you want beyond News and YouTube channel videos. Each row has a step-by-step guide and **Test access**.
3. **Run checks**, then **Save**, then **Collect now** on the Dashboard.

**YouTube tip:** with no key, Signal Room looks up the channel ID from the @handle. If that lookup is ever blocked, paste the channel ID itself
(channel page → *…more* → *Share channel* → *Copy channel ID*). Example: `@BananaClub2011` is `UC_pjOZCvBV8eta0j74ihG_g`.

## Using the dashboard

- **Status strip** — click a platform to see its details or jump to what needs fixing.
- **Time slicer** — drag the handles or use 7D / 30D / 90D / All. Everything follows it.
- **Platform vs platform** — 17 measures side by side; ties count for each platform that ties.
- **Best content** — ranked by engagements, engagement rate (≥500 views), reach, comments or shares. YouTube videos play in the card; X and Instagram posts open in the card; every card links to the original.
- **Export CSV** — posts in the current filter. Setup exports everything.

## How the numbers work

- **Reach** = views (YouTube, your own Instagram posts) + impressions (X). Platforms that don't report reach show *n/a*; nothing is estimated.
- **Engagements** = likes + comments + shares + saves. Without a YouTube key, comments aren't available for videos.
- **Engagement rate** = engagements ÷ reach, using only posts that report reach.
- **Brand-owned** = posted by the brand's own handle; everything else is **earned**.
- **Exact matching** — each search result is re-checked for the brand's exact name, hashtag or @handle; off-target results are dropped and counted under Data sources.
- **Sentiment** — VADER scoring, identical to the Python reference implementation. Directional; weaker on Hinglish and sarcasm.

## Good to know

- Daily collection runs while Chrome is open.
- If an embedded player shows an error, use the card's **Open on …** link.
- Uninstalling deletes stored data. Export a CSV or a setup backup first.

## Credits

Sentiment: vaderSentiment-js (Apache-2.0, Comcast) with the vaderSentiment lexicon (MIT, C.J. Hutto) — see `src/vendor/`.
Fonts: Archivo and IBM Plex (SIL Open Font License) — see `fonts/`.
