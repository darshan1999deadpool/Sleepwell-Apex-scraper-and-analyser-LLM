// Settings: brands with a name and one handle per platform, API keys, collection options.
// A brand without a handle on a platform gets NO data from that platform.

export const PLATFORMS = ["youtube", "x", "instagram", "reddit"];
export const PLATFORM_LABEL = { youtube: "YouTube", x: "X", instagram: "Instagram", reddit: "Reddit", news: "News" };
export const MAX_BRANDS = 8;

export const DEFAULT_COLLECT = {
  windowDays: 7,
  autoDaily: false,
  dailyTime: "09:30",
  xMaxPosts: 100,
  xIncludeProfiles: true,
  xPostRate: 0.005,
  xUserRate: 0.01,
  news: true,
  gdelt: false,
  retentionDays: 180,
  region: "IN",
  language: "en",
};

export const DEFAULT_KEYS = { youtube: "", x: "", redditId: "", redditSecret: "", igToken: "", igBusinessId: "" };

let idCounter = 0;
export function newBrandId() {
  idCounter += 1;
  return "b" + Date.now().toString(36) + idCounter.toString(36);
}

export function emptyBrand(name = "", primary = false) {
  return {
    id: newBrandId(),
    name,
    primary,
    handles: { youtube: "", x: "", instagram: "", reddit: "" },
    keywords: [],
    hashtags: [],
    context: [],
    exclude: [],
  };
}

export function starterSettings() {
  const sleepwell = emptyBrand("Sleepwell", true);
  // "Sleepwell" / "#sleepwell" are also everyday goodnight wishes: require a product or customer word
  sleepwell.context = [
    "mattress", "pillow", "foam", "bed", "protector", "sheela", "comforter", "sofa", "topper",
    "order", "delivery", "customer care", "customer service", "refund", "warranty", "showroom", "store", "offer", "sale",
  ];
  sleepwell.keywords = ["Sheela Foam"];
  return {
    brands: [sleepwell, emptyBrand("Kurlon", true), emptyBrand("Wakefit"), emptyBrand("Duroflex"), emptyBrand("The Sleep Company")],
    keys: { ...DEFAULT_KEYS },
    collect: { ...DEFAULT_COLLECT },
  };
}

// ---------------------------------------------------------------- handles
const HANDLE_RULES = {
  x: { re: /^[A-Za-z0-9_]{1,15}$/, hint: "X usernames are 1–15 letters, numbers or underscores." },
  instagram: { re: /^[A-Za-z0-9._]{1,30}$/, hint: "Instagram usernames are up to 30 letters, numbers, dots or underscores." },
  reddit: { re: /^[A-Za-z0-9_-]{3,20}$/, hint: "Reddit usernames are 3–20 letters, numbers, - or _." },
  youtube: { re: /^(@[A-Za-z0-9._-]{3,30}|UC[A-Za-z0-9_-]{22})$/, hint: "Use the channel's @handle or its channel ID (starts with UC)." },
};

function asUrl(raw) {
  const s = raw.trim();
  if (/^https?:\/\//i.test(s)) return safeUrl(s);
  if (/^(www\.|m\.)?(youtube\.com|youtu\.be|x\.com|twitter\.com|instagram\.com|reddit\.com|old\.reddit\.com)\//i.test(s)) return safeUrl("https://" + s);
  return null;
}
function safeUrl(s) {
  try {
    return new URL(s);
  } catch {
    return null;
  }
}

/** Turns whatever the user pasted (handle, @handle, profile link) into a clean handle.
 *  Returns { handle, error }. Empty input -> { handle: "" } (platform skipped for that brand). */
export function parseHandle(platform, raw) {
  const input = String(raw ?? "").trim();
  if (!input) return { handle: "" };
  let h = input;
  const url = asUrl(input);
  if (url) {
    const host = url.hostname.replace(/^(www\.|m\.|old\.)/, "").toLowerCase();
    const parts = url.pathname.split("/").filter(Boolean);
    const wrongSite = {
      youtube: !["youtube.com", "youtu.be"].includes(host),
      x: !["x.com", "twitter.com"].includes(host),
      instagram: host !== "instagram.com",
      reddit: host !== "reddit.com",
    }[platform];
    if (wrongSite) return { handle: "", error: `That link isn't a ${PLATFORM_LABEL[platform]} profile.` };
    if (platform === "youtube") {
      if (parts[0] && parts[0].startsWith("@")) h = parts[0];
      else if (parts[0] === "channel" && parts[1]) h = parts[1];
      else return { handle: "", error: "Use the channel's @handle link (youtube.com/@name) or its /channel/UC… link." };
    } else if (platform === "reddit") {
      if ((parts[0] === "user" || parts[0] === "u") && parts[1]) h = parts[1];
      else return { handle: "", error: "Use a Reddit user link like reddit.com/user/name." };
    } else {
      h = parts[0] || "";
    }
  }
  h = decodeURIComponent(h).trim();
  if (platform === "reddit") h = h.replace(/^\/?u\//i, "");
  if (platform === "youtube") {
    if (!h.startsWith("@") && !/^UC[A-Za-z0-9_-]{22}$/.test(h)) h = "@" + h;
  } else {
    h = h.replace(/^@/, "");
  }
  const rule = HANDLE_RULES[platform];
  if (!rule.re.test(h)) return { handle: "", error: rule.hint };
  return { handle: h };
}

// ---------------------------------------------------------------- normalise + validate
const list = (v) =>
  (Array.isArray(v) ? v : String(v ?? "").split(","))
    .map((s) => String(s).trim())
    .filter(Boolean);

function clampNum(v, lo, hi, dflt) {
  const n = Number(v);
  if (!Number.isFinite(n)) return dflt;
  return Math.min(hi, Math.max(lo, n));
}

export function normalizeSettings(raw) {
  const r = raw && typeof raw === "object" ? raw : {};
  const collect = { ...DEFAULT_COLLECT, ...(r.collect || {}) };
  const out = {
    brands: (Array.isArray(r.brands) ? r.brands : []).slice(0, MAX_BRANDS).map((b) => ({
      id: String(b.id || newBrandId()),
      name: String(b.name || "").trim(),
      primary: !!b.primary,
      handles: Object.fromEntries(PLATFORMS.map((p) => [p, String((b.handles || {})[p] || "").trim()])),
      keywords: list(b.keywords),
      hashtags: list(b.hashtags).map((h) => h.replace(/^#/, "")),
      context: list(b.context),
      exclude: list(b.exclude),
    })),
    keys: Object.fromEntries(Object.keys(DEFAULT_KEYS).map((k) => [k, String((r.keys || {})[k] || "").trim()])),
    collect: {
      windowDays: Math.round(clampNum(collect.windowDays, 1, 30, 7)),
      autoDaily: !!collect.autoDaily,
      dailyTime: /^\d{2}:\d{2}$/.test(collect.dailyTime) ? collect.dailyTime : "09:30",
      xMaxPosts: Math.round(clampNum(collect.xMaxPosts, 10, 1000, 100)),
      xIncludeProfiles: collect.xIncludeProfiles !== false,
      xPostRate: clampNum(collect.xPostRate, 0, 1, 0.005),
      xUserRate: clampNum(collect.xUserRate, 0, 1, 0.01),
      news: collect.news !== false,
      gdelt: collect.gdelt === true,
      retentionDays: Math.round(clampNum(collect.retentionDays, 7, 730, 180)),
      region: /^[A-Z]{2}$/.test(String(collect.region || "").toUpperCase()) ? String(collect.region).toUpperCase() : "IN",
      language: /^[a-z]{2}$/.test(String(collect.language || "")) ? collect.language : "en",
    },
  };
  return out;
}

/** Returns [{ field, message }]. field is a stable string used by the setup form. */
export function validateSettings(s) {
  const errors = [];
  if (!s.brands.length) errors.push({ field: "brands", message: "Add at least one brand." });
  const seen = new Set();
  s.brands.forEach((b) => {
    if (!b.name) errors.push({ field: `brand:${b.id}:name`, message: "Brand name is required." });
    else if (seen.has(b.name.toLowerCase())) errors.push({ field: `brand:${b.id}:name`, message: "Another brand already has this name." });
    seen.add(b.name.toLowerCase());
    PLATFORMS.forEach((p) => {
      const { error } = parseHandle(p, b.handles[p]);
      if (error) errors.push({ field: `brand:${b.id}:${p}`, message: error });
    });
  });
  return errors;
}

/** Settings with every handle cleaned. Call after validateSettings() returned no errors. */
export function cleanHandles(s) {
  return {
    ...s,
    brands: s.brands.map((b) => ({
      ...b,
      handles: Object.fromEntries(PLATFORMS.map((p) => [p, parseHandle(p, b.handles[p]).handle || ""])),
    })),
  };
}

export const hasHandle = (brand, platform) => !!(brand.handles && brand.handles[platform]);
export const brandsOn = (settings, platform) => settings.brands.filter((b) => hasHandle(b, platform));

export function keysReady(settings, platform) {
  const k = settings.keys;
  if (platform === "youtube") return k.youtube ? [] : ["YouTube API key"];
  if (platform === "x") return k.x ? [] : ["X bearer token"];
  if (platform === "reddit") return [!k.redditId && "Reddit client ID", !k.redditSecret && "Reddit client secret"].filter(Boolean);
  if (platform === "instagram") return [!k.igToken && "Instagram access token", !k.igBusinessId && "Instagram business account ID"].filter(Boolean);
  return [];
}

/** How a platform can be collected with the keys in hand:
 *  full    — every source for that platform
 *  limited — YouTube without a key: each brand's own latest videos from the public channel feed
 *  none    — nothing can be pulled until the listed keys are added
 *  off     — News switched off in Setup */
export function accessMode(settings, platform) {
  if (platform === "news") return settings.collect.news ? { mode: "full", missing: [] } : { mode: "off", missing: [], reason: "Turned off in Setup." };
  const missing = keysReady(settings, platform);
  if (!missing.length) return { mode: "full", missing };
  if (platform === "youtube") {
    return { mode: "limited", missing, reason: "No API key: each brand's own latest videos only, from YouTube's public channel feed." };
  }
  return { mode: "none", missing, reason: `Needs the ${missing.join(" and ")}.` };
}

/** "a YouTube", "an X", "an Instagram", "a Reddit" */
export const withArticle = (label) => (/^[aeiou]/i.test(label) || /^X\b/.test(label) ? "an " : "a ") + label;

export const isChannelId = (h) => /^UC[A-Za-z0-9_-]{22}$/.test(String(h || ""));

/** The brand's default hashtag: its name, lowercased, letters and digits only. */
export function defaultHashtag(name) {
  return String(name || "").toLowerCase().replace(/[^\p{L}\p{N}_]+/gu, "");
}

export function brandHashtags(brand) {
  const tags = [defaultHashtag(brand.name), ...brand.hashtags.map((h) => h.toLowerCase())].filter(Boolean);
  return [...new Set(tags)];
}

export function brandKeywords(brand) {
  return [...new Set([brand.name, ...brand.keywords].filter(Boolean))];
}

/** Next local time HH:MM after `now`, as epoch ms. */
export function nextDailyTime(hhmm, now = Date.now()) {
  const [h, m] = hhmm.split(":").map(Number);
  const d = new Date(now);
  d.setHours(h, m, 0, 0);
  if (d.getTime() <= now) d.setDate(d.getDate() + 1);
  return d.getTime();
}
