// Decides which brands a post genuinely mentions.
// Platform search is fuzzy ("Sleepwell" also finds "sleep well"), so every result is
// re-checked against exact terms. Only brands that have a handle on the post's platform
// are eligible — no handle on a platform means no data from that platform.

import { brandHashtags, brandKeywords, hasHandle } from "./config.js";
import { fullText } from "./model.js";

const W = "[\\p{L}\\p{N}_]";
const cache = new Map();

function escapeRe(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

export function termRegex(term) {
  const t = String(term).trim().toLowerCase();
  if (cache.has(t)) return cache.get(t);
  let re;
  if (t.startsWith("#") || t.startsWith("@")) {
    re = new RegExp(`${escapeRe(t[0])}${escapeRe(t.slice(1))}(?!${W})`, "iu");
  } else if (/^u\//.test(t)) {
    re = new RegExp(`(?<!${W})/?${escapeRe(t)}(?!${W})`, "iu");
  } else {
    const parts = t.split(/[\s-]+/).filter(Boolean).map(escapeRe);
    re = new RegExp(`(?<!${W})${parts.join("[\\s\\-]+")}(?!${W})`, "iu");
  }
  cache.set(t, re);
  return re;
}

export const contains = (text, term) => !!String(term).trim() && termRegex(term).test(text);

export function brandTerms(brand, platform) {
  const terms = [...brandKeywords(brand), ...brandHashtags(brand).map((h) => "#" + h)];
  const h = (brand.handles && brand.handles[platform]) || "";
  if (h) {
    if (platform === "x" || platform === "instagram") terms.push("@" + h);
    if (platform === "youtube" && h.startsWith("@")) terms.push(h);
    if (platform === "reddit") terms.push("u/" + h);
  }
  const seen = new Set();
  return terms.filter((t) => t && !seen.has(t.toLowerCase()) && seen.add(t.toLowerCase()));
}

const norm = (s) => String(s || "").toLowerCase().replace(/^@/, "");

export function isOwnedBy(post, brand) {
  const extra = post.extra || {};
  if (extra.owned_by && extra.owned_by === brand.name) return true;
  const h = norm(brand.handles && brand.handles[post.platform]);
  if (!h) return false;
  if (post.platform === "youtube") {
    return h === norm(extra.channel_id) || (!!extra.channel_handle && h === norm(extra.channel_handle));
  }
  return h === norm(post.author);
}

/** Fills post.brands, post.matched_terms, post.content_type, post.owner_brand. */
export function matchPost(post, brands) {
  const haystack = `${fullText(post)}\n${(post.hashtags || []).map((t) => "#" + t).join(" ")}`;
  const matched = [];
  const terms = [];
  let owner = "";
  for (const brand of brands) {
    if (!hasHandle(brand, post.platform)) continue;
    const owned = isOwnedBy(post, brand);
    const forced = (post.extra || {}).force_brand === brand.name;
    const hits = brandTerms(brand, post.platform).filter((t) => contains(haystack, t));
    if (owned) owner = brand.name;
    if (!hits.length && !owned && !forced) continue;
    if (!owned && !forced) {
      if (brand.exclude.length && brand.exclude.some((x) => contains(haystack, x))) continue;
      // an @mention of the brand's own account is unambiguous; plain words and hashtags need a context word
      const mentionsHandle = hits.some((t) => t.startsWith("@") || t.startsWith("u/"));
      if (brand.context.length && !mentionsHandle && !brand.context.some((c) => contains(haystack, c))) continue;
    }
    matched.push(brand.name);
    for (const h of hits) if (!terms.includes(h)) terms.push(h);
    if (forced && !hits.length) terms.push("tagged @" + brand.handles.instagram);
  }
  post.brands = matched;
  post.matched_terms = terms;
  post.content_type = owner ? "owned" : "earned";
  post.owner_brand = owner;
  return post;
}

/** News: exact-phrase search already; keep the query brand and add others named in the headline. */
export function matchNews(item, brands, queryBrand) {
  const found = queryBrand ? [queryBrand] : [];
  for (const b of brands) {
    if (found.includes(b.name)) continue;
    if (brandKeywords(b).some((k) => contains(item.title, k)) && !(b.exclude.length && b.exclude.some((x) => contains(item.title, x)))) {
      found.push(b.name);
    }
  }
  item.brands = found;
  return item;
}
