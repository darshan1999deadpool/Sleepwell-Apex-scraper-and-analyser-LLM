// VADER sentiment (English social text). Directional: weaker on Hinglish and sarcasm.
// Emojis are swapped for their descriptions first, exactly as the Python reference does.
import SentimentIntensityAnalyzer from "../vendor/vader.js";
import EMOJI from "../vendor/vader-emoji.js";

export const POSITIVE_AT = 0.05;
export const NEGATIVE_AT = -0.05;

export function describeEmojis(text) {
  let out = "";
  let prevSpace = true;
  for (const ch of text) {
    const d = EMOJI[ch];
    if (d !== undefined) {
      if (!prevSpace) out += " ";
      out += d;
      prevSpace = false;
    } else {
      out += ch;
      prevSpace = ch === " ";
    }
  }
  return out.trim();
}

export function compound(text) {
  return SentimentIntensityAnalyzer.polarity_scores(describeEmojis(String(text || ""))).compound;
}

export function score(text) {
  const t = String(text || "").trim();
  if (!t) return [0, "neutral"];
  let c;
  try {
    c = Math.round(compound(t.slice(0, 3000)) * 10000) / 10000;
  } catch {
    return [0, "neutral"];
  }
  if (c >= POSITIVE_AT) return [c, "positive"];
  if (c <= NEGATIVE_AT) return [c, "negative"];
  return [c, "neutral"];
}
