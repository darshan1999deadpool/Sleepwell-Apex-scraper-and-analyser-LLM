// Fictional SAMPLE data so the dashboard can be explored before any key is set up.
// Nothing here is real; posts have no links.
import { emptyBrand } from "./config.js";
import { DAY, makePost, toIso } from "./model.js";
import { score } from "./sentiment.js";

function rng(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const PHRASES = {
  positive: [
    "Six months on the {b} mattress and my back pain is finally gone. Worth it.",
    "Unboxing the new {b} ortho range: firm, cool and zero smell. Loving it!",
    "{b} delivery was quick and the installer was super helpful. Great experience.",
    "Switched from coil to {b} memory foam, sleeping so much better now.",
    "Festive sale pick: {b} pillow and protector combo. Totally worth the price.",
  ],
  neutral: [
    "Comparing {b} vs others for a queen size, what thickness should I pick?",
    "Anyone tried the {b} hybrid? Looking at it for my parents.",
    "{b} launched a new pillow range this week, specs inside.",
    "Is the {b} 100-night trial actually 100 nights? Reading the fine print.",
  ],
  negative: [
    "{b} customer care hasn't replied in 10 days about my sagging mattress. Disappointed.",
    "Ordered from {b}, wrong size delivered and the return pickup keeps getting cancelled.",
    "The {b} topper started smelling after two weeks. Not happy at all.",
  ],
};
const OUTLETS = ["Northgate Times", "Harbour Business Review", "Metro Retail Journal", "The Home Desk", "Market Pulse Daily", "Consumer Bulletin"];
const HEADLINES = [
  "{b} expands its mattress range into tier-2 cities",
  "{b} reports strong festive-season demand for sleep products",
  "{b} bets on quick commerce for pillows and protectors",
  "How {b} is competing in India's online mattress market",
  "{b} announces new manufacturing capacity",
  "Customer complaints rise over {b} delivery delays",
];
const AUTHORS = ["sleepyreviewer", "homedecor_diaries", "techandhome", "desi_unboxer", "backpain_buddy", "nestingnotes", "the_room_edit", "budgethomes", "mom_of_two_blr", "gadgetguru_in"];
const WEIGHT = { "Lumen Sleep": 0.3, "Cotton Cloud": 0.14, "Driftwood Beds": 0.27, "Nimbus Rest": 0.17, "Haven Mattress": 0.12 };
const PF_WEIGHT = { youtube: 0.18, x: 0.3, instagram: 0.34, reddit: 0.18 };

function pick(r, weights) {
  const total = Object.values(weights).reduce((s, v) => s + v, 0);
  let x = r() * total;
  for (const [k, w] of Object.entries(weights)) {
    x -= w;
    if (x <= 0) return k;
  }
  return Object.keys(weights).pop();
}

export function sampleSettings() {
  const names = Object.keys(WEIGHT);
  const brands = names.map((n, i) => {
    const b = emptyBrand(n, i < 2);
    const slug = n.toLowerCase().replace(/\s+/g, "");
    b.handles = { youtube: "@" + slug, x: slug, instagram: slug + "_official", reddit: i === 4 ? "" : slug + "_team" };
    return b;
  });
  return { brands };
}

export function sampleState(endMs = Date.UTC(2026, 9, 15, 6, 0, 0), days = 60, seed = 42) {
  const r = rng(seed);
  const settings = sampleSettings();
  const posts = {};
  for (let i = 0; i < 640; i++) {
    const brand = pick(r, WEIGHT);
    let pf = pick(r, PF_WEIGHT);
    if (pf === "reddit" && brand === "Haven Mattress") pf = "x"; // no Reddit handle -> no Reddit data
    const tone = pick(r, { positive: 0.46, neutral: 0.36, negative: 0.18 });
    const list = PHRASES[tone];
    let text = list[Math.floor(r() * list.length)].replaceAll("{b}", brand);
    const brands = [brand];
    if (r() < 0.08) {
      const others = Object.keys(WEIGHT).filter((b) => b !== brand && !(pf === "reddit" && b === "Haven Mattress"));
      const other = others[Math.floor(r() * others.length)];
      text += ` Also looked at ${other}.`;
      brands.push(other);
    }
    const tag = "#" + brand.toLowerCase().replace(/\s+/g, "");
    text += ` ${tag} #mattress`;
    const owned = r() < 0.22;
    const slug = brand.toLowerCase().replace(/\s+/g, "");
    const author = owned ? (pf === "instagram" ? slug + "_official" : pf === "reddit" ? slug + "_team" : slug) : AUTHORS[Math.floor(r() * AUTHORS.length)];
    const published = endMs - r() * days * DAY * (1 - 0.35 * r());
    const boost = owned ? 3 : 1;
    const m = { views: null, likes: null, comments: null, shares: null, saves: null };
    let reachKind = null;
    let media = { type: "text" };
    if (pf === "youtube" || pf === "x") {
      const [lo, hi] = pf === "youtube" ? [800, 250000] : [150, 60000];
      const views = Math.floor((lo + (hi - lo) * r()) * r() ** 1.6 * boost) + lo;
      m.views = views;
      m.likes = Math.floor(views * (pf === "youtube" ? 0.02 + 0.025 * r() : 0.01 + 0.02 * r()));
      m.comments = Math.floor(views * (0.002 + 0.006 * r()));
      if (pf === "x") {
        m.shares = Math.floor(views * (0.002 + 0.008 * r()));
        m.saves = Math.floor(views * (0.0005 + 0.0025 * r()));
      }
      reachKind = pf === "youtube" ? "views" : "impressions";
      media = pf === "youtube" ? { type: "video", duration: `${1 + Math.floor(r() * 12)}:${String(Math.floor(r() * 60)).padStart(2, "0")}` } : { type: "post" };
    } else if (pf === "instagram") {
      m.likes = Math.floor((15 + 4485 * r()) * r() ** 1.4 * boost);
      m.comments = Math.floor(m.likes * (0.01 + 0.07 * r()));
      if (owned && brand === "Lumen Sleep") {
        m.views = Math.floor(m.likes / (0.015 + 0.035 * r()));
        m.shares = Math.floor(m.views * (0.001 + 0.005 * r()));
        m.saves = Math.floor(m.views * (0.002 + 0.007 * r()));
        reachKind = "views";
      }
      media = { type: r() < 0.55 ? "video" : "image" };
    } else {
      m.likes = Math.floor(900 * r() * r() ** 2);
      m.comments = Math.floor(160 * r() * r() ** 1.5);
      m.shares = [0, 0, 0, 1, 2][Math.floor(r() * 5)];
    }
    const p = makePost({
      platform: pf,
      id: `sample${String(i).padStart(4, "0")}`,
      url: "",
      published_at: toIso(published),
      author,
      author_followers: owned ? 40000 + Math.floor(r() * 560000) : r() < 0.5 ? null : 200 + Math.floor(r() * 90000),
      title: pf === "youtube" || pf === "reddit" ? text.slice(0, 70) : "",
      text,
      metrics: m,
      reach_kind: reachKind,
      brands,
      content_type: owned ? "owned" : "earned",
      owner_brand: owned ? brand : "",
      source: "sample",
      hashtags: [tag.slice(1), "mattress"],
      where: pf === "reddit" ? ["r/IndianHomes", "r/Mattress", "r/bangalore", "r/india"][Math.floor(r() * 4)] : "",
      media: { ...media, sample: true },
    });
    [p.sentiment, p.sentiment_label] = score(text);
    posts[p.uid] = p;
  }
  const news = {};
  for (let j = 0; j < 90; j++) {
    const brand = pick(r, WEIGHT);
    const title = HEADLINES[Math.floor(r() * HEADLINES.length)].replaceAll("{b}", brand);
    const [s, label] = score(title);
    const item = {
      id: `sample-news-${j}`, uid: `news:sample-news-${j}`, url: "", title, outlet: OUTLETS[Math.floor(r() * OUTLETS.length)],
      published_at: toIso(endMs - r() * days * DAY), brands: [brand], source: r() < 0.5 ? "google_news" : "gdelt", sentiment: s, sentiment_label: label,
    };
    news[item.uid] = item;
  }
  const count = (pf) => Object.values(posts).filter((p) => p.platform === pf).length;
  const status = {};
  for (const pf of ["youtube", "x", "instagram", "reddit"]) {
    const on = settings.brands.filter((b) => b.handles[pf]).map((b) => b.name);
    status[pf] = { status: "ok", message: `Sample data: ${count(pf)} posts from ${on.length} brands.`, notes: pf === "reddit" ? ["Haven Mattress has no Reddit handle, so no Reddit data was pulled for it."] : [], items: count(pf), brands: on };
  }
  status.news = { status: "ok", message: `Sample data: ${Object.keys(news).length} articles.`, notes: [], items: Object.keys(news).length, brands: settings.brands.map((b) => b.name) };
  return { settings, state: { posts, news, runs: [{ at: toIso(endMs) }], status } };
}
