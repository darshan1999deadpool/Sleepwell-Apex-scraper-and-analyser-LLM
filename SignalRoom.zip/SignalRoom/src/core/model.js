// Shared record shape + date helpers.

export const DAY = 86400000;

export function toIso(d) {
  const dt = d instanceof Date ? d : new Date(d);
  return dt.toISOString().replace(/\.\d{3}Z$/, "Z");
}

/** Parses ISO 8601, including Instagram's "+0000" offsets. Returns epoch ms or NaN. */
export function parseTime(s) {
  if (!s) return NaN;
  let v = String(s).trim();
  v = v.replace(/([+-]\d{2})(\d{2})$/, "$1:$2");
  return Date.parse(v);
}

export const num = (v) => {
  if (v === null || v === undefined || v === "") return null;
  const n = Number(v);
  return Number.isFinite(n) ? Math.round(n) : null;
};

export const nz = (v) => (v ? Number(v) : 0);

export function engagements(m) {
  m = m || {};
  return nz(m.likes) + nz(m.comments) + nz(m.shares) + nz(m.saves);
}

const HASHTAG_RE = /#([\p{L}\p{N}_]+)/gu;

export function makePost(fields) {
  const p = {
    platform: "",
    id: "",
    url: "",
    published_at: "",
    author: "",
    author_followers: null,
    title: "",
    text: "",
    metrics: { views: null, likes: null, comments: null, shares: null, saves: null },
    reach_kind: null,
    brands: [],
    matched_terms: [],
    content_type: "earned",
    owner_brand: "",
    source: "",
    sentiment: 0,
    sentiment_label: "neutral",
    hashtags: [],
    media: { type: "text", thumb: "", src: "", embed: "", duration: "" },
    where: "",
    extra: {},
    ...fields,
  };
  p.metrics = { views: null, likes: null, comments: null, shares: null, saves: null, ...(fields.metrics || {}) };
  p.media = { type: "text", thumb: "", src: "", embed: "", duration: "", ...(fields.media || {}) };
  p.uid = `${p.platform}:${p.id}`;
  return p;
}

export function fullText(p) {
  return `${p.title || ""}\n${p.text || ""}`.trim();
}

export function collectHashtags(p) {
  const tags = new Set((p.hashtags || []).map((t) => t.toLowerCase()));
  for (const m of fullText(p).matchAll(HASHTAG_RE)) tags.add(m[1].toLowerCase());
  p.hashtags = [...tags].sort();
  return p;
}

/** ISO 8601 duration (PT1H2M3S) -> "1:02:03" */
export function formatDuration(iso) {
  const m = /^P(?:(\d+)D)?T?(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$/.exec(iso || "");
  if (!m) return "";
  const h = Number(m[1] || 0) * 24 + Number(m[2] || 0);
  const mm = Number(m[3] || 0);
  const ss = Number(m[4] || 0);
  const pad = (n) => String(n).padStart(2, "0");
  return h ? `${h}:${pad(mm)}:${pad(ss)}` : `${mm}:${pad(ss)}`;
}
