// Diagnostics: tests every key and confirms each brand's handle can actually be read,
// so a setup problem shows up here instead of as an empty dashboard.
import { collectionPlan, CONNECTORS } from "./collect.js";
import { brandsOn } from "./config.js";
import { ApiError, createHttp } from "./http.js";

const msg = (e) => (e instanceof ApiError ? e.detail : `Unexpected error: ${(e && e.message) || e}`);

/** Returns rows: { platform, brand, ok: true | false | null, detail }. ok null = informational. */
export async function diagnose(settings, { fetchImpl, sleep, cache = {}, onRow = () => {} } = {}) {
  const rows = [];
  const push = (r) => {
    rows.push(r);
    onRow(r);
  };
  for (const step of collectionPlan(settings)) {
    const p = step.platform;
    if (step.state === "no-handles" || step.state === "off") {
      push({ platform: p, brand: "", ok: null, detail: step.reason });
      continue;
    }
    if (step.state === "needs-access") {
      push({ platform: p, brand: "", ok: false, detail: `Can't be pulled yet. ${step.reason}` });
      continue;
    }
    const http = createHttp(p, { fetchImpl, sleep, retries: 1, timeoutMs: 30000 });
    if (p === "news") {
      const gHttp = createHttp(p, { fetchImpl, sleep, retries: 0, timeoutMs: 30000, minInterval: 5500 });
      for (const r of await CONNECTORS.news.checkSources(settings, settings.brands[0], http, gHttp, sleep || ((ms) => new Promise((res) => setTimeout(res, ms))))) {
        push({ platform: p, brand: settings.brands[0].name, ...r });
      }
      continue;
    }
    if (step.state === "limited") {
      push({ platform: p, brand: "", ok: null, detail: step.reason });
    } else if (p === "x") {
      push({ platform: p, brand: "", ok: null, detail: "Token saved. X bills every lookup, so it isn't tested here; use Test access in API access (billed as one request)." });
      continue;
    } else {
      try {
        push({ platform: p, brand: "", ok: true, detail: await CONNECTORS[p].check(settings.keys, http, brandsOn(settings, p)[0]) });
      } catch (e) {
        push({ platform: p, brand: "", ok: false, detail: `Key problem: ${msg(e)}` });
        continue;
      }
    }
    for (const brand of brandsOn(settings, p)) {
      try {
        const r = await CONNECTORS[p].checkHandle(settings, brand, http, cache[p === "youtube" ? "ytChannel" : p] || {});
        push({ platform: p, brand: brand.name, ...r });
      } catch (e) {
        push({ platform: p, brand: brand.name, ok: false, detail: msg(e) });
      }
    }
  }
  return rows;
}
