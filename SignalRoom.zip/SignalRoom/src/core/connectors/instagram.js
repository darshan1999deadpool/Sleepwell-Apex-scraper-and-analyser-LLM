// Instagram Graph API (Instagram Business/Creator account linked to a Meta app).
//   * the connected account's own posts, with insights (views, reach, shares, saves)
//   * other brands' business accounts via business_discovery (likes, comments)
//   * hashtag search (needs Meta's "Instagram Public Content Access" approval; 30 hashtags / 7 days)
//   * posts that tag the connected account
// Only brands with an Instagram handle in Setup are pulled.
import { brandHashtags } from "../config.js";
import { ApiError } from "../http.js";
import { makePost, num, parseTime, toIso } from "../model.js";

const GRAPH = "https://graph.facebook.com/v25.0";
const HASHTAG_LIMIT = 30;

const FULL_FIELDS = "id,caption,media_type,media_product_type,comments_count,like_count,permalink,timestamp,media_url,thumbnail_url";
const MID_FIELDS = "id,caption,media_type,comments_count,like_count,permalink,timestamp,media_url";
const BASIC_FIELDS = "id,caption,media_type,comments_count,like_count,permalink,timestamp";
const HASHTAG_FIELDS = "id,caption,media_type,comments_count,like_count,permalink,timestamp,media_url";

const lc = (s) => String(s || "").toLowerCase().replace(/^@/, "");
const isFieldError = (e) => e instanceof ApiError && e.status === 400 && /field|param|#100/i.test(e.detail);

export async function check(keys, http) {
  const data = await http.get(`${GRAPH}/${encodeURIComponent(keys.igBusinessId)}`, {
    params: { fields: "username,followers_count", access_token: keys.igToken },
  });
  return `Connected as @${data.username} (${data.followers_count ?? "?"} followers).`;
}

/** Confirms one brand's Instagram handle can be read. Returns { ok, detail }. */
export async function checkHandle(settings, brand, http) {
  const token = settings.keys.igToken;
  const igId = encodeURIComponent(settings.keys.igBusinessId);
  const h = brand.handles.instagram;
  const acct = await http.get(`${GRAPH}/${igId}`, { params: { fields: "username", access_token: token } });
  if (lc(acct.username) === lc(h)) return { ok: true, detail: `@${h} is your connected account: its posts come with reach, views, shares and saves.` };
  try {
    const data = await http.get(`${GRAPH}/${igId}`, { params: { fields: `business_discovery.username(${h}){username,followers_count,media_count}`, access_token: token } });
    const bd = data.business_discovery || {};
    return { ok: true, detail: `Found @${bd.username || h}: ${Number(bd.followers_count || 0).toLocaleString("en-IN")} followers, ${bd.media_count ?? "?"} posts. Likes and comments only (Meta hides reach for other accounts).` };
  } catch (e) {
    if (!(e instanceof ApiError)) throw e;
    return { ok: false, detail: `@${h} can't be read: ${e.detail} It must be a public Business or Creator account, and the handle must be exact.` };
  }
}

function embedUrl(permalink) {
  if (!/^https:\/\/(www\.)?instagram\.com\//.test(permalink || "")) return "";
  return permalink.replace(/\?.*$/, "").replace(/\/?$/, "/") + "embed/";
}

function toPost(m, author, followers, source, extra = {}) {
  const t = parseTime(m.timestamp);
  if (!Number.isFinite(t)) return null;
  const isVideo = m.media_type === "VIDEO" || m.media_product_type === "REELS";
  const type = isVideo ? "video" : m.media_type === "CAROUSEL_ALBUM" ? "carousel" : "image";
  return makePost({
    platform: "instagram",
    id: String(m.id),
    url: m.permalink || "",
    published_at: toIso(t),
    author: author || "",
    author_followers: followers ?? null,
    text: m.caption || "",
    metrics: { views: null, likes: num(m.like_count), comments: num(m.comments_count), shares: null, saves: null },
    reach_kind: null,
    source,
    where: m.media_product_type === "REELS" ? "Reel" : type === "carousel" ? "Carousel" : isVideo ? "Video" : "Photo",
    media: {
      type,
      src: isVideo ? m.media_url || "" : "",
      thumb: isVideo ? m.thumbnail_url || "" : m.media_url || "",
      embed: embedUrl(m.permalink),
    },
    extra,
  });
}

export async function collect(ctx) {
  const { brands, http, settings, since, result } = ctx;
  const token = settings.keys.igToken;
  const igId = encodeURIComponent(settings.keys.igBusinessId);
  const get = (path, params) => http.get(`${GRAPH}/${path}`, { params: { ...params, access_token: token } });
  const seen = new Set();
  let failures = 0;
  const keep = (m) => {
    if (!m || !m.id || seen.has(m.id) || !m.timestamp) return false;
    if (parseTime(m.timestamp) < since) return false;
    seen.add(m.id);
    return true;
  };
  const push = (p) => p && result.posts.push(p);

  const account = await get(igId, { fields: "username,followers_count" });
  const me = lc(account.username);
  const accountBrand = brands.find((b) => lc(b.handles.instagram) === me);

  if (accountBrand) {
    // 1. own posts with insights
    try {
      let data = null;
      for (const fields of [FULL_FIELDS, MID_FIELDS, BASIC_FIELDS]) {
        try {
          data = await get(`${igId}/media`, { fields, limit: 50 });
          break;
        } catch (e) {
          if (!isFieldError(e) || fields === BASIC_FIELDS) throw e;
        }
      }
      for (const m of (data && data.data) || []) {
        if (!keep(m)) continue;
        const post = toPost(m, account.username, account.followers_count, "own_account", { owned_by: accountBrand.name });
        if (!post) continue;
        const ins = await insights(get, m.id);
        if (Object.keys(ins).length) {
          const views = ins.views ?? ins.reach ?? null;
          post.metrics.views = num(views);
          post.metrics.shares = num(ins.shares);
          post.metrics.saves = num(ins.saved);
          post.reach_kind = ins.views != null ? "views" : ins.reach != null ? "reach" : null;
          post.extra.reach_unique = num(ins.reach);
        }
        push(post);
      }
    } catch (e) {
      if (!(e instanceof ApiError)) throw e;
      failures++;
      result.notes.push(`Your own posts: ${e.detail}`);
    }
    // 4. posts tagging the account
    try {
      const data = await get(`${igId}/tags`, { fields: BASIC_FIELDS + ",username", limit: 50 });
      for (const m of data.data || []) if (keep(m)) push(toPost(m, m.username || "", null, "tagged", { force_brand: accountBrand.name }));
    } catch (e) {
      if (!(e instanceof ApiError)) throw e;
      failures++;
      result.notes.push(`Posts tagging @${account.username}: ${e.detail}`);
    }
  } else {
    result.notes.push(`The connected account @${account.username} isn't any brand's Instagram handle in Setup, so its own posts and tags were skipped.`);
  }

  // 2. other brands' business accounts
  for (const brand of brands) {
    if (brand === accountBrand) continue;
    const h = brand.handles.instagram;
    try {
      let bd = null;
      for (const fields of [MID_FIELDS, BASIC_FIELDS]) {
        try {
          const data = await get(igId, { fields: `business_discovery.username(${h}){username,followers_count,media.limit(25){${fields}}}` });
          bd = data.business_discovery || {};
          break;
        } catch (e) {
          if (!isFieldError(e) || fields === BASIC_FIELDS) throw e;
        }
      }
      for (const m of (bd.media && bd.media.data) || []) if (keep(m)) push(toPost(m, bd.username || h, bd.followers_count, `handle:${brand.name}`));
    } catch (e) {
      if (!(e instanceof ApiError)) throw e;
      failures++;
      result.notes.push(`@${h} (${brand.name}): ${e.detail}${e.status === 400 ? " The account must be a public Business or Creator account." : ""}`);
    }
  }

  // 3. hashtag search
  const tags = [];
  for (const b of brands) for (const t of brandHashtags(b)) if (!tags.includes(t)) tags.push(t);
  if (tags.length > HASHTAG_LIMIT) {
    result.notes.push(`Instagram allows ${HASHTAG_LIMIT} unique hashtags per 7 days; searched the first ${HASHTAG_LIMIT} of ${tags.length}.`);
    tags.length = HASHTAG_LIMIT;
  }
  for (const tag of tags) {
    try {
      const found = await get("ig_hashtag_search", { user_id: settings.keys.igBusinessId, q: tag });
      const hid = found.data && found.data[0] && found.data[0].id;
      if (!hid) continue;
      for (const edge of ["top_media", "recent_media"]) {
        const data = await get(`${encodeURIComponent(hid)}/${edge}`, { user_id: settings.keys.igBusinessId, fields: HASHTAG_FIELDS, limit: 50 });
        for (const m of data.data || []) if (keep(m)) push(toPost(m, "", null, `hashtag:#${tag}`));
      }
    } catch (e) {
      if (!(e instanceof ApiError)) throw e;
      failures++;
      if ((e.status === 400 || e.status === 403) && /permission|access|#10\b|approved/i.test(e.detail)) {
        result.notes.push("Hashtag search needs Meta's Instagram Public Content Access approval — skipped hashtags until it's approved.");
        break;
      }
      result.notes.push(`#${tag}: ${e.detail}`);
    }
  }

  if (failures) {
    result.status = result.posts.length ? "partial" : "error";
    result.message = `${result.posts.length} posts; ${failures} source(s) had problems — see notes`;
  }
}

async function insights(get, mediaId) {
  for (const metric of ["reach,views,shares,saved", "reach,saved", "reach"]) {
    try {
      const data = await get(`${encodeURIComponent(mediaId)}/insights`, { metric });
      const out = {};
      for (const row of data.data || []) {
        if (row.values && row.values.length) out[row.name] = row.values[0].value;
        else if (row.total_value) out[row.name] = row.total_value.value;
      }
      if (Object.keys(out).length) return out;
    } catch (e) {
      if (!(e instanceof ApiError)) throw e;
    }
  }
  return {};
}
