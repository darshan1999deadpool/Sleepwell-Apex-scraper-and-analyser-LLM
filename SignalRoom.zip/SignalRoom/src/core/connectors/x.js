// X API v2 recent search (last 7 days). Pay-per-use: billed per post and profile returned.
// views = impressions, comments = replies, shares = reposts + quotes, saves = bookmarks.
import { brandHashtags, brandKeywords } from "../config.js";
import { DAY, makePost, num, parseTime, toIso } from "../model.js";

const API = "https://api.x.com/2";
const MAX_QUERY = 512;

export function buildQuery(brand, excludeRetweets = true) {
  const terms = brandKeywords(brand).map((k) => (/\s/.test(k) ? `"${k.replace(/"/g, "")}"` : k));
  for (const h of brandHashtags(brand)) terms.push("#" + h);
  const handle = brand.handles.x;
  if (handle) terms.push("@" + handle, "from:" + handle);
  const suffix = excludeRetweets ? " -is:retweet" : "";
  while (terms.length) {
    const q = "(" + terms.join(" OR ") + ")" + suffix;
    if (q.length <= MAX_QUERY) return q;
    terms.pop();
  }
  return `"${brand.name}"${suffix}`;
}

export async function check(keys, http, sampleBrand) {
  const q = sampleBrand ? buildQuery(sampleBrand) : "from:XDevelopers";
  const data = await http.get(`${API}/tweets/counts/recent`, {
    params: { query: q, granularity: "day" },
    headers: { Authorization: `Bearer ${keys.x}` },
  });
  const total = data.meta && data.meta.total_tweet_count;
  return `Token works${total != null ? ` (${total} matching posts in the last 7 days)` : ""}. This check is billed as one counts request.`;
}

export async function collect(ctx) {
  const { brands, http, settings, since, now, result } = ctx;
  const c = settings.collect;
  const headers = { Authorization: `Bearer ${settings.keys.x}` };
  const budget = Math.max(10, c.xMaxPosts);
  const start = Math.max(since, now - 7 * DAY + 5 * 60000);
  if (c.windowDays > 7) result.notes.push("X search only reaches back 7 days; daily collection builds up longer history.");

  const perBrand = Math.max(10, Math.floor(budget / Math.max(1, brands.length)));
  let postsRead = 0;
  let usersRead = 0;
  const seen = new Set();

  for (const brand of brands) {
    let remaining = Math.min(perBrand, budget - postsRead);
    let next = null;
    while (remaining >= 10) {
      const params = {
        query: buildQuery(brand, true),
        start_time: toIso(start),
        max_results: Math.min(100, remaining),
        "tweet.fields": "created_at,public_metrics,author_id,lang,entities",
      };
      if (c.xIncludeProfiles) {
        params.expansions = "author_id";
        params["user.fields"] = "username,name,public_metrics";
      }
      if (next) params.next_token = next;
      const data = await http.get(`${API}/tweets/search/recent`, { params, headers });
      const tweets = data.data || [];
      const users = Object.fromEntries(((data.includes && data.includes.users) || []).map((u) => [u.id, u]));
      postsRead += tweets.length;
      usersRead += Object.keys(users).length;
      remaining -= tweets.length;
      for (const t of tweets) {
        if (seen.has(t.id)) continue;
        seen.add(t.id);
        const post = toPost(t, users[t.author_id], brand.name);
        if (post) result.posts.push(post);
      }
      next = data.meta && data.meta.next_token;
      if (!next || !tweets.length) break;
    }
    if (postsRead >= budget) {
      result.notes.push(`Stopped at the per-run cap of ${budget} posts (Setup → X posts per run).`);
      break;
    }
  }
  result.estCostUsd = postsRead * c.xPostRate + usersRead * c.xUserRate;
  result.notes.push(`Read ${postsRead} posts and ${usersRead} profiles ≈ $${result.estCostUsd.toFixed(2)} at the rates in Setup.`);
}

function toPost(t, user, brandName) {
  const time = parseTime(t.created_at);
  if (!Number.isFinite(time)) return null;
  const pm = t.public_metrics || {};
  const username = (user && user.username) || "";
  const rt = pm.retweet_count;
  const qt = pm.quote_count;
  const tags = ((t.entities && t.entities.hashtags) || []).map((h) => String(h.tag || "").toLowerCase()).filter(Boolean);
  return makePost({
    platform: "x",
    id: String(t.id),
    url: username ? `https://x.com/${username}/status/${t.id}` : `https://x.com/i/web/status/${t.id}`,
    published_at: toIso(time),
    author: username,
    author_followers: user && user.public_metrics ? num(user.public_metrics.followers_count) : null,
    text: t.text || "",
    metrics: {
      views: num(pm.impression_count),
      likes: num(pm.like_count),
      comments: num(pm.reply_count),
      shares: rt == null && qt == null ? null : (num(rt) || 0) + (num(qt) || 0),
      saves: num(pm.bookmark_count),
    },
    reach_kind: "impressions",
    source: `search:${brandName}`,
    hashtags: [...new Set(tags)],
    media: { type: "post", embed: `https://platform.twitter.com/embed/Tweet.html?id=${encodeURIComponent(t.id)}&dnt=true` },
    extra: { lang: t.lang || "" },
  });
}
