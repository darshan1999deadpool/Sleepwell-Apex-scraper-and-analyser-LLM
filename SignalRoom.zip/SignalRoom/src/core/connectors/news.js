// Online news: Google News RSS (primary) and the GDELT DOC API (secondary). No keys.
// GDELT is slow and rate-limited (one request per 5 seconds), so it is paced, retried once,
// and treated as optional: if Google News worked for a brand, a GDELT failure is only a note.
import { brandKeywords } from "../config.js";
import { ApiError } from "../http.js";
import { toIso } from "../model.js";
import { parseRss } from "../rss.js";

const GOOGLE = "https://news.google.com/rss/search";
const GDELT = "https://api.gdeltproject.org/api/v2/doc/doc";
const GDELT_GAP_MS = 5500;

export function newsQuery(brand, withContext = false) {
  const names = brandKeywords(brand).map((k) => `"${k.replace(/"/g, "")}"`);
  let q = names.length > 1 ? `(${names.join(" OR ")})` : names[0];
  if (withContext && brand.context.length) {
    q += ` (${brand.context.slice(0, 8).map((c) => (/\s/.test(c) ? `"${c}"` : c)).join(" OR ")})`;
  }
  return q;
}

function hash(s) {
  // FNV-1a, 2 x 32 bit -> 16 hex chars
  let h1 = 0x811c9dc5, h2 = 0x01000193 ^ 0x5bd1e995;
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    h1 = Math.imul(h1 ^ c, 0x01000193) >>> 0;
    h2 = Math.imul(h2 ^ c, 0x5bd1e995) >>> 0;
  }
  return h1.toString(16).padStart(8, "0") + h2.toString(16).padStart(8, "0");
}

const host = (u) => {
  try {
    return new URL(u).hostname.replace(/^www\./, "");
  } catch {
    return "";
  }
};

async function googleNews(http, brand, settings, since) {
  const { windowDays, region, language } = settings.collect;
  const xml = await http.get(GOOGLE, {
    params: { q: `${newsQuery(brand, true)} when:${windowDays}d`, hl: `${language}-${region}`, gl: region, ceid: `${region}:${language}` },
    expect: "text",
  });
  let items;
  try {
    items = parseRss(xml);
  } catch {
    throw new ApiError("news", "Google News returned something that isn't an RSS feed");
  }
  const out = [];
  for (const it of items.slice(0, 75)) {
    const t = Date.parse(it.pubDate);
    if (!it.link || !Number.isFinite(t) || t < since) continue;
    const suffix = it.source ? ` - ${it.source}` : "";
    const title = suffix && it.title.endsWith(suffix) ? it.title.slice(0, -suffix.length) : it.title;
    out.push({ id: hash(it.link), url: it.link, title, outlet: it.source || host(it.link), published_at: toIso(t), source: "google_news" });
  }
  return out;
}

async function gdelt(http, brand, settings, since, sleep) {
  const params = { query: newsQuery(brand), mode: "ArtList", format: "json", maxrecords: 75, timespan: `${Math.min(settings.collect.windowDays, 90)}d`, sort: "DateDesc" };
  let text = await http.get(GDELT, { params, expect: "text" });
  if (/limit requests/i.test(text)) {
    await sleep(GDELT_GAP_MS + 500);
    text = await http.get(GDELT, { params, expect: "text" });
  }
  let data;
  try {
    data = text.trim() ? JSON.parse(text) : {};
  } catch {
    throw new ApiError("news", `GDELT said: ${text.trim().slice(0, 140)}`);
  }
  const out = [];
  for (const a of data.articles || []) {
    const m = /^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})Z$/.exec(a.seendate || "");
    if (!a.url || !m) continue;
    const t = Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +m[6]);
    if (t < since) continue;
    out.push({ id: hash(a.url), url: a.url, title: String(a.title || "").trim(), outlet: a.domain || host(a.url), published_at: toIso(t), source: "gdelt" });
  }
  return out;
}

export async function collect(ctx) {
  const { brands, http, settings, since, result } = ctx;
  const gHttp = ctx.makeHttp ? ctx.makeHttp({ minInterval: GDELT_GAP_MS, timeoutMs: 45000, retries: 1 }) : http;
  const sleep = ctx.sleep || ((ms) => new Promise((r) => setTimeout(r, ms)));
  const seen = new Set();
  let brandsFailed = 0;
  let gdeltFailures = 0;
  const add = (item, brand) => {
    if (seen.has(item.id)) return;
    seen.add(item.id);
    item.brands = [brand.name];
    item.uid = "news:" + item.id;
    result.posts.push(item);
  };

  for (const brand of brands) {
    let googleOk = false;
    try {
      for (const it of await googleNews(http, brand, settings, since)) add(it, brand);
      googleOk = true;
    } catch (e) {
      if (!(e instanceof ApiError)) throw e;
      result.notes.push(`Google News (${brand.name}): ${e.detail}`);
    }
    let gdeltOk = false;
    if (settings.collect.gdelt) {
      try {
        for (const it of await gdelt(gHttp, brand, settings, since, sleep)) add(it, brand);
        gdeltOk = true;
      } catch (e) {
        if (!(e instanceof ApiError)) throw e;
        gdeltFailures++;
        if (!googleOk) result.notes.push(`GDELT (${brand.name}): ${e.detail}`);
      }
    }
    if (!googleOk && !gdeltOk) brandsFailed++;
  }
  ctx.extraCalls = (ctx.extraCalls || 0) + (gHttp === http ? 0 : gHttp.calls);
  if (gdeltFailures && brandsFailed < brands.length) {
    result.notes.push(`GDELT, the backup news source, didn't respond for ${gdeltFailures} of ${brands.length} brand${brands.length === 1 ? "" : "s"}; Google News covered ${brands.length - brandsFailed}.`);
  }
  if (brandsFailed) {
    result.status = brandsFailed === brands.length ? "error" : "partial";
    result.message = `${result.posts.length} articles; no news source answered for ${brandsFailed} brand${brandsFailed === 1 ? "" : "s"} — see notes`;
  }
}

/** Quick health check of both sources for Diagnostics. */
export async function checkSources(settings, brand, http, gHttp, sleep) {
  const since = Date.now() - settings.collect.windowDays * 86400000;
  const out = [];
  try {
    const n = (await googleNews(http, brand, settings, since)).length;
    out.push({ ok: true, detail: `Google News: ${n} articles for "${brand.name}" in the last ${settings.collect.windowDays} days.` });
  } catch (e) {
    out.push({ ok: false, detail: `Google News: ${e.detail || e.message}` });
  }
  if (!settings.collect.gdelt) return out;
  try {
    const n = (await gdelt(gHttp, brand, settings, since, sleep)).length;
    out.push({ ok: true, detail: `GDELT: ${n} articles.` });
  } catch (e) {
    out.push({ ok: null, detail: `GDELT (backup source) didn't respond: ${e.detail || e.message}. Google News is enough on its own.` });
  }
  return out;
}
