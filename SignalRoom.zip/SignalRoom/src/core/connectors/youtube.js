// YouTube.
//   With an API key (YouTube Data API v3): keyword/hashtag search for anyone's videos about the brand,
//   plus the brand's own channel uploads, with views, likes, comments and channel subscribers.
//   Without a key: each brand's own latest videos from YouTube's public channel feed
//   (the RSS feed YouTube advertises on every channel page), with views and likes.
import { brandHashtags, brandKeywords, isChannelId } from "../config.js";
import { ApiError } from "../http.js";
import { formatDuration, makePost, num, parseTime, toIso } from "../model.js";
import { decodeEntities } from "../rss.js";

const API = "https://www.googleapis.com/youtube/v3";
const SITE = "https://www.youtube.com";

export function buildQuery(brand) {
  const parts = brandKeywords(brand).map((k) => (/\s/.test(k) ? `"${k}"` : k));
  for (const h of brandHashtags(brand)) parts.push("#" + h);
  return parts.join("|");
}

function chunks(arr, n) {
  const out = [];
  for (let i = 0; i < arr.length; i += n) out.push(arr.slice(i, i + n));
  return out;
}

const embed = (id) => `https://www.youtube-nocookie.com/embed/${encodeURIComponent(id)}?autoplay=1&rel=0`;

// ---------------------------------------------------------------- public feed (no key)

/** Finds a channel ID in a channel page: the RSS link YouTube publishes for feed readers, else the canonical link. */
export function channelIdFromPage(html) {
  const s = String(html || "");
  const patterns = [
    /feeds\/videos\.xml\?channel_id=(UC[A-Za-z0-9_-]{22})/,
    /<link[^>]+rel="canonical"[^>]+href="https:\/\/www\.youtube\.com\/channel\/(UC[A-Za-z0-9_-]{22})"/,
    /"externalId":"(UC[A-Za-z0-9_-]{22})"/,
    /<meta[^>]+itemprop="(?:identifier|channelId)"[^>]+content="(UC[A-Za-z0-9_-]{22})"/,
  ];
  for (const re of patterns) {
    const m = re.exec(s);
    if (m) return m[1];
  }
  return null;
}

/** Resolves a handle (@name) or channel ID to a channel ID without an API key. Results are cached. */
export async function resolveChannelId(http, handle, cache = {}) {
  if (isChannelId(handle)) return handle;
  const key = String(handle).toLowerCase();
  if (cache[key]) return cache[key];
  const html = await http.get(`${SITE}/${encodeURIComponent(handle).replace(/^%40/, "@")}`, { expect: "text" });
  const id = channelIdFromPage(html);
  if (!id) {
    throw new ApiError("youtube", `couldn't find the channel ID for ${handle}. Paste the channel ID (starts with UC) into Setup instead: on the channel page, open "…more" → Share channel → Copy channel ID.`);
  }
  cache[key] = id;
  return id;
}

function tag(block, name) {
  const m = new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)</${name}>`).exec(block);
  return m ? decodeEntities(m[1].trim()) : "";
}
function attr(block, name, attribute) {
  const m = new RegExp(`<${name}\\b[^>]*\\b${attribute}="([^"]*)"`).exec(block);
  return m ? decodeEntities(m[1]) : "";
}

/** Parses YouTube's Atom channel feed (no DOMParser in service workers). */
export function parseFeed(xml) {
  const s = String(xml || "");
  if (!/<feed[\s>]/.test(s) || !/youtube/i.test(s)) throw new Error("not a YouTube channel feed");
  const head = s.split("<entry>")[0];
  const channel = { id: tag(head, "yt:channelId"), title: tag(head, "title") };
  const entries = [];
  const re = /<entry>([\s\S]*?)<\/entry>/g;
  let m;
  while ((m = re.exec(s))) {
    const e = m[1];
    const videoId = tag(e, "yt:videoId");
    if (!videoId) continue;
    const href = attr(e, 'link rel="alternate"', "href") || attr(e, "link", "href");
    entries.push({
      videoId,
      title: tag(e, "title"),
      published: tag(e, "published"),
      url: /^https:\/\/www\.youtube\.com\//.test(href) ? href : `${SITE}/watch?v=${videoId}`,
      thumb: attr(e, "media:thumbnail", "url"),
      description: tag(e, "media:description"),
      likes: attr(e, "media:starRating", "count"),
      views: attr(e, "media:statistics", "views"),
    });
  }
  return { channel, entries };
}

async function feedUploads(ctx, brand, http) {
  const { result, cache, retentionStart } = ctx;
  const id = await resolveChannelId(http, brand.handles.youtube, cache.ytChannel);
  const xml = await http.get(`${SITE}/feeds/videos.xml`, { params: { channel_id: id }, expect: "text" });
  let feed;
  try {
    feed = parseFeed(xml);
  } catch {
    throw new ApiError("youtube", `the channel feed for ${brand.handles.youtube} didn't come back as a feed`);
  }
  let kept = 0;
  for (const e of feed.entries) {
    const t = parseTime(e.published);
    if (!Number.isFinite(t) || t < retentionStart) continue;
    const thumb = /^https:\/\//.test(e.thumb) ? e.thumb.replace(/^https:\/\/i\d\.ytimg\.com\//, "https://i.ytimg.com/") : "";
    result.posts.push(makePost({
      platform: "youtube",
      id: e.videoId,
      url: e.url,
      published_at: toIso(t),
      author: feed.channel.title || brand.name,
      title: e.title,
      text: e.description,
      metrics: { views: num(e.views), likes: num(e.likes), comments: null, shares: null, saves: null },
      reach_kind: "views",
      source: `feed:${brand.name}`,
      where: e.url.includes("/shorts/") ? "Short" : "",
      media: { type: "video", thumb, embed: embed(e.videoId) },
      extra: { channel_id: id, owned_by: brand.name },
    }));
    kept++;
  }
  return kept;
}

// ---------------------------------------------------------------- checks

export async function check(keys, http) {
  const data = await http.get(`${API}/videos`, { params: { part: "id", chart: "mostPopular", maxResults: 1, regionCode: "IN", key: keys.youtube } });
  if (!Array.isArray(data.items)) throw new ApiError("youtube", "unexpected response");
  return "Key works.";
}

/** Confirms one brand's channel exists. Returns { ok, detail }. */
export async function checkHandle(settings, brand, http, cache = {}) {
  const h = brand.handles.youtube;
  if (settings.keys.youtube) {
    const data = await http.get(`${API}/channels`, {
      params: { part: "snippet,statistics", ...(isChannelId(h) ? { id: h } : { forHandle: h }), key: settings.keys.youtube },
    });
    const c = data.items && data.items[0];
    if (!c) return { ok: false, detail: `No channel found for ${h}.` };
    const subs = c.statistics && !c.statistics.hiddenSubscriberCount ? Number(c.statistics.subscriberCount) : null;
    return { ok: true, detail: `Found "${c.snippet.title}" (${c.id})${subs != null ? `, ${subs.toLocaleString("en-IN")} subscribers` : ""}.` };
  }
  const id = await resolveChannelId(http, h, cache);
  const feed = parseFeed(await http.get(`${SITE}/feeds/videos.xml`, { params: { channel_id: id }, expect: "text" }));
  const latest = feed.entries[0] ? new Date(parseTime(feed.entries[0].published)).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }) : null;
  return { ok: true, detail: `Found "${feed.channel.title || h}" (${id}) via the public feed: ${feed.entries.length} recent videos${latest ? `, latest ${latest}` : ""}.` };
}

// ---------------------------------------------------------------- collect

export async function collect(ctx) {
  const { brands, http, settings, since, result, mode } = ctx;
  ctx.cache = ctx.cache || {};
  ctx.cache.ytChannel = ctx.cache.ytChannel || {};
  ctx.retentionStart = ctx.now - settings.collect.retentionDays * 86400000;

  if (mode !== "full") {
    result.mode = "limited";
    let total = 0;
    let failed = 0;
    for (const brand of brands) {
      try {
        total += await feedUploads(ctx, brand, http);
      } catch (e) {
        if (!(e instanceof ApiError)) throw e;
        failed++;
        result.notes.push(`${brand.name}: ${e.detail}`);
      }
    }
    result.notes.unshift("No API key, so only each brand's own latest videos were pulled (public channel feed: views and likes). Add a YouTube API key in Setup to also find other creators' videos about your brands, with comments.");
    if (failed) {
      result.status = total ? "partial" : "error";
      result.message = `${total} videos; ${failed} channel(s) couldn't be read — see notes`;
    }
    return;
  }

  const key = settings.keys.youtube;
  const get = (path, params) => http.get(`${API}/${path}`, { params: { ...params, key } });
  const found = new Map();
  let stop = false;

  for (const brand of brands) {
    if (stop) break;
    try {
      const data = await get("search", {
        part: "snippet", q: buildQuery(brand), type: "video", order: "date", publishedAfter: toIso(since),
        maxResults: 50, regionCode: settings.collect.region, relevanceLanguage: settings.collect.language,
      });
      for (const it of data.items || []) {
        const vid = it.id && it.id.videoId;
        if (vid && !found.has(vid)) found.set(vid, { source: `search:${brand.name}` });
      }
    } catch (e) {
      if (!(e instanceof ApiError)) throw e;
      result.notes.push(`Search for ${brand.name}: ${e.detail}`);
      if (e.status === 403) stop = true; // quota used up: further searches would fail too
    }
  }

  for (const brand of brands) {
    const h = brand.handles.youtube;
    try {
      const ch = await get("channels", isChannelId(h) ? { part: "contentDetails", id: h } : { part: "contentDetails", forHandle: h });
      const item = ch.items && ch.items[0];
      const uploads = item && item.contentDetails && item.contentDetails.relatedPlaylists && item.contentDetails.relatedPlaylists.uploads;
      if (!uploads) {
        result.notes.push(`YouTube channel ${h} (${brand.name}) wasn't found — check the handle in Setup.`);
        continue;
      }
      ctx.cache.ytChannel[String(h).toLowerCase()] = item.id || ctx.cache.ytChannel[String(h).toLowerCase()];
      const page = await get("playlistItems", { part: "contentDetails", playlistId: uploads, maxResults: 50 });
      for (const it of page.items || []) {
        const cd = it.contentDetails || {};
        if (cd.videoId && cd.videoPublishedAt && parseTime(cd.videoPublishedAt) >= ctx.retentionStart) {
          found.set(cd.videoId, { source: `channel:${brand.name}`, owner: brand.name });
        }
      }
    } catch (e) {
      if (!(e instanceof ApiError)) throw e;
      // quota or API trouble: fall back to the public feed for the brand's own videos
      try {
        const n = await feedUploads(ctx, brand, ctx.feedHttp || http);
        result.notes.push(`Channel ${h} (${brand.name}): the API failed (${e.detail}); used the public feed instead (${n} videos).`);
      } catch (e2) {
        if (!(e2 instanceof ApiError)) throw e2;
        result.notes.push(`Channel ${h} (${brand.name}): ${e.detail}`);
      }
    }
  }

  const fromFeed = new Set(result.posts.map((p) => p.id));
  const ids = [...found.keys()].filter((id) => !fromFeed.has(id));
  const videos = [];
  for (const batch of chunks(ids, 50)) {
    const data = await get("videos", { part: "snippet,statistics,contentDetails", id: batch.join(","), maxResults: 50 });
    videos.push(...(data.items || []));
  }
  const channels = {};
  const channelIds = [...new Set(videos.map((v) => v.snippet && v.snippet.channelId).filter(Boolean))];
  for (const batch of chunks(channelIds, 50)) {
    const data = await get("channels", { part: "snippet,statistics", id: batch.join(","), maxResults: 50 });
    for (const c of data.items || []) {
      const st = c.statistics || {};
      channels[c.id] = {
        subscribers: st.hiddenSubscriberCount ? null : num(st.subscriberCount),
        handle: ((c.snippet && c.snippet.customUrl) || "").replace(/^@/, ""),
      };
    }
  }

  for (const v of videos) {
    const sn = v.snippet || {};
    const st = v.statistics || {};
    const ch = channels[sn.channelId] || {};
    const thumbs = sn.thumbnails || {};
    const thumb = (thumbs.maxres || thumbs.standard || thumbs.high || thumbs.medium || thumbs.default || {}).url || "";
    const t = parseTime(sn.publishedAt);
    if (!Number.isFinite(t)) continue;
    const meta = found.get(v.id) || {};
    result.posts.push(makePost({
      platform: "youtube",
      id: v.id,
      url: `${SITE}/watch?v=${encodeURIComponent(v.id)}`,
      published_at: toIso(t),
      author: sn.channelTitle || "",
      author_followers: ch.subscribers ?? null,
      title: sn.title || "",
      text: sn.description || "",
      metrics: { views: num(st.viewCount), likes: num(st.likeCount), comments: num(st.commentCount), shares: null, saves: null },
      reach_kind: "views",
      source: meta.source || "",
      hashtags: (sn.tags || []).filter((x) => !/\s/.test(x)).map((x) => x.toLowerCase()),
      media: { type: "video", thumb, embed: embed(v.id), duration: formatDuration((v.contentDetails || {}).duration) },
      extra: { channel_id: sn.channelId || "", channel_handle: ch.handle || "", ...(meta.owner ? { owned_by: meta.owner } : {}) },
    }));
  }
}
