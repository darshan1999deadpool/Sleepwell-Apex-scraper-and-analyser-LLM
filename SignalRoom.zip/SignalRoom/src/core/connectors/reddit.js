// Reddit Data API (OAuth, app must be approved by Reddit).
// Pulls posts mentioning the brand + posts by the brand's own Reddit account.
// likes = net upvotes (floored at 0), comments = num_comments, shares = cross-posts. No views.
import { brandKeywords } from "../config.js";
import { ApiError } from "../http.js";
import { makePost, toIso } from "../model.js";

const TOKEN_URL = "https://www.reddit.com/api/v1/access_token";
const API = "https://oauth.reddit.com";

export function timeFilter(days) {
  if (days <= 1) return "day";
  if (days <= 7) return "week";
  if (days <= 31) return "month";
  return "year";
}

export function buildQuery(brand) {
  return brandKeywords(brand).map((k) => `"${k.replace(/"/g, "")}"`).join(" OR ");
}

function basic(id, secret) {
  const raw = `${id}:${secret}`;
  return "Basic " + (typeof btoa === "function" ? btoa(raw) : Buffer.from(raw).toString("base64"));
}

async function token(http, keys) {
  const data = await http.post(TOKEN_URL, {
    body: "grant_type=client_credentials",
    headers: { Authorization: basic(keys.redditId, keys.redditSecret), "Content-Type": "application/x-www-form-urlencoded" },
  });
  if (!data.access_token) throw new ApiError("reddit", `sign-in failed: ${data.error || "no token returned"}`);
  return data.access_token;
}

export async function check(keys, http) {
  await token(http, keys);
  return "Signed in to the Reddit API.";
}

/** Confirms one brand's Reddit account exists. Returns { ok, detail }. */
export async function checkHandle(settings, brand, http) {
  const bearer = await token(http, settings.keys);
  const h = brand.handles.reddit;
  try {
    const data = await http.get(`${API}/user/${encodeURIComponent(h)}/about`, { params: { raw_json: 1 }, headers: { Authorization: `bearer ${bearer}` } });
    const d = data.data || {};
    return { ok: true, detail: `Found u/${d.name || h}${d.total_karma != null ? ` (${Number(d.total_karma).toLocaleString("en-IN")} karma)` : ""}.` };
  } catch (e) {
    if (!(e instanceof ApiError)) throw e;
    return { ok: false, detail: e.status === 404 ? `There's no Reddit user u/${h}.` : `u/${h}: ${e.detail}` };
  }
}

const unescape = (u) => String(u || "").replace(/&amp;/g, "&");

function media(d) {
  if (d.over_18) return { type: "text" };
  const preview = d.preview && d.preview.images && d.preview.images[0] && d.preview.images[0].source && d.preview.images[0].source.url;
  const thumb = unescape(preview) || (/^https?:\/\//.test(d.thumbnail || "") ? d.thumbnail : "");
  const rv = d.secure_media && d.secure_media.reddit_video;
  if (d.is_video && rv && rv.fallback_url) return { type: "video", src: unescape(rv.fallback_url), thumb, muted: true };
  if (thumb) return { type: "image", thumb };
  return { type: "text" };
}

function toPost(d, source) {
  const created = Number(d.created_utc) * 1000;
  if (!d.id || !Number.isFinite(created)) return null;
  const score = Number(d.score) || 0;
  return makePost({
    platform: "reddit",
    id: String(d.id),
    url: "https://www.reddit.com" + (d.permalink || `/comments/${d.id}/`),
    published_at: toIso(created),
    author: d.author || "",
    title: d.title || "",
    text: d.selftext || "",
    metrics: { views: null, likes: Math.max(score, 0), comments: Number(d.num_comments) || 0, shares: Number(d.num_crossposts) || 0, saves: null },
    reach_kind: null,
    source,
    where: d.subreddit_name_prefixed || (d.subreddit ? "r/" + d.subreddit : ""),
    media: media(d),
    extra: { subreddit_subscribers: d.subreddit_subscribers ?? null, upvote_ratio: d.upvote_ratio ?? null },
  });
}

export async function collect(ctx) {
  const { brands, http, settings, since, result } = ctx;
  const bearer = await token(http, settings.keys);
  const headers = { Authorization: `bearer ${bearer}` };
  const seen = new Set();
  const take = (children, source) => {
    for (const c of children || []) {
      const d = c && c.data;
      if (!d || seen.has(d.id)) continue;
      if (Number(d.created_utc) * 1000 < since) continue;
      const p = toPost(d, source);
      if (p) {
        seen.add(d.id);
        result.posts.push(p);
      }
    }
  };
  for (const brand of brands) {
    try {
      const data = await http.get(`${API}/search`, {
        params: { q: buildQuery(brand), sort: "new", t: timeFilter(settings.collect.windowDays), limit: 100, type: "link", raw_json: 1 },
        headers,
      });
      take(data.data && data.data.children, `search:${brand.name}`);
    } catch (e) {
      if (!(e instanceof ApiError)) throw e;
      result.notes.push(`Search for ${brand.name}: ${e.detail}`);
    }
    try {
      const data = await http.get(`${API}/user/${encodeURIComponent(brand.handles.reddit)}/submitted`, {
        params: { sort: "new", limit: 100, raw_json: 1 },
        headers,
      });
      take(data.data && data.data.children, `account:${brand.name}`);
    } catch (e) {
      if (!(e instanceof ApiError)) throw e;
      result.notes.push(`u/${brand.handles.reddit} (${brand.name}): ${e.detail}`);
    }
  }
  if (result.notes.length) {
    result.status = result.posts.length ? "partial" : "error";
    result.message = `${result.posts.length} posts; some requests failed — see notes`;
  }
}
