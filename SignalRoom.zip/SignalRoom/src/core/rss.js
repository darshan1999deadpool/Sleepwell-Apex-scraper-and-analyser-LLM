// Minimal RSS reader. Service workers have no DOMParser, so this parses the few
// elements Google News uses: <item>, <title>, <link>, <pubDate>, <source>.

const ENTITIES = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: " " };

export function decodeEntities(s) {
  return String(s).replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (m, e) => {
    if (e[0] === "#") {
      const code = e[1].toLowerCase() === "x" ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10);
      return Number.isFinite(code) && code > 0 && code < 0x110000 ? String.fromCodePoint(code) : m;
    }
    return ENTITIES[e.toLowerCase()] ?? m;
  });
}

function field(block, tag) {
  const m = new RegExp(`<${tag}(\\s[^>]*)?>([\\s\\S]*?)</${tag}>`, "i").exec(block);
  if (!m) return { text: "", attrs: "" };
  let v = m[2].trim();
  const cdata = /^<!\[CDATA\[([\s\S]*?)\]\]>$/.exec(v);
  v = cdata ? cdata[1] : decodeEntities(v);
  return { text: v.trim(), attrs: m[1] || "" };
}

export function parseRss(xml) {
  if (typeof xml !== "string" || !/<rss[\s>]|<channel[\s>]/i.test(xml)) throw new Error("not an RSS feed");
  const items = [];
  const re = /<item(\s[^>]*)?>([\s\S]*?)<\/item>/gi;
  let m;
  while ((m = re.exec(xml))) {
    const block = m[2];
    const src = field(block, "source");
    const urlAttr = /url="([^"]*)"/i.exec(src.attrs);
    items.push({
      title: field(block, "title").text,
      link: field(block, "link").text,
      pubDate: field(block, "pubDate").text,
      source: src.text,
      sourceUrl: urlAttr ? decodeEntities(urlAttr[1]) : "",
    });
  }
  return items;
}
