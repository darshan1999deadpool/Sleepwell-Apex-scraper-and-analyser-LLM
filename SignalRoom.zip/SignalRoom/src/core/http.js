// fetch wrapper: query strings, timeouts, retries on 429/5xx, readable errors.

export class ApiError extends Error {
  constructor(platform, message, status = null) {
    super(`${platform}: ${message}`);
    this.platform = platform;
    this.status = status;
    this.detail = message;
  }
}

const realSleep = (ms) => new Promise((r) => setTimeout(r, ms));

export function buildUrl(url, params) {
  if (!params) return url;
  const u = new URL(url);
  for (const [k, v] of Object.entries(params)) {
    if (v === undefined || v === null || v === "") continue;
    u.searchParams.set(k, String(v));
  }
  return u.toString();
}

function hintFor(status) {
  return (
    {
      400: " — the request was rejected (often an unsupported field or bad ID)",
      401: " — the key or token is missing, wrong or expired",
      403: " — not allowed: missing permission, approval or quota",
      404: " — not found: check the handle in Setup",
    }[status] || ""
  );
}

async function explain(resp) {
  let detail = "";
  let text = "";
  try {
    text = await resp.text();
    const body = JSON.parse(text);
    const err = body && body.error;
    if (err && typeof err === "object") detail = err.message || err.error_user_msg || JSON.stringify(err).slice(0, 200);
    else if (err) detail = String(err) + (body.message ? ": " + body.message : "");
    detail = detail || body.detail || body.title || body.message || "";
    if (!detail && Array.isArray(body.errors)) detail = body.errors.slice(0, 3).map((e) => e.message || JSON.stringify(e)).join("; ");
  } catch {
    detail = text.slice(0, 200);
  }
  return `HTTP ${resp.status}${hintFor(resp.status)}. ${detail}`.trim();
}

export function createHttp(platform, opts = {}) {
  const fetchImpl = opts.fetchImpl || ((...a) => fetch(...a));
  const sleep = opts.sleep || realSleep;
  const retries = opts.retries ?? 3;
  const timeoutMs = opts.timeoutMs ?? 30000;
  const minInterval = opts.minInterval ?? 0;
  const maxWaitMs = opts.maxWaitMs ?? 120000;
  let last = 0;

  const http = {
    calls: 0,
    async request(method, url, { params, headers, body, expect = "json" } = {}) {
      const full = buildUrl(url, params);
      let lastError = "request failed";
      for (let attempt = 0; attempt <= retries; attempt++) {
        if (minInterval) {
          const gap = Date.now() - last;
          if (gap < minInterval) await sleep(minInterval - gap);
        }
        last = Date.now();
        http.calls += 1;
        const ctrl = typeof AbortController !== "undefined" ? new AbortController() : null;
        const timer = ctrl ? setTimeout(() => ctrl.abort(), timeoutMs) : null;
        let resp;
        try {
          resp = await fetchImpl(full, { method, headers, body, signal: ctrl ? ctrl.signal : undefined });
        } catch (e) {
          lastError = e && e.name === "AbortError" ? `timed out after ${Math.round(timeoutMs / 1000)}s` : `network error: ${(e && e.message) || e}`;
          if (attempt < retries) {
            await sleep(Math.min(2 ** attempt * 1000, 20000));
            continue;
          }
          throw new ApiError(platform, lastError);
        } finally {
          if (timer) clearTimeout(timer);
        }
        if (resp.status === 429 || resp.status >= 500) {
          const ra = resp.headers.get("retry-after") || resp.headers.get("x-rate-limit-reset");
          let wait = 2 ** attempt * 1000;
          if (ra && /^\d+$/.test(ra)) {
            const v = Number(ra);
            wait = v > 10_000_000 ? Math.max(1000, v * 1000 - Date.now()) : v * 1000;
          }
          lastError = `HTTP ${resp.status} (rate limited or server error)`;
          if (attempt < retries && wait <= maxWaitMs) {
            await sleep(wait);
            continue;
          }
          throw new ApiError(platform, lastError, resp.status);
        }
        if (resp.status >= 400) throw new ApiError(platform, await explain(resp), resp.status);
        const text = await resp.text();
        if (expect === "text") return text;
        try {
          return JSON.parse(text);
        } catch {
          throw new ApiError(platform, `expected JSON, got: ${text.slice(0, 160)}`, resp.status);
        }
      }
      throw new ApiError(platform, lastError);
    },
    get(url, o) {
      return http.request("GET", url, o);
    },
    post(url, o) {
      return http.request("POST", url, o);
    },
  };
  return http;
}
