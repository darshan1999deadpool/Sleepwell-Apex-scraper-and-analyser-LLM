// Pure merge/prune logic for the history kept in chrome.storage.local.
import { DAY, parseTime } from "./model.js";

/** Merges items into bucket (uid -> item). Latest metrics win; first_seen and earlier brand tags are kept. */
export function mergeItems(bucket, items, nowIso) {
  let added = 0;
  let updated = 0;
  for (const item of items) {
    const old = bucket[item.uid];
    if (old) {
      item.first_seen = old.first_seen || nowIso;
      item.brands = [...new Set([...(old.brands || []), ...(item.brands || [])])].sort();
      updated++;
    } else {
      item.first_seen = nowIso;
      added++;
    }
    item.last_updated = nowIso;
    bucket[item.uid] = item;
  }
  return { added, updated };
}

export function prune(bucket, retentionDays, now = Date.now()) {
  const cutoff = now - retentionDays * DAY;
  let removed = 0;
  for (const [uid, item] of Object.entries(bucket)) {
    const t = parseTime(item.published_at);
    if (Number.isFinite(t) && t < cutoff) {
      delete bucket[uid];
      removed++;
    }
  }
  return removed;
}

/** Renames a brand in stored items (used when a brand is renamed in Setup). */
export function renameBrand(bucket, from, to) {
  let changed = 0;
  for (const item of Object.values(bucket)) {
    if (!(item.brands || []).includes(from)) continue;
    item.brands = [...new Set(item.brands.map((b) => (b === from ? to : b)))];
    if (item.owner_brand === from) item.owner_brand = to;
    changed++;
  }
  return changed;
}

/** Hides brand tags on platforms where that brand has no handle (no handle = no data from that platform). */
export function visiblePosts(posts, brands) {
  const handles = new Map(brands.map((b) => [b.name, b.handles || {}]));
  const out = [];
  for (const p of posts) {
    const keep = (p.brands || []).filter((name) => handles.has(name) && handles.get(name)[p.platform]);
    if (!keep.length) continue;
    if (keep.length === p.brands.length) {
      out.push(p);
      continue;
    }
    const ownerGone = p.owner_brand && !keep.includes(p.owner_brand);
    out.push({ ...p, brands: keep, ...(ownerGone ? { owner_brand: "", content_type: "earned" } : {}) });
  }
  return out;
}

/** Removes a brand's tag from stored items (used when a brand is deleted in Setup). Items left with no brand are dropped. */
export function forgetBrand(bucket, brandName) {
  let removed = 0;
  for (const [uid, item] of Object.entries(bucket)) {
    if (!(item.brands || []).includes(brandName)) continue;
    item.brands = item.brands.filter((b) => b !== brandName);
    if (item.owner_brand === brandName) {
      item.owner_brand = "";
      item.content_type = "earned";
    }
    if (!item.brands.length) {
      delete bucket[uid];
      removed++;
    }
  }
  return removed;
}
