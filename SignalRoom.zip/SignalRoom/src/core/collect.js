// One collection run: for each platform, pull only for brands that have a handle there,
// verify brand mentions, score sentiment, merge into history.
import { PLATFORM_LABEL, PLATFORMS, accessMode, brandsOn, keysReady, withArticle } from "./config.js";
import * as instagram from "./connectors/instagram.js";
import * as news from "./connectors/news.js";
import * as reddit from "./connectors/reddit.js";
import * as x from "./connectors/x.js";
import * as youtube from "./connectors/youtube.js";
import { ApiError, createHttp } from "./http.js";
import { matchNews, matchPost } from "./matching.js";
import { DAY, collectHashtags, fullText, toIso } from "./model.js";
import { score } from "./sentiment.js";
import { mergeItems, prune } from "./store.js";

export const CONNECTORS = { youtube, x, instagram, reddit, news };
const MIN_INTERVAL = { youtube: 0, x: 1000, instagram: 300, reddit: 700, news: 1000 };
export const STEPS = [...PLATFORMS, "news"];

export function emptyState() {
  return { posts: {}, news: {}, runs: [], status: {}, cache: { ytChannel: {} } };
}

/** What a run would do for each platform, from settings alone (no network). Used by Setup and the dashboard.
 *  state: "ready" | "limited" | "needs-access" | "no-handles" | "off" */
export function collectionPlan(settings) {
  return STEPS.map((p) => {
    const label = PLATFORM_LABEL[p];
    const brands = p === "news" ? settings.brands : brandsOn(settings, p);
    const access = accessMode(settings, p);
    let state;
    let reason;
    if (p === "news" && access.mode === "off") {
      state = "off";
      reason = "News is turned off in Setup.";
    } else if (!brands.length) {
      state = "no-handles";
      reason = p === "news" ? "Add a brand first." : `No brand has ${withArticle(label)} handle, so ${label} isn't tracked.`;
    } else if (access.mode === "none") {
      state = "needs-access";
      reason = `Add the ${access.missing.join(" and ")} in Setup → API access.`;
    } else if (access.mode === "limited") {
      state = "limited";
      reason = access.reason;
    } else {
      state = "ready";
      reason = p === "news" ? `Google News${settings.collect.gdelt ? " and GDELT" : ""}, by brand name. No key needed.` : `All ${label} sources.`;
    }
    return { platform: p, label, state, reason, brands: brands.map((b) => b.name), missing: access.missing || [] };
  });
}

function newResult(platform) {
  return { platform, status: "ok", message: "", posts: [], notes: [], estCostUsd: 0, mode: "full" };
}

async function runOne(name, ctx) {
  const result = ctx.result;
  try {
    await CONNECTORS[name].collect(ctx);
  } catch (e) {
    result.status = result.posts.length ? "partial" : "error";
    result.message = e instanceof ApiError ? e.detail : `Unexpected error: ${(e && e.message) || e}`;
  }
  return result;
}

/** Checks one platform's keys with a single cheap call. Returns { ok, message }. */
export async function checkPlatform(platform, settings, { fetchImpl, sleep } = {}) {
  const missing = keysReady(settings, platform);
  if (missing.length) return { ok: false, message: `Add the ${missing.join(" and ")} first.` };
  const http = createHttp(platform, { fetchImpl, sleep, retries: 1 });
  try {
    const sample = brandsOn(settings, platform)[0];
    return { ok: true, message: await CONNECTORS[platform].check(settings.keys, http, sample) };
  } catch (e) {
    return { ok: false, message: e instanceof ApiError ? e.detail : `Unexpected error: ${(e && e.message) || e}` };
  }
}

export async function runCollection({ settings, state, fetchImpl, sleep, now = Date.now(), onProgress = () => {} }) {
  state = { ...emptyState(), ...(state || {}) };
  state.cache = { ytChannel: {}, ...(state.cache || {}) };
  const since = now - settings.collect.windowDays * DAY;
  const nowIso = toIso(now);
  const totals = { added: 0, updated: 0, dropped: 0 };
  const status = { ...(state.status || {}) };
  const plan = collectionPlan(settings);

  // Platforms are independent (each has its own rate limits), so they run at the same time;
  // results are then merged one platform at a time, in a fixed order.
  let done = 0;
  onProgress({ step: 0, total: STEPS.length, platform: "start", label: "Starting" });
  const runs = await Promise.all(STEPS.map(async (name, i) => {
    const step = plan[i];
    const result = newResult(name);
    let calls = 0;
    const eligible = name === "news" ? settings.brands : brandsOn(settings, name);
    if (step.state === "off" || step.state === "no-handles" || step.state === "needs-access") {
      result.status = "skipped";
      result.message = step.state === "needs-access" ? `Not pulled: ${step.reason}` : step.reason;
    } else {
      const http = createHttp(name, { fetchImpl, sleep, minInterval: MIN_INTERVAL[name] });
      const ctx = {
        brands: eligible, http, settings, since, now, result, sleep, cache: state.cache,
        mode: step.state === "limited" ? "limited" : "full",
        makeHttp: (opts) => createHttp(name, { fetchImpl, sleep, ...opts }),
      };
      await runOne(name, ctx);
      calls = http.calls + (ctx.extraCalls || 0);
    }
    done++;
    onProgress({ step: done, total: STEPS.length, platform: name, label: `${step.label} done` });
    return { name, step, result, calls, eligible };
  }));

  for (const { name, step, result, calls, eligible } of runs) {

    const kept = [];
    if (name === "news") {
      for (const item of result.posts) {
        matchNews(item, settings.brands, item.brands[0]);
        [item.sentiment, item.sentiment_label] = score(item.title);
        kept.push(item);
      }
      const r = mergeItems(state.news, kept, nowIso);
      totals.added += r.added;
      totals.updated += r.updated;
    } else {
      let dropped = 0;
      for (const post of result.posts) {
        collectHashtags(post);
        matchPost(post, eligible);
        if (!post.brands.length) {
          dropped++;
          continue;
        }
        [post.sentiment, post.sentiment_label] = score(fullText(post));
        kept.push(post);
      }
      if (dropped) result.notes.push(`${dropped} result(s) dropped: they didn't name the brand exactly (fuzzy search match).`);
      totals.dropped += dropped;
      const r = mergeItems(state.posts, kept, nowIso);
      totals.added += r.added;
      totals.updated += r.updated;
    }
    if (result.status === "ok" && !result.message) {
      const what = name === "news" ? "articles" : name === "youtube" && result.mode === "limited" ? "videos from brand channels" : "posts";
      result.message = `${kept.length} ${what} kept from ${eligible.length} brand${eligible.length === 1 ? "" : "s"}.`;
    }
    status[name] = {
      status: result.status,
      state: step.state,
      mode: result.mode,
      message: result.message,
      notes: result.notes,
      items: kept.length,
      brands: eligible.map((b) => b.name),
      apiCalls: calls,
      estCostUsd: Math.round(result.estCostUsd * 10000) / 10000,
      checkedAt: nowIso,
    };
  }

  const pruned = prune(state.posts, settings.collect.retentionDays, now) + prune(state.news, settings.collect.retentionDays, now);
  state.status = status;
  state.runs = [...(state.runs || []), { at: nowIso, ...totals, pruned, status: Object.fromEntries(STEPS.map((s) => [s, status[s].status])) }].slice(-60);
  onProgress({ step: STEPS.length, total: STEPS.length, platform: "done", label: "Done" });
  return { state, summary: { ...totals, pruned, status } };
}
