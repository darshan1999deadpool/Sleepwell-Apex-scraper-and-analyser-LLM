// Every number on the dashboard comes from these functions.
//
//   reach            sum of views/impressions on posts where the platform reports them
//   engagements      likes + comments + shares + saves
//   engagement rate  engagements on reach-reported posts / reach   (same posts on both sides)
//   comment share    comments / engagements;   share share = shares / engagements
//   share of voice   a brand's mentions / sum of all brands' mentions
// A post naming two brands counts once for each brand, and once in "all brands".

import { engagements, nz, parseTime } from "./model.js";

export function filterPosts(posts, { brand = null, platform = null, ctype = null, start = -Infinity, end = Infinity } = {}) {
  return posts.filter((p) => {
    if (!p.brands || !p.brands.length) return false;
    if (brand && !p.brands.includes(brand)) return false;
    if (platform && p.platform !== platform) return false;
    if (ctype && p.content_type !== ctype) return false;
    const t = parseTime(p.published_at);
    return t >= start && t <= end;
  });
}

export function aggregate(posts) {
  const a = {
    posts: 0, posts_with_reach: 0, reach: 0, likes: 0, comments: 0, shares: 0, saves: 0, engagements: 0, eng_on_reach_posts: 0,
    positive: 0, neutral: 0, negative: 0, owned: 0, earned: 0, shares_reported: 0, saves_reported: 0, authors: 0,
  };
  const authors = new Set();
  for (const p of posts) {
    const m = p.metrics || {};
    const e = engagements(m);
    a.posts++;
    a.likes += nz(m.likes);
    a.comments += nz(m.comments);
    a.shares += nz(m.shares);
    a.saves += nz(m.saves);
    a.engagements += e;
    if (m.views !== null && m.views !== undefined) {
      a.posts_with_reach++;
      a.reach += nz(m.views);
      a.eng_on_reach_posts += e;
    }
    if (m.shares !== null && m.shares !== undefined) a.shares_reported++;
    if (m.saves !== null && m.saves !== undefined) a.saves_reported++;
    const s = p.sentiment_label || "neutral";
    a[s] = (a[s] || 0) + 1;
    if (p.content_type === "owned") a.owned++;
    else a.earned++;
    if (p.author) authors.add(p.platform + "|" + String(p.author).toLowerCase());
  }
  a.authors = authors.size;
  a.engagement_rate = a.reach ? a.eng_on_reach_posts / a.reach : null;
  a.comment_share = a.engagements ? a.comments / a.engagements : null;
  a.share_share = a.engagements ? a.shares / a.engagements : null;
  a.reach_coverage = a.posts ? a.posts_with_reach / a.posts : null;
  a.eng_per_post = a.posts ? a.engagements / a.posts : null;
  a.reach_per_post = a.posts_with_reach ? a.reach / a.posts_with_reach : null;
  a.positive_share = a.posts ? a.positive / a.posts : null;
  a.net_sentiment = a.posts ? ((a.positive - a.negative) / a.posts) * 100 : null;
  return a;
}

export function shareOfVoice(posts, brandNames) {
  const mentions = Object.fromEntries(brandNames.map((b) => [b, 0]));
  const eng = { ...mentions };
  for (const p of posts) {
    const e = engagements(p.metrics);
    for (const b of p.brands || []) if (b in mentions) { mentions[b]++; eng[b] += e; }
  }
  const tm = Object.values(mentions).reduce((s, v) => s + v, 0);
  const te = Object.values(eng).reduce((s, v) => s + v, 0);
  return Object.fromEntries(brandNames.map((b) => [b, {
    mentions: mentions[b], mention_sov: tm ? mentions[b] / tm : null,
    engagements: eng[b], engagement_sov: te ? eng[b] / te : null,
  }]));
}

// Metric catalogue for the platform face-off and the brand × platform grid.
// value(agg) returns a number, or null when the platform doesn't report it.
export const METRICS = [
  { key: "posts", label: "Mentions", kind: "count", value: (a) => a.posts },
  { key: "authors", label: "Unique accounts", kind: "count", value: (a) => a.authors },
  { key: "earned", label: "Earned posts", kind: "count", value: (a) => a.earned },
  { key: "owned", label: "Brand-owned posts", kind: "count", value: (a) => a.owned },
  { key: "reach", label: "Reach", kind: "count", value: (a) => (a.posts_with_reach ? a.reach : null) },
  { key: "reach_per_post", label: "Avg reach per post", kind: "count", value: (a) => a.reach_per_post },
  { key: "engagements", label: "Engagements", kind: "count", value: (a) => a.engagements },
  { key: "eng_per_post", label: "Engagements per post", kind: "count", value: (a) => a.eng_per_post },
  { key: "engagement_rate", label: "Engagement rate", kind: "pct", value: (a) => a.engagement_rate },
  { key: "likes", label: "Likes", kind: "count", value: (a) => a.likes },
  { key: "comments", label: "Comments", kind: "count", value: (a) => a.comments },
  { key: "shares", label: "Shares", kind: "count", value: (a) => (a.shares_reported ? a.shares : null) },
  { key: "saves", label: "Saves", kind: "count", value: (a) => (a.saves_reported ? a.saves : null) },
  { key: "comment_share", label: "Conversation (comments ÷ eng.)", kind: "pct", value: (a) => a.comment_share },
  { key: "share_share", label: "Amplification (shares ÷ eng.)", kind: "pct", value: (a) => (a.shares_reported ? a.share_share : null) },
  { key: "positive_share", label: "Positive posts", kind: "pct", value: (a) => a.positive_share },
  { key: "net_sentiment", label: "Net sentiment", kind: "signed", value: (a) => a.net_sentiment },
];

/** Ranking keys for the best-content board. */
export const RANKINGS = {
  engagements: { label: "Engagements", value: (p) => engagements(p.metrics) },
  engagement_rate: {
    label: "Engagement rate",
    // a rate on a handful of views is noise: needs at least 500 views/impressions
    value: (p) => (p.metrics && p.metrics.views >= 500 ? engagements(p.metrics) / p.metrics.views : null),
  },
  reach: { label: "Reach", value: (p) => (p.metrics && p.metrics.views != null ? Number(p.metrics.views) : null) },
  comments: { label: "Comments", value: (p) => nz(p.metrics && p.metrics.comments) },
  shares: { label: "Shares", value: (p) => (p.metrics && p.metrics.shares != null ? Number(p.metrics.shares) : null) },
};

export function rankPosts(posts, key) {
  const r = RANKINGS[key] || RANKINGS.engagements;
  return posts
    .map((p) => ({ p, v: r.value(p) }))
    .filter((x) => x.v !== null && x.v !== undefined && Number.isFinite(x.v))
    .sort((a, b) => b.v - a.v || parseTime(b.p.published_at) - parseTime(a.p.published_at))
    .map((x) => ({ post: x.p, score: x.v }));
}
