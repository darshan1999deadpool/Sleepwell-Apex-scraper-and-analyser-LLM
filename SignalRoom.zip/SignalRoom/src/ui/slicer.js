// Time slicer: two draggable handles over a histogram of daily activity.
import { addDays, dfmt, esc } from "./util.js";

export function createSlicer(root, { onChange }) {
  root.innerHTML = `
    <svg class="hist" preserveAspectRatio="none" aria-hidden="true"></svg>
    <div class="sel"></div>
    <input type="range" id="slice-start" aria-label="Start date" min="0" max="1" step="1" value="0">
    <input type="range" id="slice-end" aria-label="End date" min="0" max="1" step="1" value="1">
    <div class="axis" aria-hidden="true"></div>`;
  const hist = root.querySelector(".hist");
  const sel = root.querySelector(".sel");
  const a = root.querySelector("#slice-start");
  const b = root.querySelector("#slice-end");
  const axis = root.querySelector(".axis");
  let days = [];
  let counts = [];
  let timer = 0;

  const n = () => days.length;
  const xPct = (i) => (n() <= 1 ? 0 : (i / (n() - 1)) * 100);
  const thumbPos = (i) => `calc(9px + (100% - 18px) * ${xPct(i) / 100})`;

  function paint() {
    const s = +a.value;
    const e = +b.value;
    sel.style.left = thumbPos(s);
    sel.style.width = `calc((100% - 18px) * ${(xPct(e) - xPct(s)) / 100})`;
    a.setAttribute("aria-valuetext", dfmt(days[s], { day: "numeric", month: "short", year: "numeric" }));
    b.setAttribute("aria-valuetext", dfmt(days[e], { day: "numeric", month: "short", year: "numeric" }));
    // keep the start handle reachable when both handles sit at the right edge
    a.style.zIndex = s >= n() - 2 ? "3" : "2";
    b.style.zIndex = s >= n() - 2 ? "2" : "3";
    const max = Math.max(1, ...counts);
    const bw = 100 / n();
    hist.setAttribute("viewBox", `0 0 100 100`);
    hist.innerHTML = counts
      .map((c, i) => {
        if (!c) return "";
        const h = Math.max(3, (c / max) * 100);
        const inside = i >= s && i <= e;
        return `<rect x="${(i * bw + bw * 0.12).toFixed(3)}" y="${(100 - h).toFixed(2)}" width="${(bw * 0.76).toFixed(3)}" height="${h.toFixed(2)}" style="fill:${inside ? "var(--q4)" : "var(--rule)"}"/>`;
      })
      .join("");
  }

  function emit(now) {
    clearTimeout(timer);
    const fire = () => onChange({ startDay: days[+a.value], endDay: days[+b.value], fromSlider: true });
    if (now) fire();
    else timer = setTimeout(fire, 90);
  }

  a.addEventListener("input", () => {
    if (+a.value > +b.value) a.value = b.value;
    paint();
    emit(false);
  });
  b.addEventListener("input", () => {
    if (+b.value < +a.value) b.value = a.value;
    paint();
    emit(false);
  });
  a.addEventListener("change", () => emit(true));
  b.addEventListener("change", () => emit(true));

  return {
    /** domainStart/domainEnd: local midnights; dayCounts: counts per day; startDay/endDay: selection */
    update({ domainStart, domainEnd, dayCounts, startDay, endDay }) {
      days = [];
      for (let t = domainStart; t <= domainEnd; t = addDays(t, 1)) days.push(t);
      if (days.length < 2) days = [addDays(domainEnd, -1), domainEnd];
      counts = days.map((_, i) => dayCounts[i] || 0);
      a.max = b.max = String(days.length - 1);
      const idx = (t) => Math.max(0, Math.min(days.length - 1, Math.round((t - days[0]) / 86400000)));
      a.value = String(idx(startDay));
      b.value = String(idx(endDay));
      if (+a.value > +b.value) a.value = b.value;
      const ticks = Math.min(6, days.length);
      axis.innerHTML = Array.from({ length: ticks }, (_, k) => {
        const i = Math.round((k / (ticks - 1)) * (days.length - 1));
        const align = k === 0 ? "translateX(0)" : k === ticks - 1 ? "translateX(-100%)" : "translateX(-50%)";
        return `<span style="left:${xPct(i)}%;transform:${align}">${esc(dfmt(days[i]))}</span>`;
      }).join("");
      paint();
    },
    days: () => days.slice(),
  };
}
