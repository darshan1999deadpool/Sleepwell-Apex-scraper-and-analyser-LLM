// Media for the best-content cards: thumbnails, playable video, embedded posts.
import { PLATFORM_LABEL } from "../core/config.js";
import { esc, safeUrl } from "./util.js";

const PLAY = `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 4.5v15l13-7.5z" fill="#fff"/></svg>`;

const embedOk = {
  youtube: (u) => /^https:\/\/www\.youtube(-nocookie)?\.com\/embed\//.test(u),
  x: (u) => /^https:\/\/platform\.twitter\.com\/embed\/Tweet\.html\?/.test(u),
  instagram: (u) => /^https:\/\/www\.instagram\.com\/[^?#]+\/embed\/$/.test(u),
  reddit: () => false,
};

export function canEmbed(post) {
  const m = post.media || {};
  return !m.sample && !!m.embed && embedOk[post.platform] && embedOk[post.platform](m.embed);
}

function textBlock(post) {
  const t = (post.title ? post.title + " — " : "") + (post.text || "");
  return `<div class="textpost">${esc(t.slice(0, 400))}</div>`;
}

/** Initial (not yet playing) media HTML for a card. */
export function mediaHtml(post, rank) {
  const m = post.media || {};
  const rankTag = `<span class="rank">#${rank}</span>`;
  const label = PLATFORM_LABEL[post.platform];
  if (m.sample) {
    const kind = m.type === "video" ? "video" : m.type === "post" ? "post" : m.type === "image" ? "photo" : "text post";
    return `<div class="media">${rankTag}<div class="placeholder">Sample ${esc(label)} ${kind}<br>No real media in sample data</div>${m.duration ? `<span class="badge">${esc(m.duration)}</span>` : ""}</div>`;
  }
  const thumb = safeUrl(m.thumb);
  const src = safeUrl(m.src);
  if (post.platform === "youtube") {
    return `<div class="media" data-kind="youtube">${rankTag}
      ${thumb ? `<img src="${esc(thumb)}" alt="" loading="lazy" referrerpolicy="no-referrer">` : `<div class="placeholder">YouTube video</div>`}
      ${canEmbed(post) ? `<button class="play" type="button" data-action="play" aria-label="Play this video here"><span>${PLAY}</span></button>` : ""}
      ${m.duration ? `<span class="badge">${esc(m.duration)}</span>` : ""}</div>`;
  }
  if (m.type === "video" && src) {
    return `<div class="media" data-kind="video">${rankTag}
      <video controls playsinline preload="metadata"${m.muted ? " muted" : ""}${thumb ? ` poster="${esc(thumb)}"` : ""} src="${esc(src)}"></video></div>`;
  }
  if (thumb && (m.type === "image" || m.type === "carousel" || m.type === "video")) {
    return `<div class="media" data-kind="image">${rankTag}
      <img src="${esc(thumb)}" alt="" loading="lazy" referrerpolicy="no-referrer">
      ${m.type === "video" && canEmbed(post) ? `<button class="play" type="button" data-action="embed" aria-label="Play this post here"><span>${PLAY}</span></button>` : ""}</div>`;
  }
  return `<div class="media" data-kind="text">${rankTag}${textBlock(post)}</div>`;
}

/** Replaces a card's media with the platform's embedded player / post. */
export function playEmbed(mediaEl, post) {
  if (!canEmbed(post)) return false;
  const src = esc(post.media.embed);
  const title = `${PLATFORM_LABEL[post.platform]} post by ${post.author || "unknown account"}`;
  const rank = mediaEl.querySelector(".rank");
  mediaEl.className = "media" + (post.platform === "x" ? " embed-x" : post.platform === "instagram" ? " embed-ig" : "");
  const allow = post.platform === "youtube" ? ` allow="autoplay; encrypted-media; picture-in-picture; fullscreen"` : "";
  mediaEl.innerHTML = `<iframe src="${src}" title="${esc(title)}" loading="lazy" referrerpolicy="strict-origin-when-cross-origin"${allow}></iframe>`;
  if (rank) mediaEl.prepend(rank);
  return true;
}

/** When a thumbnail or video fails (expired CDN link), fall back to text or the embed. */
export function mediaFailed(mediaEl, post) {
  if (mediaEl.dataset.failed) return;
  mediaEl.dataset.failed = "1";
  const rank = mediaEl.querySelector(".rank");
  mediaEl.className = "media";
  mediaEl.innerHTML = textBlock(post);
  if (rank) mediaEl.prepend(rank);
}
