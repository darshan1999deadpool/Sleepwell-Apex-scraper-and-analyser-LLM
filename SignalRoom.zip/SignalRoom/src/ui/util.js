// Small UI helpers shared by the dashboard and setup screens.

export const $ = (id) => document.getElementById(id);

export const esc = (s) =>
  String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);

/** Only http(s) links are ever rendered as links. */
export const safeUrl = (u) => (/^https?:\/\//i.test(String(u || "")) ? String(u) : "");

const nf = new Intl.NumberFormat("en-IN");

export const full = (n) => (n == null || !Number.isFinite(Number(n)) ? "—" : nf.format(Math.round(n)));
// Indian short forms: 12.4K (thousand), 3.6L (lakh), 1.2Cr (crore). Below 10,000 numbers are written in full.
const short = (v, suffix) => (Math.round(v * 10) / 10).toLocaleString("en-IN", { maximumFractionDigits: 1 }) + suffix;
export const compact = (n) => {
  if (n == null || !Number.isFinite(Number(n))) return "—";
  n = Number(n);
  const a = Math.abs(n);
  if (a >= 1e7) return short(n / 1e7, "Cr");
  if (a >= 1e5) return short(n / 1e5, "L");
  if (a >= 1e4) return short(n / 1e3, "K");
  if (a < 10 && !Number.isInteger(n)) return n.toFixed(1);
  return nf.format(Math.round(n));
};
export const pct = (x, digits = 1) => {
  if (x == null || !Number.isFinite(x)) return "—";
  const v = x * 100;
  const d = v < 10 ? digits : Math.min(digits, 1);
  return v.toFixed(v >= 100 ? 0 : d) + "%";
};
export const signed = (n) => (n == null || !Number.isFinite(n) ? "—" : (n > 0 ? "+" : n < 0 ? "−" : "") + Math.abs(Math.round(n)));

export function fmtMetric(kind, v) {
  if (v == null || !Number.isFinite(v)) return "—";
  if (kind === "pct") return pct(v, 2);
  if (kind === "signed") return signed(v);
  return compact(v);
}

export const dfmt = (t, opts) => new Date(t).toLocaleDateString("en-IN", opts || { day: "numeric", month: "short" });
export const dtfmt = (t) => new Date(t).toLocaleString("en-IN", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });

export function startOfDay(t) {
  const d = new Date(t);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
}
export function addDays(t, n) {
  const d = new Date(t);
  d.setDate(d.getDate() + n);
  return d.getTime();
}
export function endOfDay(t) {
  return addDays(startOfDay(t), 1) - 1;
}
export function dayDiff(a, b) {
  return Math.round((startOfDay(b) - startOfDay(a)) / 86400000);
}

// ---------- tooltip + toast ----------
let tipEl = null;
export function showTip(html, x, y) {
  tipEl = tipEl || $("tip");
  tipEl.innerHTML = html;
  tipEl.hidden = false;
  const r = tipEl.getBoundingClientRect();
  let left = x + 14;
  let top = y + 14;
  if (left + r.width > window.innerWidth - 8) left = x - r.width - 14;
  if (top + r.height > window.innerHeight - 8) top = y - r.height - 14;
  tipEl.style.left = Math.max(8, left) + "px";
  tipEl.style.top = Math.max(8, top) + "px";
}
export function hideTip() {
  tipEl = tipEl || $("tip");
  tipEl.hidden = true;
}
export function bindTips(root) {
  root.querySelectorAll("[data-tip]").forEach((el) => {
    el.addEventListener("mousemove", (e) => showTip(el.dataset.tip, e.clientX, e.clientY));
    el.addEventListener("mouseleave", hideTip);
  });
}
let toastTimer = 0;
export function toast(msg, ms = 4000) {
  const t = $("toast");
  t.textContent = msg;
  t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.hidden = true), ms);
}

/** Segmented control. options: [[value, label, disabled?]] */
export function seg(el, options, current, onChange) {
  el.innerHTML = options
    .map(([v, l, dis]) => `<button type="button" data-v="${esc(v)}" aria-pressed="${v === current}"${dis ? " disabled" : ""}>${esc(l)}</button>`)
    .join("");
  el.onclick = (e) => {
    const b = e.target.closest("button");
    if (!b || b.disabled) return;
    el.querySelectorAll("button").forEach((x) => x.setAttribute("aria-pressed", String(x === b)));
    onChange(b.dataset.v);
  };
}
export function setPressed(el, value) {
  el.querySelectorAll("button").forEach((x) => x.setAttribute("aria-pressed", String(x.dataset.v === value)));
}

// ---------- colours: fixed order, colour-blind validated, follow the brand not its rank ----------
export function brandColor(brandNames, name) {
  const i = brandNames.indexOf(name);
  return i >= 0 && i < 8 ? `var(--s${i + 1})` : "var(--muted)";
}
/** Slots whose light-mode colour needs dark text on top. */
export function onLightClass(brandNames, name) {
  return [2, 3, 4].includes(brandNames.indexOf(name)) ? "on-light" : "";
}

// ---------- files ----------
export function downloadFile(filename, text, mime = "text/csv;charset=utf-8") {
  // CSV gets a byte-order mark so Excel reads Hindi and emoji correctly; JSON must not have one
  const blob = new Blob([(mime.startsWith("text/csv") ? "﻿" : "") + text], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}
export function csvRow(cells) {
  return cells
    .map((c) => {
      const s = c == null ? "" : String(c);
      return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    })
    .join(",");
}
