// Dashboard view. Every number comes from core/metrics.js.
import { collectionPlan } from "../core/collect.js";
import { PLATFORM_LABEL as PL, PLATFORMS } from "../core/config.js";
import { METRICS, RANKINGS, aggregate, rankPosts } from "../core/metrics.js";
import { engagements, nz, parseTime } from "../core/model.js";
import { visiblePosts } from "../core/store.js";
import { canEmbed, mediaFailed, mediaHtml, playEmbed } from "./media.js";
import { createSlicer } from "./slicer.js";
import {
  $, addDays, bindTips, brandColor, compact, csvRow, dayDiff, dfmt, downloadFile, dtfmt, endOfDay, esc, fmtMetric, full,
  hideTip, onLightClass, pct, safeUrl, seg, setPressed, showTip, signed, startOfDay,
} from "./util.js";

const DAY = 86400000;
const PRESETS = [["7", "7D"], ["30", "30D"], ["90", "90D"], ["all", "All"]];

export function createDashboard({ getData, goSetup, exploreSample, leaveSample, collectNow, dismissNotice }) {
  const F = { startDay: 0, endDay: 0, preset: "30", platform: "all", ctype: "all", brand: "all", rank: "engagements", trend: "engagements", matrix: "engagements", bestShown: 9, newsShown: 15, ready: false };
  let D = null; // { settings, state, sample, posts, news, names, domainStart, domainEnd, dayCounts }
  const slicer = createSlicer($("slicer"), {
    onChange: ({ startDay, endDay }) => {
      F.startDay = startDay;
      F.endDay = endDay;
      F.preset = matchPreset();
      setPressed($("f-preset"), F.preset);
      F.bestShown = 9;
      renderAll(false);
    },
  });

  // ---------------------------------------------------------------- data + filters
  function load() {
    const { settings, state, sample, dismissed } = getData();
    // only brands that still have a handle on a post's platform keep that post
    const posts = visiblePosts(Object.values((state && state.posts) || {}), settings.brands);
    const news = Object.values((state && state.news) || {});
    const names = settings.brands.map((b) => b.name);
    const times = [...posts, ...news].map((x) => parseTime(x.published_at)).filter(Number.isFinite);
    const today = startOfDay(Date.now());
    const latest = times.length ? startOfDay(Math.max(...times)) : today;
    const domainEnd = sample ? latest : Math.max(today, latest);
    const domainStart = times.length ? Math.min(startOfDay(Math.min(...times)), addDays(domainEnd, -6)) : addDays(domainEnd, -29);
    const n = dayDiff(domainStart, domainEnd) + 1;
    const dayCounts = new Array(n).fill(0);
    for (const p of posts) {
      const i = dayDiff(domainStart, parseTime(p.published_at));
      if (i >= 0 && i < n) dayCounts[i]++;
    }
    const plan = Object.fromEntries(collectionPlan(settings).map((p) => [p.platform, p]));
    D = { settings, state: state || {}, sample, posts, news, names, domainStart, domainEnd, dayCounts, plan, dismissed: dismissed || "" };
    if (!names.includes(F.brand)) F.brand = "all";
    if (!F.ready || F.preset) applyPreset(F.preset || "30");
    else {
      F.startDay = Math.max(domainStart, Math.min(F.startDay, domainEnd));
      F.endDay = Math.max(F.startDay, Math.min(F.endDay, domainEnd));
    }
    F.ready = true;
  }

  function applyPreset(p) {
    F.preset = p;
    F.endDay = D.domainEnd;
    F.startDay = p === "all" ? D.domainStart : Math.max(D.domainStart, addDays(D.domainEnd, -(Number(p) - 1)));
  }
  function matchPreset() {
    if (F.endDay !== D.domainEnd) return null;
    if (F.startDay === D.domainStart) return "all";
    for (const [p] of PRESETS) if (p !== "all" && F.startDay === Math.max(D.domainStart, addDays(D.domainEnd, -(Number(p) - 1)))) return p;
    return null;
  }
  const range = () => [F.startDay, endOfDay(F.endDay)];

  function scoped({ ignorePlatform = false, ignoreBrand = false } = {}) {
    const [s, e] = range();
    return D.posts.filter((p) => {
      const t = parseTime(p.published_at);
      if (!(t >= s && t <= e)) return false;
      if (!ignorePlatform && F.platform !== "all" && p.platform !== F.platform) return false;
      if (F.ctype !== "all" && p.content_type !== F.ctype) return false;
      if (!ignoreBrand && F.brand !== "all" && !p.brands.includes(F.brand)) return false;
      return D.names.some((n) => p.brands.includes(n));
    });
  }
  function scopedNews({ ignoreBrand = false } = {}) {
    const [s, e] = range();
    return D.news.filter((n) => {
      const t = parseTime(n.published_at);
      return t >= s && t <= e && (ignoreBrand || F.brand === "all" || (n.brands || []).includes(F.brand));
    });
  }
  const color = (name) => brandColor(D.names, name);
  const focusLabel = () => (F.brand === "all" ? "All brands" : F.brand);
  const rangeLabel = () => `${dfmt(F.startDay, { day: "numeric", month: "short", year: "numeric" })} – ${dfmt(F.endDay, { day: "numeric", month: "short", year: "numeric" })}`;
  const brandObj = (name) => D.settings.brands.find((b) => b.name === name);
  const tracked = (pf, brandName = F.brand) =>
    brandName === "all" ? D.settings.brands.some((b) => b.handles[pf]) : !!(brandObj(brandName) && brandObj(brandName).handles[pf]);

  // ---------------------------------------------------------------- controls
  function setupControls() {
    seg($("f-preset"), PRESETS, F.preset, (v) => { applyPreset(v); F.bestShown = 9; renderAll(true); });
    seg($("f-platform"), [["all", "All platforms"], ...PLATFORMS.map((p) => [p, PL[p]])], F.platform, (v) => { F.platform = v; F.bestShown = 9; renderAll(false); });
    seg($("f-ctype"), [["all", "All posts"], ["owned", "Brand-owned"], ["earned", "Earned"]], F.ctype, (v) => { F.ctype = v; F.bestShown = 9; renderAll(false); });
    seg($("f-rank"), Object.entries(RANKINGS).map(([k, r]) => [k, r.label]), F.rank, (v) => { F.rank = v; F.bestShown = 9; renderBest(); });
    seg($("f-trend"), [["engagements", "Engagements"], ["mentions", "Mentions"], ["reach", "Reach"]], F.trend, (v) => { F.trend = v; renderTrend(); });
    $("f-matrix").innerHTML = METRICS.map((m) => `<option value="${m.key}">${esc(m.label)}</option>`).join("");
    $("f-matrix").value = F.matrix;
    $("f-matrix").onchange = (e) => { F.matrix = e.target.value; renderMatrix(); };
    $("best-more").onclick = () => { F.bestShown += 9; renderBest(); };
    $("news-more").onclick = () => { F.newsShown += 15; renderNews(); };
    $("export-csv").onclick = exportCsv;
    $("f-brand").onclick = (e) => {
      const b = e.target.closest("button");
      if (!b) return;
      F.brand = b.dataset.v;
      F.bestShown = 9;
      renderAll(false);
    };
    $("best").addEventListener("click", onBestClick);
    $("best").addEventListener("error", onBestMediaError, true);
    let rt = 0;
    window.addEventListener("resize", () => { clearTimeout(rt); rt = setTimeout(renderTrend, 150); });
  }

  function renderBrandChips() {
    $("f-brand").innerHTML = [["all", "All brands", "var(--ink)"], ...D.names.map((n) => [n, n, color(n)])]
      .map(([v, l, c]) => `<button type="button" class="chip" data-v="${esc(v)}" aria-pressed="${F.brand === v}"><span class="dot" style="background:${c}"></span>${esc(l)}</button>`)
      .join("");
  }

  // ---------------------------------------------------------------- status strip + notices
  const SICON = {
    good: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3.5 8.4l3 3 6-6.4" style="fill:none;stroke:currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    warn: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 3.2v6" style="stroke:currentColor" stroke-width="2.2" stroke-linecap="round"/><circle cx="8" cy="12.6" r="1.3" style="fill:currentColor"/></svg>',
    bad: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4.5 4.5l7 7M11.5 4.5l-7 7" style="stroke:currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>',
    off: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 8h8" style="stroke:currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>',
  };
  const unitFor = (pf, st) => (pf === "news" ? "articles" : pf === "youtube" && st && st.mode === "limited" ? "videos" : "posts");

  /** One place that decides how each platform is doing: from the plan (setup) and the last run. */
  function platformInfo(pf) {
    const plan = D.plan[pf];
    const st = (D.state.status || {})[pf];
    if (D.sample) return { cls: "good", text: `${full(st ? st.items : 0)} sample ${pf === "news" ? "articles" : "posts"}`, go: `src-${pf}`, detail: "Sample data." };
    if (plan.state === "off") return { cls: "off", text: "Turned off", go: "setup:collect", detail: plan.reason };
    if (plan.state === "no-handles") return { cls: "off", text: pf === "news" ? "No brands yet" : "No handles", go: "setup:brands", detail: plan.reason };
    if (plan.state === "needs-access") return { cls: "warn", text: "Needs access", go: `setup:key-${pf}`, detail: plan.reason };
    if (!st || st.status === "skipped") {
      return { cls: "off", text: "Ready · not collected yet", go: "collect", detail: plan.state === "limited" ? plan.reason : "Ready. Press Collect now." };
    }
    if (st.status === "error") return { cls: "bad", text: "Failed last run", go: `src-${pf}`, detail: st.message };
    if (st.status === "partial") return { cls: "warn", text: `Partly · ${full(st.items)} ${unitFor(pf, st)}`, go: `src-${pf}`, detail: st.message };
    return { cls: "good", text: `${full(st.items)} ${unitFor(pf, st)} last run${plan.state === "limited" ? " · own channel only" : ""}`, go: `src-${pf}`, detail: plan.state === "limited" ? plan.reason : st.message };
  }

  function go(target) {
    if (!target) return;
    if (target === "collect") return collectNow();
    if (target.startsWith("setup")) return goSetup(target.split(":")[1] || "");
    const el = document.getElementById(target);
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "center" });
      el.classList.remove("flash");
      void el.offsetWidth;
      el.classList.add("flash");
    }
  }

  function renderStrip() {
    $("strip").innerHTML = [...PLATFORMS, "news"].map((pf) => {
      const i = platformInfo(pf);
      return `<button type="button" class="schip ${i.cls}" data-go="${esc(i.go)}" title="${esc(i.detail || "")}"><span class="ico">${SICON[i.cls]}</span><b>${PL[pf]}</b><span class="st">${esc(i.text)}</span></button>`;
    }).join("");
    $("strip").onclick = (e) => {
      const b = e.target.closest("[data-go]");
      if (b) go(b.dataset.go);
    };
  }

  function renderNotices() {
    const out = [];
    const st = D.state.status || {};
    const anyHandle = D.settings.brands.some((b) => PLATFORMS.some((p) => b.handles[p]));
    if (D.sample) {
      out.push(`<div class="notice"><strong>Sample data with fictional brands.</strong><span>Your setup and collected data aren't affected. Posts in the sample have no links or media.</span><button class="btn" type="button" data-go="leave">Leave sample</button></div>`);
    } else {
      const needs = PLATFORMS.filter((p) => D.plan[p].state === "needs-access");
      const limited = D.plan.youtube.state === "limited";
      const signature = JSON.stringify([needs, limited, D.plan.youtube.brands]);
      if ((needs.length || limited) && D.dismissed !== signature) {
        const parts = [];
        if (needs.length) {
          parts.push(`<strong>${esc(needs.map((p) => PL[p]).join(" and "))} can't be collected yet.</strong> ${needs.length === 1 ? "It needs" : "They need"} API access, even though handles are saved. Each platform only shares data with an approved key.`);
        }
        if (limited) parts.push(`YouTube works without a key, but only for your brands' own channel videos. A free YouTube API key adds other creators' videos about your brands, plus comments.`);
        out.push(`<div class="notice action"><span>${parts.join(" ")}</span><div class="actions"><button class="btn primary" type="button" data-go="setup:key-${needs[0] || "youtube"}">Set up access</button><button class="btn" type="button" data-go="dismiss" data-sig="${esc(signature)}">Dismiss</button></div></div>`);
      }
      if (!D.posts.length && !D.news.length) {
        out.push(`<div class="notice"><strong>No data yet.</strong><span>${anyHandle ? "Press Collect now to pull the first batch." : "Add each brand's handles in Setup, then press Collect now."}</span><div class="actions"><button class="btn" type="button" data-go="setup:brands">Open Setup</button><button class="btn" type="button" data-go="sample">Explore sample data</button></div></div>`);
      }
      const bad = [...PLATFORMS, "news"].filter((p) => st[p] && (st[p].status === "error" || st[p].status === "partial"));
      if (bad.length) {
        out.push(`<div class="notice warn"><strong>Last collection:</strong><span>${bad.map((p) => `${PL[p]} ${st[p].status === "error" ? "failed" : "partly worked"}: ${esc(st[p].message)}`).join(" · ")}</span><button class="btn" type="button" data-go="src-${bad[0]}">See details</button></div>`);
      }
    }
    $("notices").innerHTML = out.join("");
    $("notices").onclick = (e) => {
      const b = e.target.closest("[data-go]");
      if (!b) return;
      const t = b.dataset.go;
      if (t === "dismiss") dismissNotice(b.dataset.sig);
      else if (t === "leave") leaveSample();
      else if (t === "sample") exploreSample();
      else go(t);
    };
  }

  /** Why a view is empty, in words the user can act on. */
  function emptyReason() {
    if (F.platform !== "all") {
      const plan = D.plan[F.platform];
      if (plan.state === "needs-access" || plan.state === "no-handles") return `${PL[F.platform]} isn't being collected. ${plan.reason}`;
    }
    if (!D.posts.length) return D.sample ? "No posts." : "Nothing collected yet. Press Collect now.";
    if (F.ctype !== "all") return `No ${F.ctype === "owned" ? "brand-owned" : "earned"} posts match. Try “All posts”.`;
    if (F.brand !== "all") return `No posts for ${F.brand} match these filters.`;
    return "No posts in this time range. Widen it with the slicer or choose All.";
  }

  // ---------------------------------------------------------------- tiles
  function renderTiles() {
    const posts = scoped();
    const a = aggregate(posts);
    const all = scoped({ ignoreBrand: true });
    const news = scopedNews();
    let mentionsAll = 0, mentionsSel = 0, engAll = 0, engSel = 0;
    const marked = D.settings.brands.filter((b) => b.primary).map((b) => b.name);
    const sel = F.brand === "all" ? (marked.length ? marked : D.names.slice(0, 1)) : [F.brand];
    for (const p of all) {
      const e = engagements(p.metrics);
      for (const b of p.brands) {
        if (!D.names.includes(b)) continue;
        mentionsAll++;
        engAll += e;
        if (sel.includes(b)) { mentionsSel++; engSel += e; }
      }
    }
    const sovLabel = F.brand === "all" ? (sel.length ? (sel.length === 1 ? sel[0] : "Your brands'") + " share of voice" : "Share of voice") : `${F.brand} share of voice`;
    const tiles = [
      ["Mentions", full(a.posts), `${full(news.length)} news articles alongside`],
      ["Measured reach", compact(a.posts_with_reach ? a.reach : null), a.posts ? `reported on ${pct(a.reach_coverage, 0)} of posts` : "no posts in range"],
      ["Engagements", compact(a.engagements), `${compact(a.likes)} likes · ${compact(a.comments)} comments · ${compact(a.shares)} shares`],
      ["Engagement rate", pct(a.engagement_rate, 2), "on posts that report reach"],
      D.names.length < 2
        ? ["Share of voice", "—", "Add competitor brands in Setup to compare"]
        : [sovLabel, sel.length && mentionsAll ? pct(mentionsSel / mentionsAll, 1) : "—", sel.length && engAll ? `${pct(engSel / engAll, 1)} of engagement` : "no mentions in range"],
      ["Net sentiment", signed(a.net_sentiment), a.posts ? `${pct(a.positive / a.posts, 0)} positive · ${pct(a.negative / a.posts, 0)} negative` : ""],
    ];
    $("tiles").innerHTML = tiles.map(([k, v, d]) => `<div class="tile"><div class="k">${esc(k)}</div><div class="v num">${esc(v)}</div><div class="d">${esc(d)}</div></div>`).join("");
  }

  // ---------------------------------------------------------------- platform face-off
  function renderFaceoff() {
    const posts = scoped({ ignorePlatform: true });
    const aggs = Object.fromEntries(PLATFORMS.map((pf) => [pf, aggregate(posts.filter((p) => p.platform === pf))]));
    const st = D.state.status || {};
    // handle set but the last run skipped the platform (e.g. no key) and there's no data: say so instead of showing zeros
    const notPulled = Object.fromEntries(PLATFORMS.map((pf) => [pf, !D.sample && tracked(pf) && D.plan[pf].state === "needs-access" && !aggs[pf].posts]));
    const on = Object.fromEntries(PLATFORMS.map((pf) => [pf, tracked(pf) && !notPulled[pf]]));
    const leads = Object.fromEntries(PLATFORMS.map((pf) => [pf, 0]));
    let contested = 0;
    const cards = METRICS.map((m) => {
      const vals = PLATFORMS.map((pf) => (on[pf] ? m.value(aggs[pf]) : undefined));
      const real = vals.filter((v) => v != null && Number.isFinite(v));
      const best = real.length ? Math.max(...real) : null;
      const hasLeader = best != null && (m.kind === "signed" ? real.length > 0 : best > 0);
      if (hasLeader) contested++;
      const maxAbs = Math.max(1e-12, ...real.map((v) => Math.abs(v)));
      const rows = PLATFORMS.map((pf, i) => {
        const v = vals[i];
        const isLead = hasLeader && v === best;
        if (isLead) leads[pf]++;
        let bar = "";
        let val;
        if (v === undefined) val = `<span class="na">${notPulled[pf] ? "not pulled" : "no handle"}</span>`;
        else if (v === null || !Number.isFinite(v)) val = `<span class="na">n/a</span>`;
        else {
          val = esc(fmtMetric(m.kind, v));
          const w = (Math.abs(v) / maxAbs) * 100;
          bar = `<i class="${m.kind === "signed" ? (v < 0 ? "neg" : "pos") : ""}" style="width:${w.toFixed(1)}%"></i>`;
        }
        return `<div class="mrow${isLead ? " lead" : ""}"><span class="p">${PL[pf]}</span><span class="track">${bar}</span><span class="v">${val}</span></div>`;
      }).join("");
      return `<div class="mcard"><h3>${esc(m.label)}</h3>${rows}</div>`;
    }).join("");
    $("faceoff").innerHTML = cards;
    $("leaders").innerHTML = PLATFORMS.map((pf) => {
      if (notPulled[pf]) return `<div class="leader off"><span class="pfn">${PL[pf]}</span><span class="score">—</span><span class="sub">Needs access. ${esc(D.plan[pf].reason)}</span></div>`;
      if (!on[pf]) return `<div class="leader off"><span class="pfn">${PL[pf]}</span><span class="score">—</span><span class="sub">Not tracked: no ${F.brand === "all" ? "brand has a" : esc(F.brand) + " has no"} ${PL[pf]} handle</span></div>`;
      const a = aggs[pf];
      return `<div class="leader"><span class="pfn">${PL[pf]}</span><span class="score">${leads[pf]} of ${contested}</span><span class="sub">metrics led · ${full(a.posts)} mentions · ${compact(a.engagements)} engagements</span></div>`;
    }).join("");
    $("faceoff-lede").textContent = `${focusLabel()} · ${rangeLabel()}. Each card compares the four platforms on one measure; the leader is in bold, and a tie counts for each platform that ties. Platform filter doesn't apply here.`;
  }

  // ---------------------------------------------------------------- best content
  let bestIndex = new Map();
  function renderBest() {
    const ranked = rankPosts(scoped(), F.rank);
    const shown = ranked.slice(0, F.bestShown);
    bestIndex = new Map(shown.map((r) => [r.post.uid, r.post]));
    const rk = RANKINGS[F.rank];
    $("best-lede").textContent = ranked.length
      ? `${full(ranked.length)} posts ranked by ${rk.label.toLowerCase()} · ${focusLabel()} · ${F.platform === "all" ? "all platforms" : PL[F.platform]}. Play videos and open posts right here.${F.rank === "engagement_rate" ? " Only posts with at least 500 views or impressions are ranked by rate." : ""}`
      : "";
    $("best").innerHTML = shown.length
      ? shown.map((r, i) => card(r.post, i + 1, F.rank)).join("")
      : `<div class="empty">${esc(scoped().length && (F.rank === "reach" || F.rank === "engagement_rate" || F.rank === "shares") ? `None of these posts report ${RANKINGS[F.rank].label.toLowerCase()}. Rank by Engagements instead.` : emptyReason())}</div>`;
    $("best-more").hidden = ranked.length <= F.bestShown;
  }

  function card(p, rank, rankKey) {
    const m = p.metrics || {};
    const e = engagements(m);
    const er = m.views >= 1 ? e / m.views : null;
    const url = safeUrl(p.url);
    const body = p.title || p.text || "(no text)";
    const stat = (key, label, v) => `<div class="${rankKey === key ? "hl" : ""}"><dt>${label}</dt><dd>${v}</dd></div>`;
    const action = canEmbed(p) ? (p.platform === "youtube" ? "" : `<button class="btn small" type="button" data-action="embed">${p.platform === "instagram" && p.media.type === "video" ? "Play here" : "Show post here"}</button>`) : "";
    return `<article class="card" data-uid="${esc(p.uid)}">
      ${mediaHtml(p, rank)}
      <div class="cbody">
        <div class="cmeta"><span class="pf">${PL[p.platform]}</span>${p.author ? `<b>${esc(p.author)}</b>` : "<span>Unknown account</span>"}${p.author_followers ? `<span>${compact(p.author_followers)} followers</span>` : ""}<span>${dfmt(parseTime(p.published_at))}</span>${p.where ? `<span>${esc(p.where)}</span>` : ""}${p.content_type === "owned" ? '<span class="pill owned">Brand-owned</span>' : ""}</div>
        ${url ? `<a class="ctitle" href="${esc(url)}" target="_blank" rel="noopener noreferrer">${esc(body.slice(0, 220))}</a>` : `<span class="ctitle">${esc(body.slice(0, 220))}</span>`}
        <div class="cmeta">${p.brands.filter((b) => D.names.includes(b)).map((b) => `<span class="tag"><span class="dot" style="background:${color(b)}"></span>${esc(b)}</span>`).join("")}</div>
        <dl class="cstats">
          ${stat("reach", p.reach_kind === "impressions" ? "Impressions" : "Reach", m.views == null ? '<span class="na">n/a</span>' : compact(m.views))}
          ${stat("likes", p.platform === "reddit" ? "Upvotes" : "Likes", compact(m.likes))}
          ${stat("comments", "Comments", compact(m.comments))}
          ${stat("shares", "Shares", m.shares == null ? '<span class="na">n/a</span>' : compact(m.shares))}
          ${stat("engagements", "Engagements", compact(e))}
          ${stat("engagement_rate", "Eng. rate", er == null ? '<span class="na">n/a</span>' : pct(er, 2))}
        </dl>
        <div class="cactions">${action}${url ? `<a class="btn small" href="${esc(url)}" target="_blank" rel="noopener noreferrer">Open on ${PL[p.platform]} ↗</a>` : '<span class="note">Sample post, no link</span>'}</div>
      </div>
    </article>`;
  }

  function onBestClick(e) {
    const btn = e.target.closest("[data-action]");
    if (!btn) return;
    const cardEl = btn.closest(".card");
    const post = cardEl && bestIndex.get(cardEl.dataset.uid);
    if (!post) return;
    const mediaEl = cardEl.querySelector(".media");
    if (!playEmbed(mediaEl, post)) return;
    if (btn.closest(".cactions")) btn.remove();
    const actions = cardEl.querySelector(".cactions");
    if (actions && !actions.querySelector(".note")) {
      actions.insertAdjacentHTML("beforeend", `<span class="note">If the player shows an error, use “Open on ${PL[post.platform]}”.</span>`);
    }
  }
  function onBestMediaError(e) {
    const el = e.target;
    if (!(el instanceof HTMLImageElement || el instanceof HTMLVideoElement)) return;
    const cardEl = el.closest(".card");
    const post = cardEl && bestIndex.get(cardEl.dataset.uid);
    if (post) mediaFailed(el.closest(".media"), post);
  }

  // ---------------------------------------------------------------- funnel
  function renderFunnel() {
    const a = aggregate(scoped());
    const stages = [
      ["Reach", "views & impressions", a.posts_with_reach ? a.reach : 0],
      ["Engagements", "all interactions", a.engagements],
      ["Conversation", "comments & replies", a.comments],
      ["Amplification", "shares, reposts", a.shares],
    ];
    const steps = [
      [a.engagement_rate, "engagement rate", "Engagements on reach-reported posts ÷ reach"],
      [a.comment_share, "of engagements are comments", "Comments ÷ engagements"],
      [a.share_share, "of engagements are shares", "Shares ÷ engagements"],
    ];
    const max = Math.max(1, ...stages.map((s) => s[2]));
    const c = F.brand === "all" ? null : color(F.brand);
    const seqc = ["var(--q6)", "var(--q5)", "var(--q4)", "var(--q3)"];
    $("funnel-lede").textContent = `${focusLabel()} · ${F.platform === "all" ? "all platforms" : PL[F.platform]} · ${rangeLabel()}. Bar lengths use a log scale; read the numbers.`;
    if (!a.posts) {
      $("funnel").innerHTML = `<div class="empty" style="grid-column:1/-1">${esc(emptyReason())}</div>`;
      $("funnel-caveat").innerHTML = "";
      return;
    }
    let html = "";
    stages.forEach(([label, sub, v], i) => {
      const w = v > 0 ? 8 + 92 * (Math.log10(v + 1) / Math.log10(max + 1)) : 0;
      html += `<div class="f-label"><b>${label}</b><span>${sub}</span></div>
        <div class="f-track"><div class="f-bar" style="width:${w.toFixed(2)}%;background:${c || seqc[i]}" data-tip="${esc(`<div class="tt">${label}</div><div class="tr"><span>${esc(focusLabel())}</span><b>${full(v)}</b></div>`)}"></div></div>
        <div class="f-val num" title="${full(v)}">${compact(v)}</div>`;
      if (i < steps.length) html += `<div class="f-step"><span title="${steps[i][2]}"><b>${pct(steps[i][0], 2)}</b> ${steps[i][1]}</span></div>`;
    });
    $("funnel").innerHTML = html;
    bindTips($("funnel"));
    $("funnel-caveat").innerHTML = [
      `${full(a.posts)} posts in scope. Reach is reported on ${full(a.posts_with_reach)} of them (${pct(a.reach_coverage, 0)}).`,
      "Shares come from X, Reddit and your own Instagram posts; YouTube and other accounts' Instagram posts don't report them.",
    ].map((t) => `<span>${esc(t)}</span>`).join("");
  }

  function renderPlatformTable() {
    const posts = scoped({ ignorePlatform: true });
    const rows = PLATFORMS.map((pf) => [pf, aggregate(posts.filter((p) => p.platform === pf))]);
    const tot = aggregate(F.platform === "all" ? posts : posts.filter((p) => p.platform === F.platform));
    $("pf-lede").textContent = `${focusLabel()}: the same funnel on each platform.`;
    const maxE = Math.max(1, ...rows.map(([, a]) => a.engagements));
    const cells = (a, pf) => {
      if (pf && !tracked(pf)) return `<td class="n na" colspan="6">Not tracked: no handle</td>`;
      return `<td class="n">${full(a.posts)}</td>
        <td class="n">${a.posts && !a.posts_with_reach ? '<span class="na">n/a</span>' : compact(a.reach)}</td>
        <td class="n"><div class="mini"><i style="width:${Math.round((a.engagements / maxE) * 56)}px;background:var(--q4)"></i>${compact(a.engagements)}</div></td>
        <td class="n">${compact(a.comments)}</td><td class="n">${a.posts && !a.shares_reported ? '<span class="na">n/a</span>' : compact(a.shares)}</td>
        <td class="n">${a.engagement_rate == null ? '<span class="na">—</span>' : pct(a.engagement_rate, 2)}</td>`;
    };
    $("pf-table").innerHTML = `<thead><tr><th>Platform</th><th class="n">Mentions</th><th class="n">Reach</th><th class="n">Engagements</th><th class="n">Comments</th><th class="n">Shares</th><th class="n">Eng. rate</th></tr></thead>
      <tbody>${rows.map(([pf, a]) => `<tr${F.platform === pf ? ' class="sel"' : ""}><td><span class="pf">${PL[pf]}</span></td>${cells(a, pf)}</tr>`).join("")}
      <tr class="total"><td>${F.platform === "all" ? "All platforms" : PL[F.platform]}</td>${cells(tot, null)}</tr></tbody>`;
  }

  // ---------------------------------------------------------------- brands compared
  function renderBrandTable() {
    const posts = scoped({ ignoreBrand: true });
    const rows = D.names.map((n) => [n, aggregate(posts.filter((p) => p.brands.includes(n)))]);
    const totalMentions = rows.reduce((s, [, a]) => s + a.posts, 0);
    const maxE = Math.max(1, ...rows.map(([, a]) => a.engagements));
    $("brand-table").innerHTML = `<thead><tr><th>Brand</th><th>Handles</th><th class="n">Mentions</th><th class="n">Share of voice</th><th class="n">Reach</th><th class="n">Engagements</th><th class="n">Eng. / post</th><th class="n">Eng. rate</th><th class="n">Comments</th><th class="n">Shares</th><th class="n">Net sentiment</th></tr></thead>
      <tbody>${rows.map(([n, a]) => {
        const b = brandObj(n);
        const handles = PLATFORMS.filter((p) => b.handles[p]).map((p) => PL[p]).join(", ") || "none";
        return `<tr class="click${F.brand === n ? " sel" : ""}" data-b="${esc(n)}" tabindex="0">
          <td><span class="bname"><span class="dot" style="background:${color(n)}"></span>${esc(n)}${b.primary ? ' <span class="pill">yours</span>' : ""}</span></td>
          <td class="${handles === "none" ? "na" : ""}" style="font-size:12px">${esc(handles)}</td>
          <td class="n">${full(a.posts)}</td><td class="n">${totalMentions ? pct(a.posts / totalMentions, 1) : "—"}</td>
          <td class="n">${a.posts_with_reach ? compact(a.reach) : '<span class="na">n/a</span>'}</td>
          <td class="n"><div class="mini"><i style="width:${Math.round((a.engagements / maxE) * 64)}px;background:${color(n)}"></i>${compact(a.engagements)}</div></td>
          <td class="n">${a.posts ? compact(a.eng_per_post) : "—"}</td>
          <td class="n">${a.engagement_rate == null ? '<span class="na">—</span>' : pct(a.engagement_rate, 2)}</td>
          <td class="n">${compact(a.comments)}</td><td class="n">${compact(a.shares)}</td>
          <td class="n">${signed(a.net_sentiment)}</td></tr>`;
      }).join("")}</tbody>`;
    $("brand-table").querySelectorAll("tr.click").forEach((tr) => {
      const go = () => { F.brand = F.brand === tr.dataset.b ? "all" : tr.dataset.b; F.bestShown = 9; renderAll(false); };
      tr.onclick = go;
      tr.onkeydown = (ev) => { if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); go(); } };
    });
  }

  // ---------------------------------------------------------------- trend
  function niceMax(v) {
    if (v <= 0) return 4;
    const p = Math.pow(10, Math.floor(Math.log10(v)));
    for (const m of [1, 2, 2.5, 4, 5, 8, 10]) if (m * p >= v) return m * p;
    return 10 * p;
  }
  function renderTrend() {
    if (!D) return;
    const posts = scoped({ ignoreBrand: true });
    const span = dayDiff(F.startDay, F.endDay) + 1;
    const bucketDays = span > 92 ? 7 : 1;
    const n = Math.max(1, Math.ceil(span / bucketDays));
    const buckets = Array.from({ length: n }, (_, i) => addDays(F.startDay, i * bucketDays));
    const series = D.names.map((name) => ({ name, vals: new Array(n).fill(0) }));
    for (const p of posts) {
      const i = Math.min(n - 1, Math.floor(dayDiff(F.startDay, parseTime(p.published_at)) / bucketDays));
      if (i < 0) continue;
      const v = F.trend === "mentions" ? 1 : F.trend === "reach" ? nz(p.metrics && p.metrics.views) : engagements(p.metrics);
      for (const b of p.brands) { const s = series.find((x) => x.name === b); if (s) s.vals[i] += v; }
    }
    const label = { engagements: "Engagements", mentions: "Mentions", reach: "Measured reach" }[F.trend];
    $("trend-lede").textContent = `${label} per ${bucketDays === 7 ? "week" : "day"}, by brand · ${F.platform === "all" ? "all platforms" : PL[F.platform]} · ${rangeLabel()}.`;
    $("trend-legend").innerHTML = D.names.map((nm) => `<span><span class="dot" style="background:${color(nm)}"></span>${esc(nm)}</span>`).join("");
    const host = $("trend");
    if (!posts.length) { host.innerHTML = `<div class="empty">${esc(emptyReason())}</div>`; return; }
    const W = Math.max(300, host.clientWidth || 900);
    const H = W < 520 ? 220 : 270;
    const ml = 48, mr = 14, mt = 10, mb = 26;
    const iw = W - ml - mr, ih = H - mt - mb;
    const ymax = niceMax(Math.max(0, ...series.flatMap((s) => s.vals)));
    const x = (i) => ml + (n === 1 ? iw / 2 : (i / (n - 1)) * iw);
    const y = (v) => mt + ih - (v / ymax) * ih;
    let svg = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(label)} over time by brand"><g class="axis">`;
    for (let k = 0; k <= 4; k++) {
      const v = (ymax / 4) * k;
      svg += `<line x1="${ml}" x2="${W - mr}" y1="${y(v)}" y2="${y(v)}" style="stroke:${k === 0 ? "var(--rule)" : "var(--grid)"}" stroke-width="1"/><text x="${ml - 8}" y="${y(v) + 3.5}" text-anchor="end">${esc(compact(v))}</text>`;
    }
    const every = Math.max(1, Math.ceil(n / Math.max(1, Math.floor(iw / 72))));
    for (let i = 0; i < n; i += every) svg += `<text x="${x(i)}" y="${H - 6}" text-anchor="middle">${esc(dfmt(buckets[i]))}</text>`;
    svg += `</g>`;
    for (const s of series) {
      const d = s.vals.map((v, i) => `${i ? "L" : "M"}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join("");
      svg += `<path d="${d}" style="fill:none;stroke:${color(s.name)}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/>`;
      svg += `<circle cx="${x(n - 1)}" cy="${y(s.vals[n - 1])}" r="3.5" style="fill:${color(s.name)};stroke:var(--surface)" stroke-width="2"/>`;
    }
    svg += `<line class="xh" x1="0" x2="0" y1="${mt}" y2="${mt + ih}" style="stroke:var(--ink-2)" stroke-width="1" stroke-dasharray="3 3" visibility="hidden"/><g class="xh-dots"></g><rect class="hit" x="${ml}" y="${mt}" width="${iw}" height="${ih}" style="fill:transparent"/></svg>`;
    host.innerHTML = svg;
    const svgEl = host.querySelector("svg");
    const xh = svgEl.querySelector(".xh");
    const dots = svgEl.querySelector(".xh-dots");
    const hit = svgEl.querySelector(".hit");
    hit.addEventListener("pointermove", (ev) => {
      const r = svgEl.getBoundingClientRect();
      const px = ((ev.clientX - r.left) / r.width) * W;
      const i = n === 1 ? 0 : Math.max(0, Math.min(n - 1, Math.round(((px - ml) / iw) * (n - 1))));
      xh.setAttribute("x1", x(i)); xh.setAttribute("x2", x(i)); xh.setAttribute("visibility", "visible");
      dots.innerHTML = series.map((s) => `<circle cx="${x(i)}" cy="${y(s.vals[i])}" r="4" style="fill:${color(s.name)};stroke:var(--surface)" stroke-width="2"/>`).join("");
      const rows = [...series].sort((a, b) => b.vals[i] - a.vals[i]).map((s) => `<div class="tr"><span><span class="dot" style="background:${color(s.name)}"></span>${esc(s.name)}</span><b>${full(s.vals[i])}</b></div>`).join("");
      const when = bucketDays === 7 ? `Week of ${dfmt(buckets[i])}` : dfmt(buckets[i], { weekday: "short", day: "numeric", month: "short" });
      showTip(`<div class="tt">${esc(when)} · ${esc(label)}</div>${rows}`, ev.clientX, ev.clientY);
    });
    hit.addEventListener("pointerleave", () => { xh.setAttribute("visibility", "hidden"); dots.innerHTML = ""; hideTip(); });
  }

  // ---------------------------------------------------------------- share of voice + sentiment
  function stackBar(parts, total, unit) {
    if (!total) return `<div class="stack" style="background:var(--surface-2)"></div>`;
    return `<div class="stack">${parts.filter((p) => p.v > 0).map((p) => {
      const share = p.v / total;
      return `<div class="${p.cls || ""}" style="flex:${p.v} 1 0;background:${p.c}" data-tip="${esc(`<div class="tt">${esc(p.name)}</div><div class="tr"><span>${esc(unit)}</span><b>${full(p.v)}</b></div><div class="tr"><span>Share</span><b>${pct(share, 1)}</b></div>`)}">${share >= 0.08 ? pct(share, 0) : ""}</div>`;
    }).join("")}</div>`;
  }
  function renderSov() {
    const posts = scoped({ ignoreBrand: true });
    const news = scopedNews({ ignoreBrand: true });
    const m = Object.fromEntries(D.names.map((n) => [n, 0]));
    const e = { ...m };
    const nw = { ...m };
    for (const p of posts) { const v = engagements(p.metrics); for (const b of p.brands) if (b in m) { m[b]++; e[b] += v; } }
    for (const a of news) for (const b of a.brands || []) if (b in nw) nw[b]++;
    const row = (label, sub, obj, unit) => {
      const total = Object.values(obj).reduce((s, v) => s + v, 0);
      return `<div class="stack-row"><div class="lbl">${label}<span>${full(total)} ${sub}</span></div>${stackBar(D.names.map((n) => ({ name: n, v: obj[n], c: color(n), cls: onLightClass(D.names, n) })), total, unit)}</div>`;
    };
    $("sov-legend").innerHTML = D.names.map((nm) => `<span><span class="dot" style="background:${color(nm)}"></span>${esc(nm)}</span>`).join("");
    $("sov").innerHTML = row("Mentions", "brand mentions", m, "Mentions") + row("Engagement", "engagements", e, "Engagements") + row("News", "article mentions", nw, "Articles");
    bindTips($("sov"));
  }
  function renderSentiment() {
    const posts = scoped({ ignoreBrand: true });
    $("sent-legend").innerHTML = [["var(--neg)", "Negative"], ["var(--neu)", "Neutral"], ["var(--pos)", "Positive"]].map(([c, l]) => `<span><span class="dot" style="background:${c}"></span>${l}</span>`).join("");
    $("sentiment").innerHTML = D.names.map((n) => {
      const a = aggregate(posts.filter((p) => p.brands.includes(n)));
      const parts = [{ name: "Negative", v: a.negative, c: "var(--neg)" }, { name: "Neutral", v: a.neutral, c: "var(--neu)", cls: "on-neu" }, { name: "Positive", v: a.positive, c: "var(--pos)" }];
      return `<div class="sent-row"><span class="bname"><span class="dot" style="background:${color(n)}"></span>${esc(n)}</span>${stackBar(parts, a.posts, "Posts")}<span class="net">${signed(a.net_sentiment)}</span></div>`;
    }).join("");
    bindTips($("sentiment"));
  }

  // ---------------------------------------------------------------- brand × platform
  function renderMatrix() {
    const posts = scoped({ ignorePlatform: true, ignoreBrand: true });
    const metric = METRICS.find((m) => m.key === F.matrix) || METRICS[0];
    const grid = D.names.map((n) => PLATFORMS.map((pf) => (brandObj(n).handles[pf] ? metric.value(aggregate(posts.filter((p) => p.platform === pf && p.brands.includes(n)))) : undefined)));
    const vals = grid.flat().filter((v) => v != null && Number.isFinite(v));
    const lo = metric.kind === "signed" ? Math.min(0, ...vals) : 0;
    const hi = Math.max(lo + 1e-12, ...vals);
    const steps = ["--q1", "--q2", "--q3", "--q4", "--q5", "--q6"];
    const cell = (v) => {
      if (v === undefined) return `<td class="off" title="No handle on this platform">no handle</td>`;
      if (v === null || !Number.isFinite(v)) return `<td class="off" title="Not reported on this platform">n/a</td>`;
      const f = (v - lo) / (hi - lo);
      const i = f <= 0 ? -1 : Math.min(5, Math.floor(f * 6 - 1e-9));
      const bg = i < 0 ? "var(--surface-2)" : `var(${steps[i]})`;
      return `<td class="cell" style="background:${bg};color:${i >= 3 ? "#fff" : "var(--ink)"}" title="${esc(fmtMetric(metric.kind, v))}">${esc(fmtMetric(metric.kind, v))}</td>`;
    };
    $("matrix").innerHTML = `<thead><tr><th>Brand</th>${PLATFORMS.map((p) => `<th class="n">${PL[p]}</th>`).join("")}<th class="n">All platforms</th></tr></thead>
      <tbody>${D.names.map((n, r) => {
        const allV = metric.value(aggregate(posts.filter((p) => p.brands.includes(n))));
        return `<tr><td><span class="bname"><span class="dot" style="background:${color(n)}"></span>${esc(n)}</span></td>${grid[r].map(cell).join("")}<td class="n"><b>${esc(fmtMetric(metric.kind, allV))}</b></td></tr>`;
      }).join("")}</tbody>`;
  }

  // ---------------------------------------------------------------- voices, hashtags, news
  function renderVoices() {
    const posts = scoped().filter((p) => p.content_type !== "owned" && p.author);
    const by = new Map();
    for (const p of posts) {
      const k = p.platform + "|" + p.author.toLowerCase();
      const v = by.get(k) || { platform: p.platform, author: p.author, posts: 0, eng: 0, followers: null, brands: new Set() };
      v.posts++;
      v.eng += engagements(p.metrics);
      if (p.author_followers != null) v.followers = Math.max(v.followers || 0, p.author_followers);
      p.brands.forEach((b) => D.names.includes(b) && v.brands.add(b));
      by.set(k, v);
    }
    const top = [...by.values()].sort((a, b) => b.eng - a.eng).slice(0, 12);
    $("voices").innerHTML = top.length
      ? `<thead><tr><th>Account</th><th>Talks about</th><th class="n">Posts</th><th class="n">Followers</th><th class="n">Engagements</th></tr></thead>
        <tbody>${top.map((v) => `<tr><td><span class="pf">${PL[v.platform]}</span> <b>${esc(v.author)}</b></td><td>${[...v.brands].map((b) => `<span class="dot" title="${esc(b)}" style="background:${color(b)};margin-right:4px"></span>`).join("")}<span class="sr-only">${esc([...v.brands].join(", "))}</span></td><td class="n">${v.posts}</td><td class="n">${compact(v.followers)}</td><td class="n"><b>${compact(v.eng)}</b></td></tr>`).join("")}</tbody>`
      : `<tbody><tr><td class="empty">No earned posts with a known account in this filter.</td></tr></tbody>`;
    const counts = new Map();
    for (const p of scoped()) for (const h of p.hashtags || []) counts.set(h, (counts.get(h) || 0) + 1);
    const tags = [...counts.entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0])).slice(0, 30);
    $("hashtags").innerHTML = tags.length ? tags.map(([h, c]) => `<span>#${esc(h)}<b>${c}</b></span>`).join("") : `<div class="empty">No hashtags in this filter.</div>`;
  }

  function renderNews() {
    const news = scopedNews().sort((a, b) => parseTime(b.published_at) - parseTime(a.published_at));
    const outlets = new Map();
    for (const n of news) outlets.set(n.outlet || "Unknown", (outlets.get(n.outlet || "Unknown") || 0) + 1);
    const top = [...outlets.entries()].sort((a, b) => b[1] - a[1]).slice(0, 10);
    const max = Math.max(1, ...top.map((t) => t[1]));
    $("outlets-lede").textContent = `${full(news.length)} articles from ${full(outlets.size)} outlets · ${focusLabel()} · ${rangeLabel()}.`;
    $("outlets").innerHTML = top.length ? top.map(([o, c]) => `<div class="t">${esc(o)}</div><div class="c">${c}</div><div class="b" style="width:${Math.max(2, (c / max) * 100)}%"></div>`).join("") : `<div class="empty">No news in this period.</div>`;
    const sc = { positive: "var(--pos)", negative: "var(--neg)", neutral: "var(--neu)" };
    $("news").innerHTML = news.slice(0, F.newsShown).map((n) => {
      const u = safeUrl(n.url);
      return `<li>${u ? `<a href="${esc(u)}" target="_blank" rel="noopener noreferrer">${esc(n.title)}</a>` : `<span>${esc(n.title)}</span>`}
        <div class="meta"><span>${esc(n.outlet)}</span><span>${dfmt(parseTime(n.published_at))}</span>${(n.brands || []).filter((b) => D.names.includes(b)).map((b) => `<span class="tag"><span class="dot" style="background:${color(b)}"></span>${esc(b)}</span>`).join("")}<span class="tag"><span class="sdot" style="background:${sc[n.sentiment_label] || "var(--neu)"}"></span>${esc(n.sentiment_label || "neutral")} headline</span></div></li>`;
    }).join("") || `<li class="empty">No news in this period.</li>`;
    $("news-more").hidden = news.length <= F.newsShown;
  }

  // ---------------------------------------------------------------- data sources
  const ICON = {
    ok: ["var(--good)", "Working", '<svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="7" style="fill:var(--good)"/><path d="M4.5 8.2l2.3 2.3 4.7-4.8" style="fill:none;stroke:#fff" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>'],
    partial: ["var(--serious)", "Partly working", '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 1.5l7 12.5H1z" style="fill:var(--warn)"/><path d="M8 6v4" style="stroke:#10131a" stroke-width="1.8" stroke-linecap="round"/><circle cx="8" cy="12" r="1" style="fill:#10131a"/></svg>'],
    skipped: ["var(--muted)", "Not pulled", '<svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="6.5" style="fill:none;stroke:var(--muted)" stroke-width="1.6" stroke-dasharray="3 2.2"/></svg>'],
    error: ["var(--crit)", "Failed", '<svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="7" style="fill:var(--crit)"/><path d="M5.5 5.5l5 5M10.5 5.5l-5 5" style="stroke:#fff" stroke-width="1.8" stroke-linecap="round"/></svg>'],
  };
  function renderSources() {
    const st = D.state.status || {};
    const runs = D.state.runs || [];
    $("src-lede").textContent = runs.length && !D.sample ? `Last collection ${dtfmt(parseTime(runs[runs.length - 1].at))}.` : D.sample ? "Sample data." : "Nothing collected yet.";
    $("sources").onclick = (e) => {
      const b = e.target.closest("[data-go]");
      if (b) go(b.dataset.go);
    };
    $("sources").innerHTML = [...PLATFORMS, "news"].map((k) => {
      const s = st[k] || { status: "skipped", message: "Hasn't run yet.", notes: [] };
      const [c, label, icon] = ICON[s.status] || ICON.skipped;
      const notes = (s.notes || []).slice(0, 6);
      const plan = D.plan[k];
      const fix = !D.sample && plan.state === "needs-access" ? `<button class="btn small" type="button" data-go="setup:key-${k}">Set up ${PL[k]} access</button>` : !D.sample && plan.state === "no-handles" && k !== "news" ? `<button class="btn small" type="button" data-go="setup:brands">Add ${PL[k]} handles</button>` : "";
      return `<div class="src" id="src-${k}"><div class="src-head"><b>${PL[k]}</b><span class="status" style="color:${c}">${icon}${label}</span></div>${fix ? `<div>${fix}</div>` : ""}
        <p>${esc(s.message || "")}</p>
        ${s.brands && s.brands.length && s.status !== "skipped" ? `<p style="color:var(--muted);font-size:12px">Pulled for ${esc(s.brands.join(", "))}${s.apiCalls ? ` · ${s.apiCalls} API calls` : ""}${s.estCostUsd ? ` · ≈$${Number(s.estCostUsd).toFixed(2)}` : ""}</p>` : ""}
        ${notes.length ? `<ul>${notes.map((n) => `<li>${esc(n)}</li>`).join("")}</ul>` : ""}</div>`;
    }).join("");
  }

  // ---------------------------------------------------------------- export
  function exportCsv() {
    const posts = scoped().sort((a, b) => parseTime(b.published_at) - parseTime(a.published_at));
    if (!posts.length) return;
    const head = ["platform", "published_at", "brands", "content_type", "owner_brand", "author", "author_followers", "reach", "reach_kind", "likes", "comments", "shares", "saves", "engagements", "engagement_rate", "sentiment", "sentiment_score", "url", "title", "text"];
    const lines = [csvRow(head)];
    for (const p of posts) {
      const m = p.metrics || {};
      const e = engagements(m);
      lines.push(csvRow([p.platform, p.published_at, p.brands.join("; "), p.content_type, p.owner_brand, p.author, p.author_followers, m.views, p.reach_kind, m.likes, m.comments, m.shares, m.saves, e, m.views ? (e / m.views).toFixed(6) : "", p.sentiment_label, p.sentiment, p.url, (p.title || "").slice(0, 300), (p.text || "").slice(0, 1000)]));
    }
    const d = (t) => new Date(t).toISOString().slice(0, 10);
    downloadFile(`signal-room-posts_${d(F.startDay)}_to_${d(F.endDay)}.csv`, lines.join("\r\n"));
  }

  // ---------------------------------------------------------------- render
  function renderAll(resetSlicer) {
    hideTip();
    $("range-text").textContent = `${rangeLabel()} · ${dayDiff(F.startDay, F.endDay) + 1} days`;
    if (resetSlicer) slicer.update({ domainStart: D.domainStart, domainEnd: D.domainEnd, dayCounts: D.dayCounts, startDay: F.startDay, endDay: F.endDay });
    renderBrandChips();
    renderStrip();
    renderNotices();
    renderTiles();
    renderFaceoff();
    renderBest();
    renderFunnel();
    renderPlatformTable();
    renderBrandTable();
    renderTrend();
    renderSov();
    renderSentiment();
    renderMatrix();
    renderVoices();
    renderNews();
    renderSources();
    $("export-csv").disabled = !scoped().length;
  }

  setupControls();
  return {
    refresh() {
      load();
      setPressed($("f-preset"), F.preset);
      renderAll(true);
    },
    renderTrend,
    // exposed for automated checks
    _debug: () => ({ F: { ...F }, scoped, scopedNews, aggregate, range }),
    _setRange(startDay, endDay) {
      F.startDay = startDay;
      F.endDay = endDay;
      F.preset = matchPreset();
      renderAll(true);
    },
  };
}
