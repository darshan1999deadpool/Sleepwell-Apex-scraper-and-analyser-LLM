// App entry: loads settings + data from chrome.storage, switches views, runs collections via the service worker.
import { STEPS, checkPlatform, collectionPlan } from "../core/collect.js";
import { PLATFORM_LABEL as PL, cleanHandles, normalizeSettings, starterSettings } from "../core/config.js";
import { engagements } from "../core/model.js";
import { sampleState } from "../core/sample.js";
import { forgetBrand, renameBrand } from "../core/store.js";
import { createDashboard } from "./dashboard.js";
import { createSetup } from "./setup.js";
import { $, csvRow, downloadFile, dtfmt, esc, toast } from "./util.js";

let settings = cleanHandles(normalizeSettings(starterSettings()));
let state = { posts: {}, news: {}, runs: [], status: {}, cache: {} };
let sample = null;
let setupDirty = false;
let progress = null;
let dismissed = "";

async function loadAll() {
  const r = await chrome.storage.local.get(["settings", "posts", "news", "runs", "status", "cache", "dismissed"]);
  dismissed = r.dismissed || "";
  settings = cleanHandles(normalizeSettings(r.settings || starterSettings()));
  state = { posts: r.posts || {}, news: r.news || {}, runs: r.runs || [], status: r.status || {}, cache: r.cache || {} };
}

const getData = () => (sample ? { settings: sample.settings, state: sample.state, sample: true } : { settings, state, sample: false, dismissed });

const dashboard = createDashboard({
  getData,
  goSetup: (section) => go("setup", section),
  collectNow: () => startCollect(),
  // the notice comes back on its own if the setup changes (different signature)
  dismissNotice: (sig) => chrome.storage.local.set({ dismissed: sig }),
  exploreSample: () => {
    const s = sampleState();
    sample = { settings: cleanHandles(normalizeSettings(s.settings)), state: s.state };
    dashboard.refresh();
    updateRun();
    window.scrollTo(0, 0);
  },
  leaveSample: () => {
    sample = null;
    dashboard.refresh();
    updateRun();
  },
});

const setup = createSetup($("view-setup"), {
  getSettings: () => settings,
  getCache: () => state.cache,
  async save(clean, { removed, renamed }) {
    if (removed.length || renamed.length) {
      const r = await chrome.storage.local.get(["posts", "news"]);
      const posts = r.posts || {};
      const news = r.news || {};
      for (const [from, to] of renamed) {
        renameBrand(posts, from, to);
        renameBrand(news, from, to);
      }
      for (const name of removed) {
        forgetBrand(posts, name);
        forgetBrand(news, name);
      }
      await chrome.storage.local.set({ posts, news });
    }
    await chrome.storage.local.set({ settings: clean });
    settings = clean;
  },
  checkPlatform: (platform, s) => checkPlatform(platform, s),
  async exportAll() {
    const r = await chrome.storage.local.get("posts");
    const posts = Object.values(r.posts || {}).sort((a, b) => String(b.published_at).localeCompare(String(a.published_at)));
    if (!posts.length) {
      toast("Nothing collected yet.");
      return;
    }
    const head = ["platform", "published_at", "brands", "content_type", "author", "author_followers", "reach", "reach_kind", "likes", "comments", "shares", "saves", "engagements", "sentiment", "url", "title", "text"];
    const lines = [csvRow(head)];
    for (const p of posts) {
      const m = p.metrics || {};
      lines.push(csvRow([p.platform, p.published_at, (p.brands || []).join("; "), p.content_type, p.author, p.author_followers, m.views, p.reach_kind, m.likes, m.comments, m.shares, m.saves, engagements(m), p.sentiment_label, p.url, (p.title || "").slice(0, 300), (p.text || "").slice(0, 1000)]));
    }
    downloadFile(`signal-room-all-posts_${new Date().toISOString().slice(0, 10)}.csv`, lines.join("\r\n"));
  },
  async deleteAll() {
    await chrome.storage.local.set({ posts: {}, news: {}, runs: [], status: {} });
    state = { ...state, posts: {}, news: {}, runs: [], status: {} };
  },
  setDirty(d) {
    setupDirty = d;
  },
});

// ---------------------------------------------------------------- views (#dashboard, #setup, #setup/key-instagram …)
function go(view, section = "") {
  const target = view === "setup" ? `#setup${section ? "/" + section : ""}` : "#dashboard";
  if (location.hash === target) route();
  else location.hash = target;
}
function route() {
  const [head, section] = location.hash.replace(/^#/, "").split("/");
  const view = head === "setup" ? "setup" : "dashboard";
  $("view-dashboard").hidden = view !== "dashboard";
  $("view-setup").hidden = view !== "setup";
  $("tabs").querySelectorAll("button").forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.view === view)));
  document.title = view === "setup" ? "Signal Room · Setup" : "Signal Room";
  if (view === "dashboard") dashboard.renderTrend(); // the chart measures its width
  if (view === "setup" && section) requestAnimationFrame(() => setup.focus(section));
}
$("tabs").addEventListener("click", (e) => {
  const b = e.target.closest("button[data-view]");
  if (b) go(b.dataset.view);
});
window.addEventListener("hashchange", route);
window.addEventListener("beforeunload", (e) => {
  if (setupDirty) {
    e.preventDefault();
    e.returnValue = "";
  }
});

// ---------------------------------------------------------------- collection
function updateRun() {
  const btn = $("collect");
  const st = $("run-status");
  if (progress && progress.running) {
    btn.disabled = true;
    btn.innerHTML = `<span class="spin" aria-hidden="true"></span> Collecting…`;
    st.innerHTML = `Collecting all platforms… <b>${Math.min(progress.step || 0, progress.total || 5)} of ${progress.total || 5}</b> done`;
    return;
  }
  btn.textContent = "Collect now";
  btn.disabled = !!sample;
  if (sample) {
    st.textContent = "Viewing sample data";
    return;
  }
  const last = state.runs.length ? state.runs[state.runs.length - 1].at : null;
  const auto = settings.collect.autoDaily ? `daily at ${settings.collect.dailyTime}` : "auto-collect off";
  st.innerHTML = last ? `Last collected <b>${esc(dtfmt(Date.parse(last)))}</b> · ${esc(auto)}` : `Not collected yet · ${esc(auto)}`;
}

const DOT = {
  good: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3.5 8.4l3 3 6-6.4" style="fill:none;stroke:currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  warn: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 3.2v6" style="stroke:currentColor" stroke-width="2.2" stroke-linecap="round"/><circle cx="8" cy="12.6" r="1.3" style="fill:currentColor"/></svg>',
  bad: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4.5 4.5l7 7M11.5 4.5l-7 7" style="stroke:currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>',
  off: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 8h8" style="stroke:currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>',
};

/** Shows what a run will and won't collect when something is blocked or limited; resolves true to go ahead. */
async function preflight(plan) {
  const blocked = plan.filter((p) => p.state === "needs-access");
  const limited = plan.filter((p) => p.state === "limited");
  const runnable = plan.filter((p) => p.state === "ready" || p.state === "limited");
  if (!blocked.length && !limited.length) return true;
  const signature = JSON.stringify(plan.map((p) => [p.platform, p.state, p.brands]));
  const { preflightAck } = await chrome.storage.local.get("preflightAck");
  if (runnable.length && preflightAck === signature) return true;

  const dlg = $("preflight");
  $("pf-lede").textContent = runnable.length
    ? "Some platforms can't be collected with the access you have. Here's what this run will do."
    : "Nothing can be collected yet. Every platform with a handle still needs API access.";
  const cls = { ready: "good", limited: "good", "needs-access": "bad", "no-handles": "off", off: "off" };
  const what = (p) =>
    p.state === "ready" ? `Will collect for ${p.brands.join(", ")}.`
    : p.state === "limited" ? `Will collect own channel videos for ${p.brands.join(", ")}. No API key, so other creators' videos aren't searched.`
    : p.state === "needs-access" ? `Won't collect: ${p.reason}`
    : p.reason;
  $("pf-list").innerHTML = plan.map((p) => `<li class="${cls[p.state]}"><span class="ico">${DOT[cls[p.state]]}</span><b>${esc(p.label)}</b><span class="why">${esc(what(p))}</span></li>`).join("");
  $("pf-go").hidden = !runnable.length;
  $("pf-remember-wrap").hidden = !runnable.length;
  $("pf-remember").checked = false;
  $("pf-setup").textContent = blocked.length ? `Set up ${blocked[0].label} access` : "Open Setup";
  return new Promise((resolve) => {
    const done = async (value, target) => {
      $("pf-go").onclick = $("pf-cancel").onclick = $("pf-setup").onclick = null;
      dlg.onclose = null;
      if (value && $("pf-remember").checked) await chrome.storage.local.set({ preflightAck: signature });
      if (dlg.open) dlg.close();
      if (target) go("setup", target);
      resolve(value);
    };
    $("pf-go").onclick = () => done(true);
    $("pf-cancel").onclick = () => done(false);
    $("pf-setup").onclick = () => done(false, blocked.length ? `key-${blocked[0].platform}` : "brands");
    dlg.onclose = () => done(false);
    dlg.showModal();
  });
}

async function startCollect() {
  if (sample) return;
  if (setupDirty) {
    toast("Save or discard your Setup changes first.");
    go("setup");
    return;
  }
  const plan = collectionPlan(settings);
  if (!(await preflight(plan))) return;
  if (!plan.some((p) => p.state === "ready" || p.state === "limited")) {
    go("setup", "brands");
    return;
  }
  try {
    const r = await chrome.runtime.sendMessage({ type: "collect" });
    if (!r || !r.started) toast((r && r.message) || "Couldn't start the collection. Try again.");
  } catch {
    toast("Couldn't reach the background collector. Reload the extension in chrome://extensions and try again.");
  }
}
$("collect").addEventListener("click", startCollect);

function finishMessage(p) {
  if (!p.ok) return `Collection failed: ${p.error || "unknown error"}`;
  // Chrome storage returns object keys sorted alphabetically, so always walk platforms in display order
  const brief = STEPS.filter((k) => p.brief && p.brief[k]).map((k) => [k, p.brief[k]]);
  const got = brief.filter(([, b]) => b.status === "ok" || b.status === "partial").map(([k, b]) => `${PL[k]} ${b.items}`);
  const blocked = brief.filter(([, b]) => b.state === "needs-access").map(([k]) => PL[k]);
  const failed = brief.filter(([, b]) => b.status === "error").map(([k]) => PL[k]);
  let msg = `Collected: ${got.length ? got.join(" · ") : "nothing new"}.`;
  if (failed.length) msg += ` Failed: ${failed.join(", ")}.`;
  if (blocked.length) msg += ` Needs access: ${blocked.join(", ")}.`;
  return msg;
}

let reloadTimer = 0;
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "session" && changes.progress) {
    const p = changes.progress.newValue;
    const prev = changes.progress.oldValue;
    progress = p;
    updateRun();
    if (p && !p.running && p.finishedAt && (!prev || prev.finishedAt !== p.finishedAt)) toast(finishMessage(p), 8000);
  }
  if (area === "local" && (changes.posts || changes.news || changes.status || changes.runs || changes.settings || changes.cache || changes.dismissed)) {
    clearTimeout(reloadTimer);
    reloadTimer = setTimeout(async () => {
      await loadAll();
      if (!sample) dashboard.refresh();
      if (changes.settings) setup.reload();
      updateRun();
    }, 150);
  }
});

// ---------------------------------------------------------------- boot
(async () => {
  await loadAll();
  const s = await chrome.storage.session.get("progress");
  progress = s.progress || null;
  setup.load(); // the form must start from what's saved, not the starter brands

  dashboard.refresh();
  route();
  updateRun();
})();

// handle for automated checks
window.__signalRoom = { dashboard, setup, getData };
