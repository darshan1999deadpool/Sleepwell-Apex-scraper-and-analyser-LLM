// Setup view: brands (name + one handle per platform), readiness + live checks, API keys with guides,
// collection options, data and setup backup.
import { collectionPlan } from "../core/collect.js";
import {
  MAX_BRANDS, PLATFORM_LABEL as PL, PLATFORMS, accessMode, brandsOn, cleanHandles, defaultHashtag, emptyBrand,
  normalizeSettings, parseHandle, validateSettings,
} from "../core/config.js";
import { diagnose } from "../core/diagnose.js";
import { downloadFile, esc, toast } from "./util.js";

const HANDLE_HINT = {
  youtube: { ph: "@channelhandle, channel ID or link" },
  x: { ph: "@username or x.com link" },
  instagram: { ph: "@username or instagram.com link" },
  reddit: { ph: "u/username or reddit.com/user link" },
};

const ICONS = {
  good: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3.5 8.4l3 3 6-6.4" style="fill:none;stroke:currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  warn: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 3.2v6" style="stroke:currentColor" stroke-width="2.2" stroke-linecap="round"/><circle cx="8" cy="12.6" r="1.3" style="fill:currentColor"/></svg>',
  bad: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4.5 4.5l7 7M11.5 4.5l-7 7" style="stroke:currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>',
  off: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 8h8" style="stroke:currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>',
};

const KEY_ROWS = [
  {
    platform: "youtube", title: "YouTube", cost: "Free · optional",
    fields: [["youtube", "API key"]],
    help: "Works without a key for each brand's own channel videos. A key adds other creators' videos about your brands, comments and subscriber counts.",
    link: "https://console.cloud.google.com/apis/library/youtube.googleapis.com",
    steps: [
      "Go to console.cloud.google.com and sign in with any Google account.",
      "Create a project: project picker in the top bar → New project (name it Signal Room).",
      "Open APIs & Services → Library, search “YouTube Data API v3” and click Enable.",
      "Open APIs & Services → Credentials → Create credentials → API key, and copy it.",
      "Recommended: edit the key → API restrictions → Restrict key → YouTube Data API v3 → Save.",
      "Paste the key here and press Test access.",
    ],
  },
  {
    platform: "x", title: "X", cost: "Paid per post read",
    fields: [["x", "Bearer token"]],
    help: "X only shares data through its paid API. Each collection's cost is capped under Collection.",
    link: "https://developer.x.com/",
    steps: [
      "Sign in at developer.x.com and create a Project and an App.",
      "In Billing, add pay-per-use credits.",
      "Open the App → Keys and tokens → Bearer Token → Generate, and copy it.",
      "Paste it here and press Test access (billed as one request).",
      "Set “X posts per run” under Collection to cap each run's cost.",
    ],
  },
  {
    platform: "instagram", title: "Instagram", cost: "Free · needs a Meta app",
    fields: [["igToken", "Long-lived access token"], ["igBusinessId", "Instagram business account ID"]],
    help: "Instagram has no keyless access. You connect one Instagram Business or Creator account (for example your own brand's); other brands' public business accounts are then read through it.",
    link: "https://developers.facebook.com/apps/",
    steps: [
      "Make sure the Instagram account you'll connect is a Business or Creator account linked to a Facebook Page (Instagram app → Settings → Account type and tools).",
      "At developers.facebook.com → My Apps → Create app, choose type Business.",
      "Add the Instagram product (API setup with Facebook login).",
      "Open Tools → Graph API Explorer, pick your app and add the permissions instagram_basic, instagram_manage_insights, pages_show_list and pages_read_engagement (plus business_management if the Page sits in a business portfolio). Click Generate Access Token and approve.",
      "Make it long-lived: Tools → Access Token Debugger → paste the token → Extend Access Token. Copy the new token.",
      "Back in Graph API Explorer, run me/accounts?fields=instagram_business_account and copy the id inside instagram_business_account. That's the business account ID.",
      "Paste both here and press Test access. Use the connected account's username as that brand's Instagram handle to get its reach, views, shares and saves.",
      "Other brands' handles (for example a competitor) must be public Business or Creator accounts. Hashtag search also needs Meta's Instagram Public Content Access approval.",
    ],
  },
  {
    platform: "reddit", title: "Reddit", cost: "Free tier · needs Reddit's approval",
    fields: [["redditId", "Client ID"], ["redditSecret", "Client secret"]],
    help: "Reddit approves each API app before it can read data, and company use counts as commercial use.",
    link: "https://www.reddit.com/prefs/apps",
    steps: [
      "Signed in to Reddit, open reddit.com/prefs/apps → “create another app…”.",
      "Name it, choose script, set the redirect URI to http://localhost:8080 and create the app.",
      "Copy the ID shown under the app name (client ID) and the secret.",
      "Request API access from Reddit's developer support, describing it as read-only internal brand monitoring. Test access fails until Reddit approves.",
      "Paste both here and press Test access.",
    ],
  },
];

export function createSetup(root, { getSettings, getCache, save, checkPlatform, exportAll, deleteAll, setDirty }) {
  let saved = getSettings();
  let draft = structuredClone(saved);
  let errors = {};
  let confirmRemove = null;
  let confirmDelete = false;
  let diagRows = null;
  let diagRunning = false;

  const isDirty = () => JSON.stringify(normalizeSettings(draft)) !== JSON.stringify(normalizeSettings(saved));
  /** The draft with only valid handles, for plans and checks while the user types. */
  const usable = () => {
    const n = normalizeSettings(draft);
    return { ...n, brands: n.brands.map((b) => ({ ...b, handles: Object.fromEntries(PLATFORMS.map((p) => [p, parseHandle(p, b.handles[p]).handle || ""])) })) };
  };

  const notifyDirty = () => {
    const d = isDirty();
    setDirty(d);
    const msg = root.querySelector(".savebar .msg");
    if (msg && !msg.classList.contains("bad")) msg.textContent = d ? "You have unsaved changes." : "All changes saved.";
    root.querySelector("#save").disabled = !d;
    root.querySelector("#discard").disabled = !d;
  };

  function field(path, label, value, { type = "text", ph = "", help = "", cls = "", attrs = "" } = {}) {
    const err = errors[path];
    return `<label class="field ${cls}${err ? " invalid" : ""}"><span>${esc(label)}</span>
      <input type="${type}" data-path="${esc(path)}" value="${esc(value)}" placeholder="${esc(ph)}" ${attrs} aria-invalid="${err ? "true" : "false"}">
      ${err ? `<span class="err">${esc(err)}</span>` : help ? `<span class="help">${help}</span>` : ""}</label>`;
  }

  /** Status under a handle input: what will be used, and whether it can be pulled with the keys typed so far. */
  function handleStatus(pf, raw) {
    const { handle, error } = parseHandle(pf, raw);
    if (!String(raw || "").trim()) return `<span class="help">No handle: ${PL[pf]} won't be pulled for this brand.</span>`;
    if (error) return `<span class="err">${esc(error)}</span>`;
    const shown = pf === "reddit" ? "u/" + handle : pf === "youtube" ? handle : "@" + handle;
    const access = accessMode(usable(), pf);
    let state;
    if (access.mode === "full") state = `<span class="pill good">Ready</span>`;
    else if (access.mode === "limited") state = `<span class="pill good">Own videos, no key needed</span>`;
    else state = `<span class="pill warn">Needs ${esc(access.missing.join(" + "))}</span><button type="button" class="linkish" data-act="goto-key" data-platform="${pf}">Add it</button>`;
    return `<span class="hstatus"><span class="ok">Will use ${esc(shown)}</span>${state}</span>`;
  }

  function brandCard(b, i) {
    const confirming = confirmRemove === b.id;
    return `<div class="bcard" data-brand="${esc(b.id)}">
      <div class="bcard-head">
        ${field(`brand:${b.id}:name`, `Brand ${i + 1} name`, b.name, { cls: "name", ph: "e.g. Sleepwell", attrs: 'maxlength="60" required' })}
        <label class="check"><input type="checkbox" data-path="brand:${esc(b.id)}:primary" ${b.primary ? "checked" : ""}> This is my brand</label>
        ${confirming
          ? `<span class="confirm">Remove ${esc(b.name || "this brand")} and its collected data? <button class="btn small danger" type="button" data-act="remove-yes">Remove</button><button class="btn small" type="button" data-act="remove-no">Cancel</button></span>`
          : `<button class="btn small" type="button" data-act="remove">Remove</button>`}
      </div>
      <div class="handles">
        ${PLATFORMS.map((pf) => {
          const path = `brand:${b.id}:${pf}`;
          const err = errors[path];
          return `<label class="field${err ? " invalid" : ""}"><span>${PL[pf]} handle</span>
            <input type="text" data-path="${esc(path)}" value="${esc(b.handles[pf])}" placeholder="${esc(HANDLE_HINT[pf].ph)}" autocomplete="off" spellcheck="false" aria-invalid="${err ? "true" : "false"}">
            <span class="preview" data-preview="${pf}">${handleStatus(pf, b.handles[pf])}</span></label>`;
        }).join("")}
      </div>
      <div class="rename-warn" data-rename>${renameWarning(b)}</div>
      <details class="adv"${b.keywords.length || b.hashtags.length || b.context.length || b.exclude.length ? " open" : ""}>
        <summary data-advsum>${advSummary(b)}</summary>
        <div class="adv-grid">
          ${field(`brand:${b.id}:keywords`, "Other names to count", b.keywords.join(", "), { ph: "e.g. Sheela Foam", help: "Comma separated. The brand name is always included." })}
          ${field(`brand:${b.id}:hashtags`, "Extra hashtags", b.hashtags.map((h) => "#" + h).join(", "), { ph: "#sleepwellmattress", help: `#${esc(defaultHashtag(b.name) || "brandname")} is always included.` })}
          ${field(`brand:${b.id}:context`, "Must also mention one of", b.context.join(", "), { ph: "mattress, pillow, foam", help: "For names that are everyday words: a post counts only if it also has one of these (an @mention of the brand's handle always counts)." })}
          ${field(`brand:${b.id}:exclude`, "Ignore posts containing", b.exclude.join(", "), { ph: "e.g. sleep well soon", help: "Posts with any of these words are dropped for this brand." })}
        </div>
      </details>
    </div>`;
  }

  function advSummary(b) {
    const parts = [];
    if (b.keywords.length) parts.push(`${b.keywords.length} other name${b.keywords.length === 1 ? "" : "s"} (${b.keywords.slice(0, 2).join(", ")}${b.keywords.length > 2 ? "…" : ""})`);
    if (b.hashtags.length) parts.push(`${b.hashtags.length} extra hashtag${b.hashtags.length === 1 ? "" : "s"}`);
    if (b.context.length) parts.push(`${b.context.length} must-mention word${b.context.length === 1 ? "" : "s"}`);
    if (b.exclude.length) parts.push(`${b.exclude.length} excluded word${b.exclude.length === 1 ? "" : "s"}`);
    return parts.length ? `Advanced matching: ${esc(parts.join(" · "))}` : "Advanced matching (optional)";
  }

  /** A renamed brand keeps its old matching words, which can silently filter or pollute the new brand's data. */
  function renameWarning(b) {
    const before = saved.brands.find((x) => x.id === b.id);
    const has = b.keywords.length || b.hashtags.length || b.context.length || b.exclude.length;
    if (!before || !has || before.name.trim().toLowerCase() === String(b.name).trim().toLowerCase()) return "";
    return `<div class="notice warn" style="margin:0"><span>Renamed from <b>${esc(before.name)}</b>. Its advanced matching still applies to this brand: ${esc([...b.keywords, ...b.context].slice(0, 6).join(", "))}${b.keywords.length + b.context.length > 6 ? "…" : ""}.</span><button class="btn small" type="button" data-act="clear-adv">Clear advanced matching</button></div>`;
  }

  const PLAN_CLS = { ready: "good", limited: "good", "needs-access": "warn", "no-handles": "off", off: "off" };
  const PLAN_TEXT = { ready: "Everything", limited: "Own channel videos only", "needs-access": "Nothing until access is added", "no-handles": "Nothing: no handles", off: "Nothing: turned off" };

  function readiness() {
    const s = usable();
    const plan = collectionPlan(s);
    const rows = plan.map((p) => {
      const access = p.platform === "news" ? `<span class="pill good">No key needed</span>`
        : !p.missing.length ? `<span class="pill good">Key saved</span>`
        : !p.brands.length ? `<span class="pill">Not needed: no handles</span>`
        : p.platform === "youtube" ? `<span class="pill">No key (optional)</span>`
        : `<span class="pill warn">Missing ${esc(p.missing.join(" + "))}</span>`;
      return `<tr><td><b>${p.label}</b></td><td>${p.brands.length ? esc(p.brands.join(", ")) : '<span class="na">—</span>'}</td><td>${access}</td>
        <td><span class="hstatus"><span class="pill ${PLAN_CLS[p.state]}">${PLAN_TEXT[p.state]}</span></span></td>
        <td class="why">${esc(p.reason)}${p.state === "needs-access" ? ` <button type="button" class="linkish" data-act="goto-key" data-platform="${p.platform}">Add access</button>` : ""}</td></tr>`;
    }).join("");
    return `<table class="ready-tbl"><thead><tr><th>Platform</th><th>Brands with handles</th><th>Access</th><th>Will collect</th><th>Why</th></tr></thead><tbody>${rows}</tbody></table>`;
  }

  function coverage() {
    const s = normalizeSettings(draft);
    const u = usable();
    const rows = s.brands.map((b) => `<tr><td><b>${esc(b.name || "(unnamed)")}</b></td>${PLATFORMS.map((pf) => {
      const { handle, error } = parseHandle(pf, b.handles[pf]);
      if (error) return `<td><span style="color:var(--err-ink)">fix</span></td>`;
      if (!handle) return `<td class="no">—</td>`;
      const m = accessMode(u, pf).mode;
      return `<td class="yes">${m === "full" ? "Pulled" : m === "limited" ? "Own videos" : '<span style="color:var(--err-ink)">Needs key</span>'}</td>`;
    }).join("")}</tr>`).join("");
    return `<table class="coverage"><thead><tr><th>Brand</th>${PLATFORMS.map((p) => `<th>${PL[p]}</th>`).join("")}</tr></thead><tbody>${rows}</tbody></table>`;
  }

  function diagHtml() {
    if (!diagRows) return "";
    if (!diagRows.length && diagRunning) return `<div class="diag"><div class="diag-row info"><span class="ico"><span class="spin" aria-hidden="true"></span></span><span class="pfx">Checking…</span><span class="txt">Testing keys and handles.</span></div></div>`;
    return `<div class="diag" aria-live="polite">${diagRows.map((r) => {
      const cls = r.ok === true ? "good" : r.ok === false ? "bad" : "info";
      return `<div class="diag-row ${cls}"><span class="ico">${ICONS[r.ok === true ? "good" : r.ok === false ? "bad" : "off"]}</span><span class="pfx">${PL[r.platform]}${r.brand ? `<small>${esc(r.brand)}</small>` : ""}</span><span class="txt">${esc(r.detail)}</span></div>`;
    }).join("")}${diagRunning ? `<div class="diag-row info"><span class="ico"><span class="spin" aria-hidden="true"></span></span><span class="pfx">Checking…</span><span class="txt"></span></div>` : ""}</div>`;
  }

  function keyRow(r) {
    const u = usable();
    const need = brandsOn(u, r.platform).length;
    const missing = accessMode(u, r.platform).missing;
    const needed = need && missing.length && r.platform !== "youtube";
    const badge = !missing.length ? `<span class="pill good">Saved</span>`
      : needed ? `<span class="pill warn">Needed for ${need} brand${need === 1 ? "" : "s"}</span>`
      : r.platform === "youtube" && need ? `<span class="pill">Optional: adds search</span>` : `<span class="pill">Not needed yet</span>`;
    return `<div class="krow${needed ? " needed" : ""}" data-platform="${r.platform}" id="key-${r.platform}">
      <div class="krow-head"><h3>${esc(r.title)} <span class="pill">${esc(r.cost)}</span> <span data-badge>${badge}</span></h3><a class="btn small" href="${esc(r.link)}" target="_blank" rel="noopener noreferrer">Open ${esc(r.title)} developer site ↗</a></div>
      <p class="lede" style="margin:0">${esc(r.help)}</p>
      <details class="guide"${needed ? " open" : ""}><summary>Step-by-step</summary><ol class="steps">${r.steps.map((t) => `<li>${esc(t)}</li>`).join("")}</ol></details>
      <div class="krow-fields">
        ${r.fields.map(([k, label]) => `<label class="field"><span>${esc(label)}</span><span class="secret"><input type="password" data-path="keys:${k}" value="${esc(draft.keys[k] || "")}" autocomplete="off" spellcheck="false"><button class="btn small" type="button" data-act="reveal" aria-label="Show ${esc(label)}">Show</button></span></label>`).join("")}
        <div class="field"><span>&nbsp;</span><button class="btn" type="button" data-act="test">Test access</button></div>
      </div>
      <div class="test-result" data-result></div>
    </div>`;
  }

  function render() {
    const c = draft.collect;
    root.innerHTML = `
      <section class="panel" id="sec-ready" aria-labelledby="h-setup-ready">
        <div class="panel-head"><div>
          <h2 id="h-setup-ready">Readiness</h2>
          <p class="lede">What each platform will collect with the handles and keys entered below. Run checks tests every key and confirms each handle exists, using what's typed here even before you save.</p>
        </div><button class="btn primary" type="button" data-act="diagnose" ${diagRunning ? "disabled" : ""}>${diagRunning ? '<span class="spin" aria-hidden="true"></span> Checking…' : "Run checks"}</button></div>
        <div class="tbl-wrap" id="readiness">${readiness()}</div>
        <div id="diag">${diagHtml()}</div>
      </section>

      <section class="panel" id="sec-brands" aria-labelledby="h-setup-brands">
        <div class="panel-head"><div>
          <h2 id="h-setup-brands">Brands and handles</h2>
          <p class="lede">Enter each brand's name and its handle on each platform. Paste a handle or a profile link. A platform is pulled only for brands that have a handle on it.</p>
        </div></div>
        ${errors.brands ? `<p class="err" style="color:var(--err-ink)">${esc(errors.brands)}</p>` : ""}
        <div class="brand-list">${draft.brands.map(brandCard).join("")}</div>
        <div style="margin-top:12px;display:flex;gap:10px;align-items:center;flex-wrap:wrap">
          <button class="btn" type="button" data-act="add" ${draft.brands.length >= MAX_BRANDS ? "disabled" : ""}>Add brand</button>
          <span class="lede" style="margin:0">${draft.brands.length} of ${MAX_BRANDS} brands</span>
        </div>
        <h3 style="margin-top:18px">Brand × platform</h3>
        <div class="tbl-wrap" id="coverage">${coverage()}</div>
      </section>

      <section class="panel" id="sec-keys" aria-labelledby="h-setup-keys">
        <div class="panel-head"><div><h2 id="h-setup-keys">API access</h2>
          <p class="lede">Platforms share data only with an approved key. Keys stay in this browser (not synced to your Google account). News needs no key, and YouTube works without one for your brands' own videos.</p></div></div>
        <div class="keys" id="keys">${KEY_ROWS.map(keyRow).join("")}</div>
      </section>

      <section class="panel" id="sec-collect" aria-labelledby="h-setup-collect">
        <div class="panel-head"><div><h2 id="h-setup-collect">Collection</h2></div></div>
        <div class="opts">
          ${field("collect:windowDays", "Days to look back each run", c.windowDays, { type: "number", attrs: 'min="1" max="30" step="1"', help: "1–30. X search only reaches back 7 days. Brand channel videos are kept for the full history." })}
          <div class="field"><span>Collect automatically</span><label class="check"><input type="checkbox" data-path="collect:autoDaily" ${c.autoDaily ? "checked" : ""}> Every day while Chrome is open</label></div>
          ${field("collect:dailyTime", "Daily collection time", c.dailyTime, { type: "time", help: "Your computer's local time." })}
          <div class="field"><span>News coverage</span><label class="check"><input type="checkbox" data-path="collect:news" ${c.news ? "checked" : ""}> Track Google News by brand name</label>
            <label class="check"><input type="checkbox" data-path="collect:gdelt" ${c.gdelt ? "checked" : ""}> Also search GDELT (more outlets, adds about 6 seconds per brand)</label></div>
          ${field("collect:xMaxPosts", "X posts per run (cost cap)", c.xMaxPosts, { type: "number", attrs: 'min="10" max="1000" step="10"', help: `About $${(Number(c.xMaxPosts || 0) * (Number(c.xPostRate || 0) + (c.xIncludeProfiles ? Number(c.xUserRate || 0) : 0))).toFixed(2)} per run at the rates below.` })}
          <div class="field"><span>X author profiles</span><label class="check"><input type="checkbox" data-path="collect:xIncludeProfiles" ${c.xIncludeProfiles ? "checked" : ""}> Fetch follower counts (billed per profile)</label></div>
          ${field("collect:xPostRate", "X rate per post read (USD)", c.xPostRate, { type: "number", attrs: 'min="0" max="1" step="0.001"', help: "For the cost estimate only. Check your X developer console." })}
          ${field("collect:xUserRate", "X rate per profile read (USD)", c.xUserRate, { type: "number", attrs: 'min="0" max="1" step="0.001"' })}
          ${field("collect:retentionDays", "Keep history for (days)", c.retentionDays, { type: "number", attrs: 'min="7" max="730" step="1"' })}
          ${field("collect:region", "Region code", c.region, { attrs: 'maxlength="2"', help: "Two letters, e.g. IN. Used by YouTube and Google News." })}
        </div>
      </section>

      <section class="panel" id="sec-data" aria-labelledby="h-setup-data">
        <div class="panel-head"><div><h2 id="h-setup-data">Your data and setup backup</h2><p class="lede">Collected posts live in this browser. A setup backup lets you move brands and settings to another computer or a fresh install.</p></div></div>
        <div style="display:grid;gap:14px">
          <div class="backup-row">
            <button class="btn" type="button" data-act="backup">Download setup backup</button>
            <label class="check"><input type="checkbox" id="backup-keys"> Include API keys (keep the file private)</label>
            <label class="btn" for="restore-file">Restore setup from backup</label>
            <input class="sr-only" type="file" id="restore-file" accept=".json,application/json">
          </div>
          <div class="backup-row">
            <button class="btn" type="button" data-act="export">Export all posts (CSV)</button>
            ${confirmDelete
              ? `<span class="confirm">Delete every collected post and article? Settings and keys stay. <button class="btn small danger" type="button" data-act="delete-yes">Delete data</button><button class="btn small" type="button" data-act="delete-no">Cancel</button></span>`
              : `<button class="btn danger" type="button" data-act="delete">Delete collected data</button>`}
          </div>
        </div>
      </section>

      <div class="savebar"><span class="msg">All changes saved.</span><button class="btn" type="button" id="discard" disabled>Discard changes</button><button class="btn primary" type="button" id="save" disabled>Save</button></div>`;
    notifyDirty();
  }

  /** Re-derive everything that depends on the draft without rebuilding inputs (keeps focus and caret). */
  function refreshDerived() {
    const r = root.querySelector("#readiness");
    if (r) r.innerHTML = readiness();
    const cov = root.querySelector("#coverage");
    if (cov) cov.innerHTML = coverage();
    root.querySelectorAll(".bcard").forEach((card) => {
      const b = draft.brands.find((x) => x.id === card.dataset.brand);
      if (!b) return;
      card.querySelector("[data-rename]").innerHTML = renameWarning(b);
      card.querySelector("[data-advsum]").innerHTML = advSummary(b);
      card.querySelectorAll("[data-preview]").forEach((el) => (el.innerHTML = handleStatus(el.dataset.preview, b.handles[el.dataset.preview])));
    });
    const u = usable();
    root.querySelectorAll(".krow").forEach((row) => {
      const pf = row.dataset.platform;
      const need = brandsOn(u, pf).length;
      const missing = accessMode(u, pf).missing;
      const needed = need && missing.length && pf !== "youtube";
      row.classList.toggle("needed", !!needed);
      row.querySelector("[data-badge]").innerHTML = !missing.length ? `<span class="pill good">Saved</span>`
        : needed ? `<span class="pill warn">Needed for ${need} brand${need === 1 ? "" : "s"}</span>`
        : pf === "youtube" && need ? `<span class="pill">Optional: adds search</span>` : `<span class="pill">Not needed yet</span>`;
    });
  }

  function setPath(path, el) {
    const parts = path.split(":");
    if (parts[0] === "brand") {
      const b = draft.brands.find((x) => x.id === parts[1]);
      if (!b) return;
      const key = parts[2];
      if (key === "name") b.name = el.value;
      else if (key === "primary") b.primary = el.checked;
      else if (PLATFORMS.includes(key)) b.handles[key] = el.value;
      else if (key === "hashtags") b.hashtags = el.value.split(",").map((s) => s.trim().replace(/^#/, "")).filter(Boolean);
      else b[key] = el.value.split(",").map((s) => s.trim()).filter(Boolean);
    } else if (parts[0] === "keys") {
      draft.keys[parts[1]] = el.value.trim();
    } else if (parts[0] === "collect") {
      const k = parts[1];
      draft.collect[k] = el.type === "checkbox" ? el.checked : el.type === "number" ? (el.value === "" ? "" : Number(el.value)) : el.value;
    }
  }

  function focus(section) {
    if (!section) return;
    const el = root.querySelector(`#${section.startsWith("key-") ? section : "sec-" + section}`);
    if (!el) return;
    if (section.startsWith("key-")) {
      const g = el.querySelector("details.guide");
      if (g) g.open = true;
    }
    el.scrollIntoView({ behavior: "smooth", block: "start" });
    el.classList.remove("flash");
    void el.offsetWidth;
    el.classList.add("flash");
    const input = section.startsWith("key-") ? el.querySelector("input") : null;
    if (input) setTimeout(() => input.focus({ preventScroll: true }), 350);
  }

  root.addEventListener("input", (e) => {
    const el = e.target.closest("[data-path]");
    if (!el) return;
    setPath(el.dataset.path, el);
    const parts = el.dataset.path.split(":");
    if (errors[el.dataset.path]) {
      delete errors[el.dataset.path];
      const f = el.closest(".field");
      f.classList.remove("invalid");
      el.setAttribute("aria-invalid", "false");
      const er = f.querySelector(":scope > .err");
      if (er && !PLATFORMS.includes(parts[2])) er.remove();
    }
    refreshDerived();
    notifyDirty();
  });
  root.addEventListener("change", async (e) => {
    if (e.target.matches('input[type="checkbox"][data-path]')) {
      setPath(e.target.dataset.path, e.target);
      refreshDerived();
      notifyDirty();
    }
    if (e.target.id === "restore-file") await restore(e.target);
  });

  async function restore(input) {
    const file = input.files && input.files[0];
    input.value = "";
    if (!file) return;
    try {
      const data = JSON.parse(await file.text());
      if (!data || data.app !== "signal-room" || !data.settings || !Array.isArray(data.settings.brands)) throw new Error("not a backup");
      const keys = data.settings.keys && Object.values(data.settings.keys).some(Boolean) ? data.settings.keys : draft.keys;
      draft = normalizeSettings({ ...data.settings, keys });
      errors = {};
      render();
      toast(`Backup loaded: ${draft.brands.length} brand${draft.brands.length === 1 ? "" : "s"}. Review it, then press Save.`);
    } catch {
      toast("That file isn't a Signal Room setup backup.");
    }
  }

  root.addEventListener("click", async (e) => {
    const btn = e.target.closest("[data-act], #save, #discard");
    if (!btn) return;
    const act = btn.dataset.act || btn.id;
    const card = btn.closest("[data-brand]");
    if (act === "add") {
      if (draft.brands.length >= MAX_BRANDS) return;
      const nb = emptyBrand("");
      draft.brands.push(nb);
      render();
      root.querySelector(`[data-path="brand:${nb.id}:name"]`).focus();
    } else if (act === "remove") {
      confirmRemove = card.dataset.brand;
      render();
    } else if (act === "remove-no") {
      confirmRemove = null;
      render();
    } else if (act === "remove-yes") {
      draft.brands = draft.brands.filter((b) => b.id !== card.dataset.brand);
      confirmRemove = null;
      render();
    } else if (act === "clear-adv") {
      const b = draft.brands.find((x) => x.id === card.dataset.brand);
      if (b) {
        b.keywords = [];
        b.hashtags = [];
        b.context = [];
        b.exclude = [];
        render();
        toast(`Advanced matching cleared for ${b.name || "this brand"}. Press Save to keep it.`);
      }
    } else if (act === "goto-key") {
      focus(`key-${btn.dataset.platform}`);
    } else if (act === "reveal") {
      const input = btn.parentElement.querySelector("input");
      input.type = input.type === "password" ? "text" : "password";
      btn.textContent = input.type === "password" ? "Show" : "Hide";
    } else if (act === "test") {
      const row = btn.closest("[data-platform]");
      const out = row.querySelector("[data-result]");
      out.className = "test-result";
      out.innerHTML = `<span class="spin" aria-hidden="true"></span> Testing…`;
      btn.disabled = true;
      try {
        const r = await checkPlatform(row.dataset.platform, usable());
        out.className = "test-result " + (r.ok ? "ok" : "bad");
        out.textContent = (r.ok ? "✓ " : "✕ ") + r.message;
      } catch (err) {
        out.className = "test-result bad";
        out.textContent = "✕ " + ((err && err.message) || err);
      } finally {
        btn.disabled = false;
      }
    } else if (act === "diagnose") {
      if (diagRunning) return;
      diagRunning = true;
      diagRows = [];
      btn.disabled = true;
      btn.innerHTML = '<span class="spin" aria-hidden="true"></span> Checking…';
      root.querySelector("#diag").innerHTML = diagHtml();
      try {
        await diagnose(usable(), {
          cache: structuredClone((getCache && getCache()) || {}),
          onRow: (r) => {
            diagRows.push(r);
            const d = root.querySelector("#diag");
            if (d) d.innerHTML = diagHtml();
          },
        });
      } catch (err) {
        diagRows.push({ platform: "news", brand: "", ok: false, detail: `Checks stopped: ${(err && err.message) || err}` });
      } finally {
        diagRunning = false;
        const d = root.querySelector("#diag");
        if (d) d.innerHTML = diagHtml();
        const b = root.querySelector('[data-act="diagnose"]');
        if (b) {
          b.disabled = false;
          b.textContent = "Run checks";
        }
        const bad = diagRows.filter((r) => r.ok === false).length;
        toast(bad ? `Checks done: ${bad} problem${bad === 1 ? "" : "s"} to fix.` : "Checks done: everything that's set up works.");
      }
    } else if (act === "backup") {
      const withKeys = root.querySelector("#backup-keys").checked;
      const n = normalizeSettings(draft);
      const out = { app: "signal-room", version: chrome.runtime.getManifest().version, exportedAt: new Date().toISOString(), settings: { brands: n.brands, collect: n.collect, ...(withKeys ? { keys: n.keys } : {}) } };
      downloadFile(`signal-room-setup_${new Date().toISOString().slice(0, 10)}.json`, JSON.stringify(out, null, 2), "application/json");
    } else if (act === "export") {
      exportAll();
    } else if (act === "delete") {
      confirmDelete = true;
      render();
    } else if (act === "delete-no") {
      confirmDelete = false;
      render();
    } else if (act === "delete-yes") {
      confirmDelete = false;
      await deleteAll();
      render();
      toast("Collected data deleted.");
    } else if (act === "discard") {
      draft = structuredClone(saved);
      errors = {};
      confirmRemove = null;
      render();
    } else if (act === "save") {
      await doSave();
    }
  });

  async function doSave() {
    const n = normalizeSettings(draft);
    const errs = validateSettings(n);
    errors = Object.fromEntries(errs.map((e) => [e.field, e.message]));
    if (errs.length) {
      render();
      const msg = root.querySelector(".savebar .msg");
      msg.classList.add("bad");
      msg.textContent = `Fix ${errs.length} problem${errs.length === 1 ? "" : "s"} before saving.`;
      const first = root.querySelector('[aria-invalid="true"]');
      if (first) first.focus();
      return;
    }
    const clean = cleanHandles(n);
    const before = new Map(saved.brands.map((b) => [b.id, b.name]));
    const after = new Map(clean.brands.map((b) => [b.id, b.name]));
    const removed = [...before].filter(([id]) => !after.has(id)).map(([, name]) => name);
    const renamed = [...before].filter(([id, name]) => after.has(id) && after.get(id) !== name).map(([id, name]) => [name, after.get(id)]);
    await save(clean, { removed, renamed });
    saved = clean;
    draft = structuredClone(clean);
    errors = {};
    render();
    const plan = collectionPlan(clean);
    const ready = plan.filter((p) => p.state === "ready" || p.state === "limited").map((p) => p.label + (p.state === "limited" ? " (own videos)" : ""));
    const blocked = plan.filter((p) => p.state === "needs-access").map((p) => p.label);
    toast(`Saved. Will collect: ${ready.join(", ") || "nothing yet"}.${blocked.length ? ` Needs access: ${blocked.join(", ")}.` : ""}`, 6000);
  }

  return {
    render,
    focus,
    /** Load the saved settings into the form (call once storage has been read). */
    load() {
      saved = getSettings();
      draft = structuredClone(saved);
      errors = {};
      render();
    },
    /** Settings changed in storage: always track them as the saved baseline; keep the user's unsaved edits if any. */
    reload() {
      const dirty = isDirty();
      saved = getSettings();
      if (dirty) {
        notifyDirty();
        return;
      }
      draft = structuredClone(saved);
      render();
    },
    isDirty,
    save: doSave,
  };
}
