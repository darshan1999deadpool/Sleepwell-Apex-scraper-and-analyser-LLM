// Chrome's "Extension options" link lands here; send it to the Setup tab of the app.
location.replace(chrome.runtime.getURL("app.html#setup"));
