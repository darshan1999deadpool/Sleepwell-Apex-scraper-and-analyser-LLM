// Background service worker: runs collections (on demand and daily), keeps the schedule.
import { cleanHandles, nextDailyTime, normalizeSettings, starterSettings } from "./core/config.js";
import { checkPlatform, emptyState, runCollection } from "./core/collect.js";

const ALARM = "signal-room-daily";
let running = null;

async function getSettings() {
  const { settings } = await chrome.storage.local.get("settings");
  return cleanHandles(normalizeSettings(settings || starterSettings()));
}

async function getState() {
  const s = await chrome.storage.local.get(["posts", "news", "runs", "status", "cache"]);
  return { ...emptyState(), ...s };
}

async function schedule() {
  const settings = await getSettings();
  await chrome.alarms.clear(ALARM);
  if (settings.collect.autoDaily) {
    await chrome.alarms.create(ALARM, { when: nextDailyTime(settings.collect.dailyTime), periodInMinutes: 1440 });
  }
}

// A service worker can be stopped after ~30s without extension activity; long rate-limit
// waits would end a run early, so touch an extension API while a run is in progress.
function keepAlive() {
  const t = setInterval(() => chrome.runtime.getPlatformInfo(() => void chrome.runtime.lastError), 20000);
  return () => clearInterval(t);
}

async function startRun(trigger) {
  if (running) return { started: false, message: "A collection is already running." };
  running = (async () => {
    const stop = keepAlive();
    const startedAt = new Date().toISOString();
    try {
      await chrome.storage.session.set({ progress: { running: true, trigger, startedAt, label: "Starting", step: 0, total: 5 } });
      const settings = await getSettings();
      const state = await getState();
      const { state: next, summary } = await runCollection({
        settings,
        state,
        onProgress: (p) => chrome.storage.session.set({ progress: { running: p.platform !== "done", trigger, startedAt, ...p } }),
      });
      await chrome.storage.local.set({ posts: next.posts, news: next.news, runs: next.runs, status: next.status, cache: next.cache, lastRun: { at: new Date().toISOString(), trigger, ...summary } });
      const brief = Object.fromEntries(Object.entries(summary.status).map(([k, v]) => [k, { status: v.status, state: v.state, items: v.items }]));
      await chrome.storage.session.set({ progress: { running: false, trigger, startedAt, finishedAt: new Date().toISOString(), ok: true, summary: { added: summary.added, updated: summary.updated, dropped: summary.dropped }, brief } });
    } catch (e) {
      await chrome.storage.session.set({ progress: { running: false, trigger, startedAt, finishedAt: new Date().toISOString(), ok: false, error: String((e && e.message) || e) } });
    } finally {
      stop();
      running = null;
    }
  })();
  return { started: true };
}

function openApp(hash = "") {
  return chrome.tabs.create({ url: chrome.runtime.getURL("app.html") + hash });
}

chrome.runtime.onInstalled.addListener(async ({ reason }) => {
  const { settings } = await chrome.storage.local.get("settings");
  if (!settings) await chrome.storage.local.set({ settings: starterSettings() });
  await schedule();
  if (reason === "install") await openApp("#setup");
});

chrome.runtime.onStartup.addListener(schedule);
chrome.action.onClicked.addListener(() => openApp());

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM) startRun("scheduled");
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.settings) schedule();
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || typeof msg !== "object") return false;
  if (msg.type === "collect") {
    startRun("manual").then(sendResponse);
    return true;
  }
  if (msg.type === "check") {
    const settings = cleanHandles(normalizeSettings(msg.settings));
    checkPlatform(msg.platform, settings).then(sendResponse);
    return true;
  }
  if (msg.type === "status") {
    sendResponse({ running: !!running });
    return false;
  }
  return false;
});
